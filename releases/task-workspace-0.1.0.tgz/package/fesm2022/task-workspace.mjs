import * as i0 from '@angular/core';
import { InjectionToken, inject, signal, effect, Component, input, output, computed, HostBinding } from '@angular/core';
import { NgComponentOutlet, DatePipe, NgClass } from '@angular/common';
import * as i5 from '@angular/cdk/drag-drop';
import { moveItemInArray, transferArrayItem, DragDropModule } from '@angular/cdk/drag-drop';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i3 from 'primeng/avatar';
import { AvatarModule } from 'primeng/avatar';
import * as i5$1 from 'primeng/contextmenu';
import { ContextMenuModule } from 'primeng/contextmenu';
import * as i4 from 'primeng/tag';
import { TagModule } from 'primeng/tag';
import * as i6 from 'primeng/tooltip';
import { TooltipModule } from 'primeng/tooltip';
import * as i2$1 from 'primeng/button';
import { ButtonModule } from 'primeng/button';
import * as i3$1 from 'primeng/select';
import { SelectModule } from 'primeng/select';

function defaultColumnsForSpace(spaceId) {
    return [
        { id: `${spaceId}-todo`, spaceId, title: 'To do', order: 0, wipLimit: 12, statusType: 'todo' },
        {
            id: `${spaceId}-in_progress`,
            spaceId,
            title: 'In progress',
            order: 1,
            wipLimit: 5,
            statusType: 'in_progress',
        },
        { id: `${spaceId}-review`, spaceId, title: 'Review', order: 2, wipLimit: 4, statusType: 'review' },
        { id: `${spaceId}-done`, spaceId, title: 'Done', order: 3, statusType: 'done' },
    ];
}
function defaultTodoColumnId(spaceId, columns) {
    const cols = columns.filter((c) => c.spaceId === spaceId).sort((a, b) => a.order - b.order);
    return cols.find((c) => c.statusType === 'todo')?.id ?? cols[0]?.id ?? `${spaceId}-todo`;
}
function dateKey(d) {
    return d.toISOString().slice(0, 10);
}

/**
 * Host app implements this (HTTP, store, etc.).
 * Board / scheduler never touch a concrete store.
 */
class TaskWorkspaceFacade {
}

function provideTaskWorkspace(options) {
    if (options.useExisting) {
        return [{ provide: TaskWorkspaceFacade, useExisting: options.useExisting }];
    }
    if (options.useClass) {
        return [{ provide: TaskWorkspaceFacade, useClass: options.useClass }];
    }
    if (options.useFactory) {
        return [
            {
                provide: TaskWorkspaceFacade,
                useFactory: options.useFactory,
                deps: options.deps ?? [],
            },
        ];
    }
    throw new Error('provideTaskWorkspace requires one of: useClass, useExisting, or useFactory');
}

const DEFAULT_TASK_LABELS = {
    favorite: 'Favorite',
    pin: 'Pin',
    open: 'Open',
    duplicate: 'Duplicate',
    delete: 'Delete',
    addCard: 'Add a card',
    addList: 'Add another list',
    deleteList: 'Delete list',
    newList: 'Enter list title…',
    wip: 'WIP',
    today: 'Today',
    month: 'Month',
    week: 'Week',
    day: 'Day',
    agenda: 'Agenda',
    addTask: 'Add task',
    noTasks: 'No tasks',
    actions: 'Actions',
};
const TASK_LABELS = new InjectionToken('TASK_LABELS', {
    providedIn: 'root',
    factory: () => DEFAULT_TASK_LABELS,
});

/**
 * Host registers its own task-detail dialog component.
 * Core only mounts it via TaskDialogHostComponent.
 */
const TASK_DETAIL_DIALOG = new InjectionToken('TASK_DETAIL_DIALOG');
function provideTaskDetailDialog(component) {
    return { provide: TASK_DETAIL_DIALOG, useValue: component };
}

/**
 * Keeps the host-provided dialog instance alive after first open so overlays
 * can dispose cleanly instead of being torn down mid-close.
 */
class TaskDialogHostComponent {
    facade = inject(TaskWorkspaceFacade);
    registered = inject(TASK_DETAIL_DIALOG, { optional: true });
    dialogType = signal(null);
    constructor() {
        effect(() => {
            const open = !!this.facade.selectedTaskId();
            if (!open || this.dialogType() || !this.registered)
                return;
            this.dialogType.set(this.registered);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: TaskDialogHostComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: TaskDialogHostComponent, isStandalone: true, selector: "tw-task-dialog-host", ngImport: i0, template: `
    @if (dialogType(); as type) {
      <ng-container *ngComponentOutlet="type" />
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: NgComponentOutlet, selector: "[ngComponentOutlet]", inputs: ["ngComponentOutlet", "ngComponentOutletInputs", "ngComponentOutletInjector", "ngComponentOutletContent", "ngComponentOutletNgModule", "ngComponentOutletNgModuleFactory"], exportAs: ["ngComponentOutlet"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: TaskDialogHostComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'tw-task-dialog-host',
                    standalone: true,
                    imports: [NgComponentOutlet],
                    template: `
    @if (dialogType(); as type) {
      <ng-container *ngComponentOutlet="type" />
    }
  `,
                }]
        }], ctorParameters: () => [] });

class TaskBoardComponent {
    facade = inject(TaskWorkspaceFacade);
    labels = inject(TASK_LABELS);
    /** Required — todos/tasks are always scoped to a space declared by the host. */
    spaceId = input.required();
    tasks = input.required();
    /** Optional display name for accessibility. */
    spaceName = input('Board');
    taskOpen = output();
    collapsed = signal(new Set());
    selectedTaskId = signal(null);
    addingList = signal(false);
    newListTitle = signal('');
    /** True while a card/column is dragged — locks overflow so no scrollbar flash. */
    dragging = signal(false);
    get hostDragging() {
        return this.dragging();
    }
    contextItems = [];
    columnMenuItems = [];
    columns = computed(() => this.facade.columnsForSpace(this.spaceId()));
    /** Card drop-lists connect only to each other (not the column list). */
    connectedCardLists = computed(() => this.columns().map((c) => this.cardListId(c.id)));
    columnMap = computed(() => {
        const map = new Map();
        for (const col of this.columns()) {
            map.set(col.id, []);
        }
        for (const t of this.tasks()) {
            const list = map.get(t.columnId);
            if (list)
                list.push(t);
            else
                map.set(t.columnId, [t]);
        }
        for (const [, list] of map) {
            list.sort((a, b) => a.order - b.order);
        }
        return map;
    });
    tasksInColumn(columnId) {
        return this.columnMap().get(columnId) ?? [];
    }
    cardListId(columnId) {
        return `col-cards-${columnId}`;
    }
    dropColumn(event) {
        if (event.previousIndex === event.currentIndex)
            return;
        const ordered = [...this.columns()];
        moveItemInArray(ordered, event.previousIndex, event.currentIndex);
        this.facade.reorderColumns(this.spaceId(), ordered.map((c) => c.id));
    }
    drop(event, columnId) {
        const spaceId = this.spaceId();
        if (event.previousContainer === event.container) {
            moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
            this.facade.syncBoardColumns(spaceId, [
                { columnId, orderedIds: event.container.data.map((t) => t.id) },
            ]);
            return;
        }
        const moved = event.previousContainer.data[event.previousIndex];
        const fromColumnId = moved.columnId;
        transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
        this.facade.syncBoardColumns(spaceId, [
            { columnId: fromColumnId, orderedIds: event.previousContainer.data.map((t) => t.id) },
            { columnId, orderedIds: event.container.data.map((t) => t.id) },
        ], { taskId: moved.id, toColumnId: columnId });
    }
    toggleCollapse(columnId) {
        this.collapsed.update((set) => {
            const next = new Set(set);
            if (next.has(columnId))
                next.delete(columnId);
            else
                next.add(columnId);
            return next;
        });
    }
    isCollapsed(columnId) {
        return this.collapsed().has(columnId);
    }
    wipExceeded(col, count) {
        return !!col.wipLimit && count > col.wipLimit;
    }
    open(task) {
        this.selectedTaskId.set(task.id);
        this.taskOpen.emit(task.id);
    }
    onDragStarted() {
        this.dragging.set(true);
        document.documentElement.classList.add('tw-taskboard-dnd');
    }
    onDragEnded() {
        this.dragging.set(false);
        document.documentElement.classList.remove('tw-taskboard-dnd');
    }
    ngOnDestroy() {
        document.documentElement.classList.remove('tw-taskboard-dnd');
    }
    openColumnMenu(event, col, menu) {
        event.preventDefault();
        event.stopPropagation();
        const canDelete = this.columns().length > 1;
        this.columnMenuItems = [
            {
                label: this.labels.deleteList,
                icon: 'pi pi-trash',
                disabled: !canDelete,
                command: () => this.deleteList(col.id),
            },
        ];
        menu.show(event);
    }
    deleteList(columnId) {
        const ok = this.facade.removeColumn(columnId);
        if (!ok)
            return;
        this.collapsed.update((set) => {
            if (!set.has(columnId))
                return set;
            const next = new Set(set);
            next.delete(columnId);
            return next;
        });
    }
    onContext(event, task, menu) {
        event.preventDefault();
        event.stopPropagation();
        const L = this.labels;
        this.contextItems = [
            {
                label: L.favorite,
                icon: task.favorite ? 'pi pi-star-fill' : 'pi pi-star',
                command: () => this.facade.toggleFavorite(task.id),
            },
            {
                label: L.pin,
                icon: 'pi pi-bookmark',
                command: () => this.facade.togglePinned(task.id),
            },
            {
                label: L.open,
                icon: 'pi pi-eye',
                command: () => this.open(task),
            },
            {
                label: L.duplicate,
                icon: 'pi pi-copy',
                command: () => this.facade.duplicateTask(task.id),
            },
            {
                label: L.delete,
                icon: 'pi pi-trash',
                command: () => this.facade.deleteTask(task.id),
            },
            { separator: true },
            ...this.columns().map((col) => ({
                label: `→ ${col.title}`,
                disabled: col.id === task.columnId,
                command: () => this.facade.moveTask(task.id, col.id),
            })),
        ];
        menu.show(event);
    }
    addCard(columnId) {
        const task = this.facade.createTask({
            spaceId: this.spaceId(),
            title: 'New task',
            description: '',
            columnId,
            priority: 'medium',
            assigneeIds: [this.facade.currentUserId()],
            reporterId: this.facade.currentUserId(),
            dueDate: null,
            scheduleStart: null,
            scheduleEnd: null,
            favorite: false,
            pinned: false,
            tags: [],
        });
        this.taskOpen.emit(task.id);
    }
    startAddList() {
        this.addingList.set(true);
        this.newListTitle.set('');
    }
    cancelAddList() {
        this.addingList.set(false);
        this.newListTitle.set('');
    }
    confirmAddList() {
        const title = this.newListTitle().trim();
        if (!title)
            return;
        this.facade.addColumn(this.spaceId(), title);
        this.cancelAddList();
    }
    assignees(task) {
        return task.assigneeIds.map((id) => this.facade.userById(id)).filter(Boolean);
    }
    checklistProgress(task) {
        if (!task.checklist.length)
            return null;
        return {
            done: task.checklist.filter((c) => c.done).length,
            total: task.checklist.length,
        };
    }
    hasDescription(task) {
        return !!task.description?.trim();
    }
    isOverdue(task) {
        if (!task.dueDate || this.facade.isDoneColumn(task.columnId))
            return false;
        const start = new Date();
        start.setHours(0, 0, 0, 0);
        return new Date(task.dueDate) < start;
    }
    priorityLabel(priority) {
        const map = {
            urgent: 'P1',
            high: 'P2',
            medium: 'P3',
            low: 'P4',
        };
        return map[priority];
    }
    columnStatusClass(col) {
        const t = col.statusType ?? 'todo';
        if (t === 'done')
            return 'p-taskboard-column-done';
        if (t === 'in_progress' || t === 'review')
            return 'p-taskboard-column-in-progress';
        if (t === 'blocked')
            return 'p-taskboard-column-blocked';
        return 'p-taskboard-column-todo';
    }
    label(key) {
        return this.labels[key];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: TaskBoardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: TaskBoardComponent, isStandalone: true, selector: "tw-task-board", inputs: { spaceId: { classPropertyName: "spaceId", publicName: "spaceId", isSignal: true, isRequired: true, transformFunction: null }, tasks: { classPropertyName: "tasks", publicName: "tasks", isSignal: true, isRequired: true, transformFunction: null }, spaceName: { classPropertyName: "spaceName", publicName: "spaceName", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { taskOpen: "taskOpen" }, host: { properties: { "class.taskboard-dragging": "this.hostDragging" } }, ngImport: i0, template: "<div\r\n  class=\"p-taskboard trello-board h-full p-taskboard-density-standard\"\r\n  role=\"group\"\r\n  data-scope=\"taskboard\"\r\n  data-part=\"root\"\r\n  data-testid=\"trello-board\"\r\n  dataKey=\"id\"\r\n  columnField=\"columnId\"\r\n  tabindex=\"0\"\r\n  [attr.aria-label]=\"spaceName()\"\r\n>\r\n  <div data-scope=\"taskboard\" data-part=\"content\" class=\"p-taskboard-body\">\r\n    <div class=\"p-taskboard-columns-row\">\r\n    <div\r\n      data-scope=\"taskboard\"\r\n      data-part=\"columns\"\r\n      class=\"p-taskboard-columns\"\r\n      cdkDropList\r\n      cdkDropListOrientation=\"horizontal\"\r\n      [cdkDropListData]=\"columns()\"\r\n      (cdkDropListDropped)=\"dropColumn($event)\"\r\n    >\r\n      @for (col of columns(); track col.id) {\r\n        <div\r\n          data-scope=\"taskboard\"\r\n          data-part=\"column\"\r\n          role=\"list\"\r\n          class=\"p-taskboard-column\"\r\n          cdkDrag\r\n          [cdkDragData]=\"col\"\r\n          (cdkDragStarted)=\"onDragStarted()\"\r\n          (cdkDragEnded)=\"onDragEnded()\"\r\n          [ngClass]=\"columnStatusClass(col)\"\r\n          [class.wip-over]=\"wipExceeded(col, tasksInColumn(col.id).length)\"\r\n          [class.collapsed]=\"isCollapsed(col.id)\"\r\n          tabindex=\"-1\"\r\n          [attr.data-column-id]=\"col.id\"\r\n          [attr.aria-label]=\"col.title + ', ' + tasksInColumn(col.id).length + ' items'\"\r\n          [attr.aria-expanded]=\"!isCollapsed(col.id)\"\r\n        >\r\n          <div\r\n            data-scope=\"taskboard\"\r\n            data-part=\"column-header\"\r\n            role=\"heading\"\r\n            aria-level=\"2\"\r\n            class=\"p-taskboard-column-header\"\r\n            [attr.aria-label]=\"col.title + ' column header'\"\r\n          >\r\n            @if (isCollapsed(col.id)) {\r\n              <div class=\"taskboard-column-collapsed-rail\" cdkDragHandle>\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"taskboard-column-collapsed-expand\"\r\n                  [attr.aria-label]=\"'Expand ' + col.title + ' column'\"\r\n                  aria-expanded=\"false\"\r\n                  [attr.title]=\"col.title + ' (' + tasksInColumn(col.id).length + ')'\"\r\n                  (click)=\"toggleCollapse(col.id)\"\r\n                >\r\n                  <i class=\"pi pi-chevron-right taskboard-column-header-chevron\"></i>\r\n                </button>\r\n                <span class=\"taskboard-column-collapsed-title\">{{ col.title }}</span>\r\n                <span class=\"taskboard-column-collapsed-count\">{{ tasksInColumn(col.id).length }}</span>\r\n              </div>\r\n            } @else {\r\n              <div data-scope=\"taskboard\" data-part=\"column-header-ui\" class=\"taskboard-column-header-content\">\r\n                <div class=\"taskboard-column-header-left\" cdkDragHandle>\r\n                  <i class=\"pi pi-bars taskboard-column-drag-grip\" aria-hidden=\"true\"></i>\r\n                  <span class=\"taskboard-column-header-title\">{{ col.title }}</span>\r\n                  <p-tag\r\n                    severity=\"secondary\"\r\n                    [rounded]=\"true\"\r\n                    [value]=\"'' + tasksInColumn(col.id).length\"\r\n                  />\r\n                  @if (col.wipLimit) {\r\n                    <span class=\"taskboard-column-header-wip\" [class.bad]=\"wipExceeded(col, tasksInColumn(col.id).length)\">\r\n                      {{ label('wip') }} {{ tasksInColumn(col.id).length }}/{{ col.wipLimit }}\r\n                    </span>\r\n                  }\r\n                </div>\r\n                <div class=\"taskboard-column-header-actions\">\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"taskboard-column-header-menu\"\r\n                    [attr.aria-label]=\"label('actions')\"\r\n                    (click)=\"openColumnMenu($event, col, colCm)\"\r\n                  >\r\n                    <i class=\"pi pi-ellipsis-h\"></i>\r\n                  </button>\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"taskboard-column-header-collapse-toggle\"\r\n                    [attr.aria-label]=\"'Collapse ' + col.title + ' column'\"\r\n                    aria-expanded=\"true\"\r\n                    (click)=\"toggleCollapse(col.id)\"\r\n                  >\r\n                    <i class=\"pi pi-chevron-down taskboard-column-header-chevron\"></i>\r\n                  </button>\r\n                </div>\r\n              </div>\r\n            }\r\n          </div>\r\n\r\n          @if (!isCollapsed(col.id)) {\r\n            <div\r\n              data-scope=\"taskboard\"\r\n              data-part=\"column-content\"\r\n              class=\"p-taskboard-column-body\"\r\n              cdkDropList\r\n              [id]=\"cardListId(col.id)\"\r\n              [cdkDropListData]=\"tasksInColumn(col.id)\"\r\n              [cdkDropListConnectedTo]=\"connectedCardLists()\"\r\n              (cdkDropListDropped)=\"drop($event, col.id)\"\r\n            >\r\n              @for (task of tasksInColumn(col.id); track task.id; let i = $index) {\r\n                <div\r\n                  data-scope=\"taskboard\"\r\n                  data-part=\"card\"\r\n                  role=\"listitem\"\r\n                  class=\"p-taskboard-card p-taskboard-card-draggable\"\r\n                  [class.p-taskboard-card-selected]=\"selectedTaskId() === task.id\"\r\n                  cdkDrag\r\n                  cdkDragPreviewClass=\"taskboard-card-drag-preview\"\r\n                  tabindex=\"-1\"\r\n                  [attr.data-task-id]=\"task.id\"\r\n                  [attr.data-task-index]=\"i\"\r\n                  [attr.aria-selected]=\"selectedTaskId() === task.id\"\r\n                  [attr.aria-label]=\"task.title\"\r\n                  (cdkDragStarted)=\"onDragStarted()\"\r\n                  (cdkDragEnded)=\"onDragEnded()\"\r\n                  (click)=\"open(task)\"\r\n                  (contextmenu)=\"onContext($event, task, cm)\"\r\n                >\r\n                  <div data-scope=\"taskboard\" data-part=\"card-advanced-ui\" class=\"taskboard-card-advanced\">\r\n                    @if (task.tags.length) {\r\n                      <div class=\"taskboard-card-advanced-tags\">\r\n                        @for (tag of task.tags; track tag) {\r\n                          <span class=\"taskboard-card-advanced-tag\">{{ tag }}</span>\r\n                        }\r\n                      </div>\r\n                    }\r\n\r\n                    <span class=\"taskboard-card-advanced-title\">{{ task.title }}</span>\r\n\r\n                    <div class=\"taskboard-card-advanced-badges\">\r\n                      <span class=\"taskboard-card-advanced-priority\" [attr.data-priority]=\"task.priority\">\r\n                        {{ priorityLabel(task.priority) }}\r\n                      </span>\r\n\r\n                      @if (checklistProgress(task); as prog) {\r\n                        <span class=\"taskboard-card-advanced-subtasks\">\r\n                          <i class=\"pi pi-check-square\"></i>\r\n                          {{ prog.done }}/{{ prog.total }}\r\n                        </span>\r\n                      }\r\n\r\n                      @if (hasDescription(task)) {\r\n                        <span class=\"taskboard-card-advanced-desc-icon\" title=\"Has description\">\r\n                          <i class=\"pi pi-align-left\"></i>\r\n                        </span>\r\n                      }\r\n\r\n                      @if (task.dueDate) {\r\n                        <span\r\n                          class=\"taskboard-card-advanced-due\"\r\n                          [class.taskboard-card-advanced-due-overdue]=\"isOverdue(task)\"\r\n                        >\r\n                          <i class=\"pi pi-calendar\"></i>\r\n                          {{ task.dueDate | date: 'MMM d' }}\r\n                        </span>\r\n                      }\r\n\r\n                      @if (task.pinned) {\r\n                        <i class=\"pi pi-bookmark-fill taskboard-card-advanced-pin\"></i>\r\n                      }\r\n                      @if (task.favorite) {\r\n                        <i class=\"pi pi-star-fill taskboard-card-advanced-star\"></i>\r\n                      }\r\n                    </div>\r\n\r\n                    @if (assignees(task); as people) {\r\n                      @if (people.length) {\r\n                        <p-avatar\r\n                          [label]=\"people[0]!.avatar\"\r\n                          shape=\"circle\"\r\n                          styleClass=\"taskboard-card-advanced-avatar\"\r\n                          [pTooltip]=\"people[0]!.name\"\r\n                        />\r\n                      }\r\n                    }\r\n                  </div>\r\n                </div>\r\n              }\r\n            </div>\r\n\r\n            <div data-scope=\"taskboard\" data-part=\"card-add\" class=\"p-taskboard-card-add\">\r\n              <button type=\"button\" class=\"taskboard-add-card-btn\" (click)=\"addCard(col.id)\">\r\n                <i class=\"pi pi-plus\"></i>\r\n                {{ label('addCard') }}\r\n              </button>\r\n            </div>\r\n          }\r\n        </div>\r\n      }\r\n    </div>\r\n\r\n      <div class=\"taskboard-add-list\">\r\n        @if (!addingList()) {\r\n          <button\r\n            type=\"button\"\r\n            data-testid=\"trello-add-list\"\r\n            class=\"taskboard-add-list-btn\"\r\n            (click)=\"startAddList()\"\r\n          >\r\n            <i class=\"pi pi-plus\"></i>\r\n            {{ label('addList') }}\r\n          </button>\r\n        } @else {\r\n          <div class=\"taskboard-add-list-form\">\r\n            <input\r\n              type=\"text\"\r\n              class=\"taskboard-add-list-input\"\r\n              [placeholder]=\"label('newList')\"\r\n              [ngModel]=\"newListTitle()\"\r\n              (ngModelChange)=\"newListTitle.set($event)\"\r\n              (keydown.enter)=\"confirmAddList()\"\r\n              (keydown.escape)=\"cancelAddList()\"\r\n            />\r\n            <div class=\"taskboard-add-list-actions\">\r\n              <button type=\"button\" class=\"taskboard-add-list-confirm\" (click)=\"confirmAddList()\">\r\n                {{ label('addList') }}\r\n              </button>\r\n              <button type=\"button\" class=\"taskboard-add-list-cancel\" (click)=\"cancelAddList()\">\r\n                <i class=\"pi pi-times\"></i>\r\n              </button>\r\n            </div>\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<p-contextMenu #cm [model]=\"contextItems\" />\r\n<p-contextMenu #colCm [model]=\"columnMenuItems\" />\r\n", styles: [":host{--tw-surface: var(--p-content-background, var(--p-surface-100, #f1f5f9));--tw-surface-card: var(--p-surface-0, #ffffff);--tw-surface-ground: var(--p-surface-50, #f8fafb);--tw-border: var(--p-content-border-color, var(--p-surface-200, #e2e8f0));--tw-text: var(--p-text-color, #0f172a);--tw-muted: var(--p-text-muted-color, #64748b);--tw-accent: var(--p-primary-color, #0f766e);--tw-accent-contrast: var(--p-primary-contrast-color, #ffffff);--tw-accent-soft: var(--p-primary-100, var(--p-primary-50, #ccfbf1));--tw-danger: var(--p-red-500, #dc2626);--tw-danger-border: var(--p-red-300, #fca5a5);--tw-warning: var(--p-orange-500, #ea580c);--tw-warning-soft: var(--p-orange-100, #ffedd5);--tw-highlight: var(--p-highlight-background, var(--p-primary-50, #f0fdfa));--tw-tag-bg: var(--p-surface-100, #f1f5f9);--tw-tag-fg: var(--p-surface-600, #475569);display:block;height:100%;min-height:0;overflow:hidden}.p-taskboard{--p-taskboard-column-min-width: 17rem;--p-taskboard-column-max-width: 17rem;--p-taskboard-columns-padding: .5rem;--p-taskboard-column-gap: .5rem;--p-taskboard-column-body-padding: .375rem;--p-taskboard-card-gap: .375rem;height:100%;min-height:0;overflow:hidden;outline:none}.p-taskboard-body{height:100%;min-height:0;overflow:hidden}.p-taskboard-columns-row{display:flex;flex-wrap:nowrap;align-items:stretch;gap:var(--p-taskboard-column-gap);padding:var(--p-taskboard-columns-padding);overflow-x:auto;overflow-y:hidden;height:100%;min-height:0;box-sizing:border-box;scrollbar-width:none;-ms-overflow-style:none}.p-taskboard-columns-row::-webkit-scrollbar{display:none;width:0;height:0}.p-taskboard-columns{display:flex;flex:0 0 auto;align-items:stretch;gap:var(--p-taskboard-column-gap);height:100%;min-height:0;width:max-content;min-width:max-content}.p-taskboard-column{display:flex;flex-direction:column;min-width:var(--p-taskboard-column-min-width);max-width:var(--p-taskboard-column-max-width);width:var(--p-taskboard-column-min-width);height:100%;max-height:100%;min-height:0;overflow:hidden;background:color-mix(in srgb,var(--tw-surface) 88%,transparent);border:1px solid var(--tw-border);border-radius:.75rem;flex-shrink:0}.p-taskboard-column.wip-over{border-color:var(--tw-danger-border);box-shadow:0 0 0 1px color-mix(in srgb,var(--tw-danger) 20%,transparent)}.p-taskboard-column.collapsed{--p-taskboard-collapsed-width: 2.75rem;min-width:var(--p-taskboard-collapsed-width);max-width:var(--p-taskboard-collapsed-width);width:var(--p-taskboard-collapsed-width);max-height:100%;align-self:stretch;height:100%}.taskboard-column-drag-grip{font-size:.7rem;color:var(--tw-muted);cursor:grab;flex-shrink:0}.taskboard-column-header-left[cdkDragHandle],.taskboard-column-collapsed-rail[cdkDragHandle]{cursor:grab}.taskboard-column-collapsed-rail{width:100%;height:100%;min-height:12rem;padding:.65rem .2rem;display:flex;flex-direction:column;align-items:center;gap:.55rem;color:var(--tw-muted);border-radius:.65rem;transition:background .15s ease,color .15s ease}.taskboard-column-collapsed-rail:hover{background:color-mix(in srgb,var(--tw-border) 55%,transparent);color:var(--tw-text)}.taskboard-column-collapsed-expand{border:0;background:transparent;cursor:pointer;padding:.15rem;color:inherit;line-height:1;display:grid;place-items:center;border-radius:.3rem}.taskboard-column-collapsed-expand .taskboard-column-header-chevron{font-size:.85rem;flex-shrink:0}.taskboard-column-collapsed-expand:hover{background:color-mix(in srgb,var(--tw-border) 70%,transparent)}.taskboard-column-collapsed-title{writing-mode:vertical-rl;transform:rotate(180deg);font-size:.75rem;font-weight:600;letter-spacing:.02em;white-space:nowrap;max-height:10rem;overflow:hidden;text-overflow:ellipsis;color:inherit}.taskboard-column-collapsed-count{font-size:.65rem;font-weight:700;flex-shrink:0;min-width:1.15rem;height:1.15rem;border-radius:999px;display:grid;place-items:center;background:color-mix(in srgb,var(--tw-border) 80%,transparent);color:var(--tw-text)}.p-taskboard-column-header{display:block;flex-shrink:0}.p-taskboard-column.collapsed .p-taskboard-column-header{flex:1;display:flex;min-height:0}.taskboard-column-header-content{display:flex;align-items:center;justify-content:space-between;gap:.35rem;padding:.55rem .65rem .35rem}.taskboard-column-header-left{display:flex;align-items:center;gap:.4rem;min-width:0;flex-wrap:wrap}.taskboard-column-header-title{font-weight:600;font-size:.875rem;color:var(--tw-text)}.taskboard-column-header-wip{font-size:.7rem;font-weight:600;color:var(--tw-accent)}.taskboard-column-header-wip.bad{color:var(--tw-danger)}.taskboard-column-header-actions{display:inline-flex;align-items:center;gap:.1rem;flex-shrink:0}.taskboard-column-header-menu,.taskboard-column-header-collapse-toggle{border:0;background:transparent;cursor:pointer;padding:.2rem;color:var(--tw-muted);border-radius:.35rem;line-height:1;display:grid;place-items:center;width:1.5rem;height:1.5rem}.taskboard-column-header-menu:hover,.taskboard-column-header-collapse-toggle:hover{background:color-mix(in srgb,var(--tw-border) 60%,transparent);color:var(--tw-text)}.taskboard-column-header-menu i,.taskboard-column-header-collapse-toggle i{font-size:.75rem}.taskboard-column-header-chevron{font-size:.7rem}.p-taskboard-column-body{display:flex;flex-direction:column;gap:var(--p-taskboard-card-gap);padding:var(--p-taskboard-column-body-padding);overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;flex:1 1 0;min-height:0;scrollbar-width:none;-ms-overflow-style:none}.p-taskboard-column-body::-webkit-scrollbar{display:none;width:0;height:0}:host.taskboard-dragging .p-taskboard-columns-row,:host.taskboard-dragging .p-taskboard-column-body{overflow:hidden!important}.p-taskboard-card{background:var(--tw-surface-card);border:1px solid var(--tw-border);border-radius:.5rem;padding:.55rem .6rem .5rem;cursor:grab;position:relative;box-shadow:0 1px 2px #0f172a0a;transition:box-shadow .15s ease,border-color .15s ease}.p-taskboard-card:hover{box-shadow:0 4px 12px #0f172a14}.p-taskboard-card-selected{border-color:color-mix(in srgb,var(--tw-accent) 55%,var(--tw-surface-card));box-shadow:0 0 0 1px color-mix(in srgb,var(--tw-accent) 35%,transparent)}.taskboard-card-advanced{display:flex;flex-direction:column;gap:.35rem;padding-right:1.75rem}.taskboard-card-advanced-tags{display:flex;flex-wrap:wrap;gap:.25rem}.taskboard-card-advanced-tag{font-size:.65rem;font-weight:500;padding:.1rem .4rem;border-radius:.3rem;background:var(--tw-tag-bg);color:var(--tw-tag-fg)}.taskboard-card-advanced-title{font-size:.8125rem;font-weight:600;line-height:1.35;color:var(--tw-text)}.taskboard-card-advanced-badges{display:flex;flex-wrap:wrap;align-items:center;gap:.35rem;font-size:.7rem;color:var(--tw-muted)}.taskboard-card-advanced-priority{font-weight:700;font-size:.65rem;padding:.1rem .35rem;border-radius:.25rem;letter-spacing:.02em}.taskboard-card-advanced-priority[data-priority=urgent]{background:var(--p-red-200, #fecaca);color:var(--p-red-800, #991b1b)}.taskboard-card-advanced-priority[data-priority=high]{background:var(--p-orange-200, #fed7aa);color:var(--p-orange-800, #9a3412)}.taskboard-card-advanced-priority[data-priority=medium]{background:var(--p-blue-200, #bfdbfe);color:var(--p-blue-800, #1e40af)}.taskboard-card-advanced-priority[data-priority=low]{background:var(--tw-tag-bg);color:var(--tw-tag-fg)}.taskboard-card-advanced-subtasks,.taskboard-card-advanced-due,.taskboard-card-advanced-desc-icon{display:inline-flex;align-items:center;gap:.2rem}.taskboard-card-advanced-subtasks .pi,.taskboard-card-advanced-due .pi,.taskboard-card-advanced-desc-icon .pi{font-size:.65rem}.taskboard-card-advanced-due-overdue{color:var(--tw-danger);font-weight:600}.taskboard-card-advanced-pin{color:var(--tw-muted);font-size:.7rem}.taskboard-card-advanced-star{color:var(--p-yellow-600, #ca8a04);font-size:.7rem}:host ::ng-deep .taskboard-card-advanced-avatar{position:absolute;right:.45rem;bottom:.4rem;width:1.5rem!important;height:1.5rem!important;font-size:.6rem!important;background:var(--p-primary-500, var(--tw-accent));color:var(--tw-accent-contrast)}.p-taskboard-card-add{flex:0 0 auto;flex-shrink:0;padding:.25rem .35rem .4rem;background:color-mix(in srgb,var(--tw-surface) 96%,var(--tw-surface-card));border-top:1px solid var(--tw-border);position:relative;z-index:1}.taskboard-add-card-btn{width:100%;border:0;background:transparent;color:var(--tw-muted);padding:.5rem;font-size:.8125rem;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:.25rem;border-radius:.4rem;transition:color .15s ease,background .15s ease}.taskboard-add-card-btn:hover{color:var(--tw-accent);background:color-mix(in srgb,var(--tw-surface-card) 70%,transparent)}.p-taskboard-column.cdk-drag-preview{box-sizing:border-box;border-radius:.75rem;box-shadow:0 12px 28px #0f172a2e;height:auto;max-height:min(80vh,36rem);overflow:hidden}.p-taskboard-column.cdk-drag-placeholder{min-height:8rem;opacity:.45;background:color-mix(in srgb,var(--tw-border) 45%,transparent);border:1px dashed var(--tw-border)}.taskboard-add-list{flex:0 0 auto;width:var(--p-taskboard-column-min-width);min-width:var(--p-taskboard-column-min-width);max-width:var(--p-taskboard-column-max-width);height:auto;align-self:flex-start;position:relative;z-index:0}.taskboard-add-list-btn{width:100%;border:1px dashed var(--tw-border);background:transparent;border-radius:.75rem;padding:.75rem 1rem;font-size:.8125rem;color:var(--tw-muted);cursor:pointer;display:flex;align-items:center;gap:.5rem;transition:background .15s ease,color .15s ease}.taskboard-add-list-btn:hover{background:color-mix(in srgb,var(--tw-surface) 90%,transparent);color:var(--tw-text)}.taskboard-add-list-form{background:color-mix(in srgb,var(--tw-surface) 88%,transparent);border:1px solid var(--tw-border);border-radius:.75rem;padding:.55rem;display:flex;flex-direction:column;gap:.45rem}.taskboard-add-list-input{width:100%;border:1px solid var(--tw-border);border-radius:.4rem;padding:.45rem .55rem;font-size:.8125rem;outline:none}.taskboard-add-list-input:focus{border-color:var(--tw-accent)}.taskboard-add-list-actions{display:flex;align-items:center;gap:.35rem}.taskboard-add-list-confirm{border:0;background:var(--tw-accent);color:var(--tw-accent-contrast);border-radius:.4rem;padding:.4rem .65rem;font-size:.75rem;cursor:pointer}.taskboard-add-list-cancel{border:0;background:transparent;color:var(--tw-muted);cursor:pointer;padding:.35rem}.cdk-drag-preview{box-sizing:border-box;border-radius:.5rem;box-shadow:0 12px 28px #0f172a2e;overflow:hidden!important;pointer-events:none;z-index:1000}.cdk-drag-placeholder{opacity:.35}.cdk-drop-list-dragging .p-taskboard-card:not(.cdk-drag-placeholder){transition:transform .2s ease}\n"], dependencies: [{ kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i5.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i5.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i5.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "pipe", type: DatePipe, name: "date" }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: AvatarModule }, { kind: "component", type: i3.Avatar, selector: "p-avatar", inputs: ["label", "icon", "image", "size", "shape", "style", "styleClass", "ariaLabel", "ariaLabelledBy"], outputs: ["onImageError"] }, { kind: "ngmodule", type: TagModule }, { kind: "component", type: i4.Tag, selector: "p-tag", inputs: ["style", "styleClass", "severity", "value", "icon", "rounded"] }, { kind: "ngmodule", type: ContextMenuModule }, { kind: "component", type: i5$1.ContextMenu, selector: "p-contextMenu, p-contextmenu, p-context-menu", inputs: ["model", "triggerEvent", "target", "global", "style", "styleClass", "appendTo", "autoZIndex", "baseZIndex", "id", "breakpoint", "ariaLabel", "ariaLabelledBy", "pressDelay"], outputs: ["onShow", "onHide"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i6.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "appendTo", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "pTooltip", "tooltipDisabled", "tooltipOptions"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: TaskBoardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'tw-task-board', standalone: true, imports: [
                        DragDropModule,
                        DatePipe,
                        NgClass,
                        FormsModule,
                        AvatarModule,
                        TagModule,
                        ContextMenuModule,
                        TooltipModule,
                    ], template: "<div\r\n  class=\"p-taskboard trello-board h-full p-taskboard-density-standard\"\r\n  role=\"group\"\r\n  data-scope=\"taskboard\"\r\n  data-part=\"root\"\r\n  data-testid=\"trello-board\"\r\n  dataKey=\"id\"\r\n  columnField=\"columnId\"\r\n  tabindex=\"0\"\r\n  [attr.aria-label]=\"spaceName()\"\r\n>\r\n  <div data-scope=\"taskboard\" data-part=\"content\" class=\"p-taskboard-body\">\r\n    <div class=\"p-taskboard-columns-row\">\r\n    <div\r\n      data-scope=\"taskboard\"\r\n      data-part=\"columns\"\r\n      class=\"p-taskboard-columns\"\r\n      cdkDropList\r\n      cdkDropListOrientation=\"horizontal\"\r\n      [cdkDropListData]=\"columns()\"\r\n      (cdkDropListDropped)=\"dropColumn($event)\"\r\n    >\r\n      @for (col of columns(); track col.id) {\r\n        <div\r\n          data-scope=\"taskboard\"\r\n          data-part=\"column\"\r\n          role=\"list\"\r\n          class=\"p-taskboard-column\"\r\n          cdkDrag\r\n          [cdkDragData]=\"col\"\r\n          (cdkDragStarted)=\"onDragStarted()\"\r\n          (cdkDragEnded)=\"onDragEnded()\"\r\n          [ngClass]=\"columnStatusClass(col)\"\r\n          [class.wip-over]=\"wipExceeded(col, tasksInColumn(col.id).length)\"\r\n          [class.collapsed]=\"isCollapsed(col.id)\"\r\n          tabindex=\"-1\"\r\n          [attr.data-column-id]=\"col.id\"\r\n          [attr.aria-label]=\"col.title + ', ' + tasksInColumn(col.id).length + ' items'\"\r\n          [attr.aria-expanded]=\"!isCollapsed(col.id)\"\r\n        >\r\n          <div\r\n            data-scope=\"taskboard\"\r\n            data-part=\"column-header\"\r\n            role=\"heading\"\r\n            aria-level=\"2\"\r\n            class=\"p-taskboard-column-header\"\r\n            [attr.aria-label]=\"col.title + ' column header'\"\r\n          >\r\n            @if (isCollapsed(col.id)) {\r\n              <div class=\"taskboard-column-collapsed-rail\" cdkDragHandle>\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"taskboard-column-collapsed-expand\"\r\n                  [attr.aria-label]=\"'Expand ' + col.title + ' column'\"\r\n                  aria-expanded=\"false\"\r\n                  [attr.title]=\"col.title + ' (' + tasksInColumn(col.id).length + ')'\"\r\n                  (click)=\"toggleCollapse(col.id)\"\r\n                >\r\n                  <i class=\"pi pi-chevron-right taskboard-column-header-chevron\"></i>\r\n                </button>\r\n                <span class=\"taskboard-column-collapsed-title\">{{ col.title }}</span>\r\n                <span class=\"taskboard-column-collapsed-count\">{{ tasksInColumn(col.id).length }}</span>\r\n              </div>\r\n            } @else {\r\n              <div data-scope=\"taskboard\" data-part=\"column-header-ui\" class=\"taskboard-column-header-content\">\r\n                <div class=\"taskboard-column-header-left\" cdkDragHandle>\r\n                  <i class=\"pi pi-bars taskboard-column-drag-grip\" aria-hidden=\"true\"></i>\r\n                  <span class=\"taskboard-column-header-title\">{{ col.title }}</span>\r\n                  <p-tag\r\n                    severity=\"secondary\"\r\n                    [rounded]=\"true\"\r\n                    [value]=\"'' + tasksInColumn(col.id).length\"\r\n                  />\r\n                  @if (col.wipLimit) {\r\n                    <span class=\"taskboard-column-header-wip\" [class.bad]=\"wipExceeded(col, tasksInColumn(col.id).length)\">\r\n                      {{ label('wip') }} {{ tasksInColumn(col.id).length }}/{{ col.wipLimit }}\r\n                    </span>\r\n                  }\r\n                </div>\r\n                <div class=\"taskboard-column-header-actions\">\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"taskboard-column-header-menu\"\r\n                    [attr.aria-label]=\"label('actions')\"\r\n                    (click)=\"openColumnMenu($event, col, colCm)\"\r\n                  >\r\n                    <i class=\"pi pi-ellipsis-h\"></i>\r\n                  </button>\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"taskboard-column-header-collapse-toggle\"\r\n                    [attr.aria-label]=\"'Collapse ' + col.title + ' column'\"\r\n                    aria-expanded=\"true\"\r\n                    (click)=\"toggleCollapse(col.id)\"\r\n                  >\r\n                    <i class=\"pi pi-chevron-down taskboard-column-header-chevron\"></i>\r\n                  </button>\r\n                </div>\r\n              </div>\r\n            }\r\n          </div>\r\n\r\n          @if (!isCollapsed(col.id)) {\r\n            <div\r\n              data-scope=\"taskboard\"\r\n              data-part=\"column-content\"\r\n              class=\"p-taskboard-column-body\"\r\n              cdkDropList\r\n              [id]=\"cardListId(col.id)\"\r\n              [cdkDropListData]=\"tasksInColumn(col.id)\"\r\n              [cdkDropListConnectedTo]=\"connectedCardLists()\"\r\n              (cdkDropListDropped)=\"drop($event, col.id)\"\r\n            >\r\n              @for (task of tasksInColumn(col.id); track task.id; let i = $index) {\r\n                <div\r\n                  data-scope=\"taskboard\"\r\n                  data-part=\"card\"\r\n                  role=\"listitem\"\r\n                  class=\"p-taskboard-card p-taskboard-card-draggable\"\r\n                  [class.p-taskboard-card-selected]=\"selectedTaskId() === task.id\"\r\n                  cdkDrag\r\n                  cdkDragPreviewClass=\"taskboard-card-drag-preview\"\r\n                  tabindex=\"-1\"\r\n                  [attr.data-task-id]=\"task.id\"\r\n                  [attr.data-task-index]=\"i\"\r\n                  [attr.aria-selected]=\"selectedTaskId() === task.id\"\r\n                  [attr.aria-label]=\"task.title\"\r\n                  (cdkDragStarted)=\"onDragStarted()\"\r\n                  (cdkDragEnded)=\"onDragEnded()\"\r\n                  (click)=\"open(task)\"\r\n                  (contextmenu)=\"onContext($event, task, cm)\"\r\n                >\r\n                  <div data-scope=\"taskboard\" data-part=\"card-advanced-ui\" class=\"taskboard-card-advanced\">\r\n                    @if (task.tags.length) {\r\n                      <div class=\"taskboard-card-advanced-tags\">\r\n                        @for (tag of task.tags; track tag) {\r\n                          <span class=\"taskboard-card-advanced-tag\">{{ tag }}</span>\r\n                        }\r\n                      </div>\r\n                    }\r\n\r\n                    <span class=\"taskboard-card-advanced-title\">{{ task.title }}</span>\r\n\r\n                    <div class=\"taskboard-card-advanced-badges\">\r\n                      <span class=\"taskboard-card-advanced-priority\" [attr.data-priority]=\"task.priority\">\r\n                        {{ priorityLabel(task.priority) }}\r\n                      </span>\r\n\r\n                      @if (checklistProgress(task); as prog) {\r\n                        <span class=\"taskboard-card-advanced-subtasks\">\r\n                          <i class=\"pi pi-check-square\"></i>\r\n                          {{ prog.done }}/{{ prog.total }}\r\n                        </span>\r\n                      }\r\n\r\n                      @if (hasDescription(task)) {\r\n                        <span class=\"taskboard-card-advanced-desc-icon\" title=\"Has description\">\r\n                          <i class=\"pi pi-align-left\"></i>\r\n                        </span>\r\n                      }\r\n\r\n                      @if (task.dueDate) {\r\n                        <span\r\n                          class=\"taskboard-card-advanced-due\"\r\n                          [class.taskboard-card-advanced-due-overdue]=\"isOverdue(task)\"\r\n                        >\r\n                          <i class=\"pi pi-calendar\"></i>\r\n                          {{ task.dueDate | date: 'MMM d' }}\r\n                        </span>\r\n                      }\r\n\r\n                      @if (task.pinned) {\r\n                        <i class=\"pi pi-bookmark-fill taskboard-card-advanced-pin\"></i>\r\n                      }\r\n                      @if (task.favorite) {\r\n                        <i class=\"pi pi-star-fill taskboard-card-advanced-star\"></i>\r\n                      }\r\n                    </div>\r\n\r\n                    @if (assignees(task); as people) {\r\n                      @if (people.length) {\r\n                        <p-avatar\r\n                          [label]=\"people[0]!.avatar\"\r\n                          shape=\"circle\"\r\n                          styleClass=\"taskboard-card-advanced-avatar\"\r\n                          [pTooltip]=\"people[0]!.name\"\r\n                        />\r\n                      }\r\n                    }\r\n                  </div>\r\n                </div>\r\n              }\r\n            </div>\r\n\r\n            <div data-scope=\"taskboard\" data-part=\"card-add\" class=\"p-taskboard-card-add\">\r\n              <button type=\"button\" class=\"taskboard-add-card-btn\" (click)=\"addCard(col.id)\">\r\n                <i class=\"pi pi-plus\"></i>\r\n                {{ label('addCard') }}\r\n              </button>\r\n            </div>\r\n          }\r\n        </div>\r\n      }\r\n    </div>\r\n\r\n      <div class=\"taskboard-add-list\">\r\n        @if (!addingList()) {\r\n          <button\r\n            type=\"button\"\r\n            data-testid=\"trello-add-list\"\r\n            class=\"taskboard-add-list-btn\"\r\n            (click)=\"startAddList()\"\r\n          >\r\n            <i class=\"pi pi-plus\"></i>\r\n            {{ label('addList') }}\r\n          </button>\r\n        } @else {\r\n          <div class=\"taskboard-add-list-form\">\r\n            <input\r\n              type=\"text\"\r\n              class=\"taskboard-add-list-input\"\r\n              [placeholder]=\"label('newList')\"\r\n              [ngModel]=\"newListTitle()\"\r\n              (ngModelChange)=\"newListTitle.set($event)\"\r\n              (keydown.enter)=\"confirmAddList()\"\r\n              (keydown.escape)=\"cancelAddList()\"\r\n            />\r\n            <div class=\"taskboard-add-list-actions\">\r\n              <button type=\"button\" class=\"taskboard-add-list-confirm\" (click)=\"confirmAddList()\">\r\n                {{ label('addList') }}\r\n              </button>\r\n              <button type=\"button\" class=\"taskboard-add-list-cancel\" (click)=\"cancelAddList()\">\r\n                <i class=\"pi pi-times\"></i>\r\n              </button>\r\n            </div>\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<p-contextMenu #cm [model]=\"contextItems\" />\r\n<p-contextMenu #colCm [model]=\"columnMenuItems\" />\r\n", styles: [":host{--tw-surface: var(--p-content-background, var(--p-surface-100, #f1f5f9));--tw-surface-card: var(--p-surface-0, #ffffff);--tw-surface-ground: var(--p-surface-50, #f8fafb);--tw-border: var(--p-content-border-color, var(--p-surface-200, #e2e8f0));--tw-text: var(--p-text-color, #0f172a);--tw-muted: var(--p-text-muted-color, #64748b);--tw-accent: var(--p-primary-color, #0f766e);--tw-accent-contrast: var(--p-primary-contrast-color, #ffffff);--tw-accent-soft: var(--p-primary-100, var(--p-primary-50, #ccfbf1));--tw-danger: var(--p-red-500, #dc2626);--tw-danger-border: var(--p-red-300, #fca5a5);--tw-warning: var(--p-orange-500, #ea580c);--tw-warning-soft: var(--p-orange-100, #ffedd5);--tw-highlight: var(--p-highlight-background, var(--p-primary-50, #f0fdfa));--tw-tag-bg: var(--p-surface-100, #f1f5f9);--tw-tag-fg: var(--p-surface-600, #475569);display:block;height:100%;min-height:0;overflow:hidden}.p-taskboard{--p-taskboard-column-min-width: 17rem;--p-taskboard-column-max-width: 17rem;--p-taskboard-columns-padding: .5rem;--p-taskboard-column-gap: .5rem;--p-taskboard-column-body-padding: .375rem;--p-taskboard-card-gap: .375rem;height:100%;min-height:0;overflow:hidden;outline:none}.p-taskboard-body{height:100%;min-height:0;overflow:hidden}.p-taskboard-columns-row{display:flex;flex-wrap:nowrap;align-items:stretch;gap:var(--p-taskboard-column-gap);padding:var(--p-taskboard-columns-padding);overflow-x:auto;overflow-y:hidden;height:100%;min-height:0;box-sizing:border-box;scrollbar-width:none;-ms-overflow-style:none}.p-taskboard-columns-row::-webkit-scrollbar{display:none;width:0;height:0}.p-taskboard-columns{display:flex;flex:0 0 auto;align-items:stretch;gap:var(--p-taskboard-column-gap);height:100%;min-height:0;width:max-content;min-width:max-content}.p-taskboard-column{display:flex;flex-direction:column;min-width:var(--p-taskboard-column-min-width);max-width:var(--p-taskboard-column-max-width);width:var(--p-taskboard-column-min-width);height:100%;max-height:100%;min-height:0;overflow:hidden;background:color-mix(in srgb,var(--tw-surface) 88%,transparent);border:1px solid var(--tw-border);border-radius:.75rem;flex-shrink:0}.p-taskboard-column.wip-over{border-color:var(--tw-danger-border);box-shadow:0 0 0 1px color-mix(in srgb,var(--tw-danger) 20%,transparent)}.p-taskboard-column.collapsed{--p-taskboard-collapsed-width: 2.75rem;min-width:var(--p-taskboard-collapsed-width);max-width:var(--p-taskboard-collapsed-width);width:var(--p-taskboard-collapsed-width);max-height:100%;align-self:stretch;height:100%}.taskboard-column-drag-grip{font-size:.7rem;color:var(--tw-muted);cursor:grab;flex-shrink:0}.taskboard-column-header-left[cdkDragHandle],.taskboard-column-collapsed-rail[cdkDragHandle]{cursor:grab}.taskboard-column-collapsed-rail{width:100%;height:100%;min-height:12rem;padding:.65rem .2rem;display:flex;flex-direction:column;align-items:center;gap:.55rem;color:var(--tw-muted);border-radius:.65rem;transition:background .15s ease,color .15s ease}.taskboard-column-collapsed-rail:hover{background:color-mix(in srgb,var(--tw-border) 55%,transparent);color:var(--tw-text)}.taskboard-column-collapsed-expand{border:0;background:transparent;cursor:pointer;padding:.15rem;color:inherit;line-height:1;display:grid;place-items:center;border-radius:.3rem}.taskboard-column-collapsed-expand .taskboard-column-header-chevron{font-size:.85rem;flex-shrink:0}.taskboard-column-collapsed-expand:hover{background:color-mix(in srgb,var(--tw-border) 70%,transparent)}.taskboard-column-collapsed-title{writing-mode:vertical-rl;transform:rotate(180deg);font-size:.75rem;font-weight:600;letter-spacing:.02em;white-space:nowrap;max-height:10rem;overflow:hidden;text-overflow:ellipsis;color:inherit}.taskboard-column-collapsed-count{font-size:.65rem;font-weight:700;flex-shrink:0;min-width:1.15rem;height:1.15rem;border-radius:999px;display:grid;place-items:center;background:color-mix(in srgb,var(--tw-border) 80%,transparent);color:var(--tw-text)}.p-taskboard-column-header{display:block;flex-shrink:0}.p-taskboard-column.collapsed .p-taskboard-column-header{flex:1;display:flex;min-height:0}.taskboard-column-header-content{display:flex;align-items:center;justify-content:space-between;gap:.35rem;padding:.55rem .65rem .35rem}.taskboard-column-header-left{display:flex;align-items:center;gap:.4rem;min-width:0;flex-wrap:wrap}.taskboard-column-header-title{font-weight:600;font-size:.875rem;color:var(--tw-text)}.taskboard-column-header-wip{font-size:.7rem;font-weight:600;color:var(--tw-accent)}.taskboard-column-header-wip.bad{color:var(--tw-danger)}.taskboard-column-header-actions{display:inline-flex;align-items:center;gap:.1rem;flex-shrink:0}.taskboard-column-header-menu,.taskboard-column-header-collapse-toggle{border:0;background:transparent;cursor:pointer;padding:.2rem;color:var(--tw-muted);border-radius:.35rem;line-height:1;display:grid;place-items:center;width:1.5rem;height:1.5rem}.taskboard-column-header-menu:hover,.taskboard-column-header-collapse-toggle:hover{background:color-mix(in srgb,var(--tw-border) 60%,transparent);color:var(--tw-text)}.taskboard-column-header-menu i,.taskboard-column-header-collapse-toggle i{font-size:.75rem}.taskboard-column-header-chevron{font-size:.7rem}.p-taskboard-column-body{display:flex;flex-direction:column;gap:var(--p-taskboard-card-gap);padding:var(--p-taskboard-column-body-padding);overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;flex:1 1 0;min-height:0;scrollbar-width:none;-ms-overflow-style:none}.p-taskboard-column-body::-webkit-scrollbar{display:none;width:0;height:0}:host.taskboard-dragging .p-taskboard-columns-row,:host.taskboard-dragging .p-taskboard-column-body{overflow:hidden!important}.p-taskboard-card{background:var(--tw-surface-card);border:1px solid var(--tw-border);border-radius:.5rem;padding:.55rem .6rem .5rem;cursor:grab;position:relative;box-shadow:0 1px 2px #0f172a0a;transition:box-shadow .15s ease,border-color .15s ease}.p-taskboard-card:hover{box-shadow:0 4px 12px #0f172a14}.p-taskboard-card-selected{border-color:color-mix(in srgb,var(--tw-accent) 55%,var(--tw-surface-card));box-shadow:0 0 0 1px color-mix(in srgb,var(--tw-accent) 35%,transparent)}.taskboard-card-advanced{display:flex;flex-direction:column;gap:.35rem;padding-right:1.75rem}.taskboard-card-advanced-tags{display:flex;flex-wrap:wrap;gap:.25rem}.taskboard-card-advanced-tag{font-size:.65rem;font-weight:500;padding:.1rem .4rem;border-radius:.3rem;background:var(--tw-tag-bg);color:var(--tw-tag-fg)}.taskboard-card-advanced-title{font-size:.8125rem;font-weight:600;line-height:1.35;color:var(--tw-text)}.taskboard-card-advanced-badges{display:flex;flex-wrap:wrap;align-items:center;gap:.35rem;font-size:.7rem;color:var(--tw-muted)}.taskboard-card-advanced-priority{font-weight:700;font-size:.65rem;padding:.1rem .35rem;border-radius:.25rem;letter-spacing:.02em}.taskboard-card-advanced-priority[data-priority=urgent]{background:var(--p-red-200, #fecaca);color:var(--p-red-800, #991b1b)}.taskboard-card-advanced-priority[data-priority=high]{background:var(--p-orange-200, #fed7aa);color:var(--p-orange-800, #9a3412)}.taskboard-card-advanced-priority[data-priority=medium]{background:var(--p-blue-200, #bfdbfe);color:var(--p-blue-800, #1e40af)}.taskboard-card-advanced-priority[data-priority=low]{background:var(--tw-tag-bg);color:var(--tw-tag-fg)}.taskboard-card-advanced-subtasks,.taskboard-card-advanced-due,.taskboard-card-advanced-desc-icon{display:inline-flex;align-items:center;gap:.2rem}.taskboard-card-advanced-subtasks .pi,.taskboard-card-advanced-due .pi,.taskboard-card-advanced-desc-icon .pi{font-size:.65rem}.taskboard-card-advanced-due-overdue{color:var(--tw-danger);font-weight:600}.taskboard-card-advanced-pin{color:var(--tw-muted);font-size:.7rem}.taskboard-card-advanced-star{color:var(--p-yellow-600, #ca8a04);font-size:.7rem}:host ::ng-deep .taskboard-card-advanced-avatar{position:absolute;right:.45rem;bottom:.4rem;width:1.5rem!important;height:1.5rem!important;font-size:.6rem!important;background:var(--p-primary-500, var(--tw-accent));color:var(--tw-accent-contrast)}.p-taskboard-card-add{flex:0 0 auto;flex-shrink:0;padding:.25rem .35rem .4rem;background:color-mix(in srgb,var(--tw-surface) 96%,var(--tw-surface-card));border-top:1px solid var(--tw-border);position:relative;z-index:1}.taskboard-add-card-btn{width:100%;border:0;background:transparent;color:var(--tw-muted);padding:.5rem;font-size:.8125rem;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:.25rem;border-radius:.4rem;transition:color .15s ease,background .15s ease}.taskboard-add-card-btn:hover{color:var(--tw-accent);background:color-mix(in srgb,var(--tw-surface-card) 70%,transparent)}.p-taskboard-column.cdk-drag-preview{box-sizing:border-box;border-radius:.75rem;box-shadow:0 12px 28px #0f172a2e;height:auto;max-height:min(80vh,36rem);overflow:hidden}.p-taskboard-column.cdk-drag-placeholder{min-height:8rem;opacity:.45;background:color-mix(in srgb,var(--tw-border) 45%,transparent);border:1px dashed var(--tw-border)}.taskboard-add-list{flex:0 0 auto;width:var(--p-taskboard-column-min-width);min-width:var(--p-taskboard-column-min-width);max-width:var(--p-taskboard-column-max-width);height:auto;align-self:flex-start;position:relative;z-index:0}.taskboard-add-list-btn{width:100%;border:1px dashed var(--tw-border);background:transparent;border-radius:.75rem;padding:.75rem 1rem;font-size:.8125rem;color:var(--tw-muted);cursor:pointer;display:flex;align-items:center;gap:.5rem;transition:background .15s ease,color .15s ease}.taskboard-add-list-btn:hover{background:color-mix(in srgb,var(--tw-surface) 90%,transparent);color:var(--tw-text)}.taskboard-add-list-form{background:color-mix(in srgb,var(--tw-surface) 88%,transparent);border:1px solid var(--tw-border);border-radius:.75rem;padding:.55rem;display:flex;flex-direction:column;gap:.45rem}.taskboard-add-list-input{width:100%;border:1px solid var(--tw-border);border-radius:.4rem;padding:.45rem .55rem;font-size:.8125rem;outline:none}.taskboard-add-list-input:focus{border-color:var(--tw-accent)}.taskboard-add-list-actions{display:flex;align-items:center;gap:.35rem}.taskboard-add-list-confirm{border:0;background:var(--tw-accent);color:var(--tw-accent-contrast);border-radius:.4rem;padding:.4rem .65rem;font-size:.75rem;cursor:pointer}.taskboard-add-list-cancel{border:0;background:transparent;color:var(--tw-muted);cursor:pointer;padding:.35rem}.cdk-drag-preview{box-sizing:border-box;border-radius:.5rem;box-shadow:0 12px 28px #0f172a2e;overflow:hidden!important;pointer-events:none;z-index:1000}.cdk-drag-placeholder{opacity:.35}.cdk-drop-list-dragging .p-taskboard-card:not(.cdk-drag-placeholder){transition:transform .2s ease}\n"] }]
        }], propDecorators: { hostDragging: [{
                type: HostBinding,
                args: ['class.taskboard-dragging']
            }] } });

class TaskSchedulerComponent {
    facade = inject(TaskWorkspaceFacade);
    labels = inject(TASK_LABELS);
    /** Required — create / mutations stay scoped to the host-declared space. */
    spaceId = input.required();
    tasks = input.required();
    taskOpen = output();
    createAt = output();
    view = signal('month');
    cursor = signal(new Date());
    expandedDayKey = signal(null);
    taskMenuItems = [];
    weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    viewOptions = computed(() => [
        { label: this.labels.month, value: 'month' },
        { label: this.labels.week, value: 'week' },
        { label: this.labels.day, value: 'day' },
        { label: this.labels.agenda, value: 'agenda' },
    ]);
    monthWeeks = computed(() => {
        const cells = this.buildMonth(this.cursor(), this.tasks());
        const weeks = [];
        for (let i = 0; i < cells.length; i += 7) {
            weeks.push(cells.slice(i, i + 7));
        }
        return weeks;
    });
    weekDays = computed(() => this.buildWeek(this.cursor(), this.tasks()));
    dayTasks = computed(() => this.tasksForDate(this.cursor(), this.tasks()));
    agenda = computed(() => [...this.tasks()]
        .filter((t) => t.dueDate)
        .sort((a, b) => +new Date(a.dueDate) - +new Date(b.dueDate)));
    title = computed(() => {
        const d = this.cursor();
        const v = this.view();
        if (v === 'day') {
            return d.toLocaleDateString(undefined, {
                weekday: 'long',
                month: 'long',
                day: 'numeric',
                year: 'numeric',
            });
        }
        if (v === 'week') {
            const start = new Date(d);
            start.setDate(d.getDate() - d.getDay());
            const end = new Date(start);
            end.setDate(start.getDate() + 6);
            return `${start.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} – ${end.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}`;
        }
        return d.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
    });
    connectedDayLists = computed(() => {
        if (this.view() === 'month') {
            return this.monthWeeks()
                .flat()
                .map((c) => this.dayListId(c.dateKey));
        }
        if (this.view() === 'week') {
            return this.weekDays().map((c) => this.dayListId(c.dateKey));
        }
        return [];
    });
    dayListId(dateKey) {
        return `sched-day-${dateKey}`;
    }
    visibleTasks(cell) {
        if (this.expandedDayKey() === cell.dateKey)
            return cell.tasks;
        return cell.tasks.slice(0, 3);
    }
    moreCount(cell) {
        if (this.expandedDayKey() === cell.dateKey)
            return 0;
        return Math.max(0, cell.tasks.length - 3);
    }
    toggleMore(cell, event) {
        event.stopPropagation();
        this.expandedDayKey.update((k) => (k === cell.dateKey ? null : cell.dateKey));
    }
    prev() {
        const d = new Date(this.cursor());
        if (this.view() === 'month')
            d.setMonth(d.getMonth() - 1);
        else if (this.view() === 'week')
            d.setDate(d.getDate() - 7);
        else
            d.setDate(d.getDate() - 1);
        this.cursor.set(d);
    }
    next() {
        const d = new Date(this.cursor());
        if (this.view() === 'month')
            d.setMonth(d.getMonth() + 1);
        else if (this.view() === 'week')
            d.setDate(d.getDate() + 7);
        else
            d.setDate(d.getDate() + 1);
        this.cursor.set(d);
    }
    today() {
        this.cursor.set(new Date());
    }
    setView(value) {
        this.view.set(value);
        this.expandedDayKey.set(null);
    }
    openTask(id, event) {
        event?.stopPropagation();
        this.taskOpen.emit(id);
    }
    addOnDay(date, event) {
        event?.stopPropagation();
        this.createAt.emit(date);
    }
    dropTask(event, targetDate) {
        if (event.previousContainer === event.container)
            return;
        const task = event.item.data ?? event.previousContainer.data[event.previousIndex];
        if (!task)
            return;
        const iso = this.dateToIsoKeepTime(targetDate, task.dueDate);
        this.facade.updateTask(task.id, {
            dueDate: iso,
            scheduleStart: iso,
            scheduleEnd: iso,
        });
    }
    openTaskMenu(event, task, menu) {
        event.stopPropagation();
        event.preventDefault();
        this.taskMenuItems = [
            {
                label: this.labels.open,
                icon: 'pi pi-eye',
                command: () => this.openTask(task.id),
            },
            {
                label: this.labels.delete,
                icon: 'pi pi-trash',
                command: () => this.facade.deleteTask(task.id),
            },
        ];
        menu.show(event);
    }
    accentFor(task) {
        const map = {
            urgent: 'rgb(220, 38, 38)',
            high: 'rgb(234, 88, 12)',
            medium: 'rgb(37, 99, 235)',
            low: 'rgb(100, 116, 139)',
        };
        return map[task.priority] ?? map['medium'];
    }
    holidayFor(date) {
        return this.facade.isHoliday(date);
    }
    label(key) {
        return this.labels[key];
    }
    dateToIsoKeepTime(day, previousIso) {
        const d = new Date(day);
        if (previousIso) {
            const prev = new Date(previousIso);
            d.setHours(prev.getHours(), prev.getMinutes(), prev.getSeconds(), 0);
        }
        else {
            d.setHours(10, 0, 0, 0);
        }
        return d.toISOString();
    }
    tasksForDate(date, tasks) {
        const key = this.facade.dateKey(date);
        return tasks.filter((t) => t.dueDate && this.facade.dateKey(new Date(t.dueDate)) === key);
    }
    /** Sunday-first month grid (6 weeks). */
    buildMonth(cursor, tasks) {
        const year = cursor.getFullYear();
        const month = cursor.getMonth();
        const first = new Date(year, month, 1);
        const start = new Date(first);
        start.setDate(first.getDate() - first.getDay());
        const todayKey = this.facade.dateKey(new Date());
        const cells = [];
        for (let i = 0; i < 42; i++) {
            const date = new Date(start);
            date.setDate(start.getDate() + i);
            cells.push(this.toCell(date, date.getMonth() === month, todayKey, tasks));
        }
        return cells;
    }
    buildWeek(cursor, tasks) {
        const start = new Date(cursor);
        start.setDate(cursor.getDate() - cursor.getDay());
        const todayKey = this.facade.dateKey(new Date());
        return Array.from({ length: 7 }, (_, i) => {
            const date = new Date(start);
            date.setDate(start.getDate() + i);
            return this.toCell(date, true, todayKey, tasks);
        });
    }
    toCell(date, inMonth, todayKey, tasks) {
        const holiday = this.facade.isHoliday(date);
        const dow = date.getDay();
        return {
            date,
            dateKey: this.facade.dateKey(date),
            inMonth,
            isToday: this.facade.dateKey(date) === todayKey,
            isWeekend: dow === 0 || dow === 6,
            holidayName: holiday?.name,
            tasks: this.tasksForDate(date, tasks),
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: TaskSchedulerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: TaskSchedulerComponent, isStandalone: true, selector: "tw-task-scheduler", inputs: { spaceId: { classPropertyName: "spaceId", publicName: "spaceId", isSignal: true, isRequired: true, transformFunction: null }, tasks: { classPropertyName: "tasks", publicName: "tasks", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { taskOpen: "taskOpen", createAt: "createAt" }, ngImport: i0, template: "<div class=\"p-scheduler\">\r\n  <div class=\"p-scheduler-header\">\r\n    <div class=\"p-scheduler-toolbar\">\r\n      <div class=\"p-scheduler-toolbar-start\">\r\n        <div class=\"p-scheduler-nav\">\r\n          <button\r\n            type=\"button\"\r\n            class=\"p-scheduler-nav-button p-button-text p-button-rounded\"\r\n            pButton\r\n            icon=\"pi pi-chevron-left\"\r\n            (click)=\"prev()\"\r\n            [attr.aria-label]=\"'Previous'\"\r\n          ></button>\r\n          <button\r\n            type=\"button\"\r\n            class=\"p-scheduler-nav-button p-button-text p-button-rounded\"\r\n            pButton\r\n            icon=\"pi pi-chevron-right\"\r\n            (click)=\"next()\"\r\n            [attr.aria-label]=\"'Next'\"\r\n          ></button>\r\n          <button\r\n            type=\"button\"\r\n            class=\"p-scheduler-today-button p-button-outlined p-button-sm\"\r\n            pButton\r\n            [label]=\"label('today')\"\r\n            (click)=\"today()\"\r\n          ></button>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"p-scheduler-toolbar-center\">\r\n        <h2 class=\"p-scheduler-title\">{{ title() }}</h2>\r\n      </div>\r\n\r\n      <div class=\"p-scheduler-toolbar-end\">\r\n        <p-select\r\n          class=\"p-scheduler-view-select\"\r\n          [options]=\"viewOptions()\"\r\n          [ngModel]=\"view()\"\r\n          (ngModelChange)=\"setView($event)\"\r\n          optionLabel=\"label\"\r\n          optionValue=\"value\"\r\n          [style]=\"{ minWidth: '8.5rem' }\"\r\n        />\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"p-scheduler-body\">\r\n    @if (view() === 'month') {\r\n      <div class=\"p-scheduler-month-view\">\r\n        <div class=\"p-scheduler-weekdays\">\r\n          @for (dow of weekdays; track dow) {\r\n            <div class=\"p-scheduler-weekday\">{{ dow }}</div>\r\n          }\r\n        </div>\r\n\r\n        <div class=\"p-scheduler-weeks\">\r\n          @for (week of monthWeeks(); track $index) {\r\n            <div class=\"p-scheduler-week\">\r\n              @for (cell of week; track cell.dateKey) {\r\n                <div\r\n                  class=\"p-scheduler-day\"\r\n                  [attr.data-date]=\"cell.dateKey\"\r\n                  [class.p-scheduler-day-other-month]=\"!cell.inMonth\"\r\n                  [class.p-scheduler-day-today]=\"cell.isToday\"\r\n                  [class.p-scheduler-day-weekend]=\"cell.isWeekend\"\r\n                  [class.p-scheduler-day-holiday]=\"!!cell.holidayName\"\r\n                >\r\n                  <div class=\"p-scheduler-day-header\">\r\n                    <span class=\"p-scheduler-day-number\" [class.p-scheduler-day-number-today]=\"cell.isToday\">\r\n                      {{ cell.date | date: 'd' }}\r\n                    </span>\r\n                    @if (cell.holidayName) {\r\n                      <span class=\"p-scheduler-day-holiday-label\" [title]=\"cell.holidayName\">{{ cell.holidayName }}</span>\r\n                    }\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"p-scheduler-day-add\"\r\n                      [attr.aria-label]=\"label('addTask')\"\r\n                      [title]=\"label('addTask')\"\r\n                      (click)=\"addOnDay(cell.date, $event)\"\r\n                    >\r\n                      <i class=\"pi pi-plus\"></i>\r\n                    </button>\r\n                  </div>\r\n\r\n                  <div\r\n                    class=\"p-scheduler-day-events\"\r\n                    cdkDropList\r\n                    [id]=\"dayListId(cell.dateKey)\"\r\n                    [cdkDropListData]=\"cell.tasks\"\r\n                    [cdkDropListConnectedTo]=\"connectedDayLists()\"\r\n                    (cdkDropListDropped)=\"dropTask($event, cell.date)\"\r\n                  >\r\n                    @for (task of visibleTasks(cell); track task.id) {\r\n                      <div\r\n                        class=\"p-scheduler-event\"\r\n                        cdkDrag\r\n                        [cdkDragData]=\"task\"\r\n                        [style.--event-accent]=\"accentFor(task)\"\r\n                        (click)=\"openTask(task.id, $event)\"\r\n                      >\r\n                        <div class=\"p-scheduler-event-drag-preview\" *cdkDragPreview>\r\n                          <span class=\"p-scheduler-event-title\">{{ task.title }}</span>\r\n                        </div>\r\n                        <div class=\"p-scheduler-event-placeholder\" *cdkDragPlaceholder></div>\r\n                        <span class=\"p-scheduler-event-dot\"></span>\r\n                        <span class=\"p-scheduler-event-title\">{{ task.title }}</span>\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"p-scheduler-event-menu\"\r\n                          (click)=\"openTaskMenu($event, task, taskCm)\"\r\n                          [attr.aria-label]=\"label('actions')\"\r\n                        >\r\n                          <i class=\"pi pi-ellipsis-v\"></i>\r\n                        </button>\r\n                      </div>\r\n                    }\r\n                    @if (moreCount(cell) > 0) {\r\n                      <button type=\"button\" class=\"p-scheduler-more-link\" (click)=\"toggleMore(cell, $event)\">\r\n                        +{{ moreCount(cell) }} more\r\n                      </button>\r\n                    }\r\n                  </div>\r\n                </div>\r\n              }\r\n            </div>\r\n          }\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (view() === 'week') {\r\n      <div class=\"p-scheduler-week-view\">\r\n        <div class=\"p-scheduler-weekdays\">\r\n          @for (dow of weekdays; track dow) {\r\n            <div class=\"p-scheduler-weekday\">{{ dow }}</div>\r\n          }\r\n        </div>\r\n        <div class=\"p-scheduler-week p-scheduler-week-expanded\">\r\n          @for (cell of weekDays(); track cell.dateKey) {\r\n            <div\r\n              class=\"p-scheduler-day\"\r\n              [attr.data-date]=\"cell.dateKey\"\r\n              [class.p-scheduler-day-today]=\"cell.isToday\"\r\n              [class.p-scheduler-day-weekend]=\"cell.isWeekend\"\r\n              [class.p-scheduler-day-holiday]=\"!!cell.holidayName\"\r\n            >\r\n              <div class=\"p-scheduler-day-header\">\r\n                <span class=\"p-scheduler-day-number\" [class.p-scheduler-day-number-today]=\"cell.isToday\">\r\n                  {{ cell.date | date: 'd' }}\r\n                </span>\r\n                @if (cell.holidayName) {\r\n                  <span class=\"p-scheduler-day-holiday-label\">{{ cell.holidayName }}</span>\r\n                }\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"p-scheduler-day-add\"\r\n                  [title]=\"label('addTask')\"\r\n                  (click)=\"addOnDay(cell.date, $event)\"\r\n                >\r\n                  <i class=\"pi pi-plus\"></i>\r\n                </button>\r\n              </div>\r\n              <div\r\n                class=\"p-scheduler-day-events\"\r\n                cdkDropList\r\n                [id]=\"dayListId(cell.dateKey)\"\r\n                [cdkDropListData]=\"cell.tasks\"\r\n                [cdkDropListConnectedTo]=\"connectedDayLists()\"\r\n                (cdkDropListDropped)=\"dropTask($event, cell.date)\"\r\n              >\r\n                @for (task of cell.tasks; track task.id) {\r\n                  <div\r\n                    class=\"p-scheduler-event\"\r\n                    cdkDrag\r\n                    [cdkDragData]=\"task\"\r\n                    [style.--event-accent]=\"accentFor(task)\"\r\n                    (click)=\"openTask(task.id, $event)\"\r\n                  >\r\n                    <span class=\"p-scheduler-event-dot\"></span>\r\n                    <span class=\"p-scheduler-event-title\">{{ task.title }}</span>\r\n                    <button type=\"button\" class=\"p-scheduler-event-menu\" (click)=\"openTaskMenu($event, task, taskCm)\">\r\n                      <i class=\"pi pi-ellipsis-v\"></i>\r\n                    </button>\r\n                  </div>\r\n                }\r\n              </div>\r\n            </div>\r\n          }\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (view() === 'day') {\r\n      <div class=\"p-scheduler-day-view\">\r\n        @if (holidayFor(cursor()); as hol) {\r\n          <div class=\"p-scheduler-holiday-banner\">{{ hol.name }}</div>\r\n        }\r\n        <div class=\"p-scheduler-day-view-actions\">\r\n          <button\r\n            type=\"button\"\r\n            class=\"p-button-sm\"\r\n            pButton\r\n            icon=\"pi pi-plus\"\r\n            [label]=\"label('addTask')\"\r\n            (click)=\"addOnDay(cursor())\"\r\n          ></button>\r\n        </div>\r\n        <div class=\"p-scheduler-day-events p-scheduler-day-events-stack\">\r\n          @for (task of dayTasks(); track task.id) {\r\n            <div\r\n              class=\"p-scheduler-event p-scheduler-event-large\"\r\n              [style.--event-accent]=\"accentFor(task)\"\r\n              (click)=\"openTask(task.id, $event)\"\r\n            >\r\n              <span class=\"p-scheduler-event-dot\"></span>\r\n              <span class=\"p-scheduler-event-title\">{{ task.title }}</span>\r\n              <span class=\"p-scheduler-event-time\">{{ task.dueDate | date: 'shortTime' }}</span>\r\n              <button type=\"button\" class=\"p-scheduler-event-menu\" (click)=\"openTaskMenu($event, task, taskCm)\">\r\n                <i class=\"pi pi-ellipsis-v\"></i>\r\n              </button>\r\n            </div>\r\n          } @empty {\r\n            <p class=\"p-scheduler-empty\">{{ label('noTasks') }}</p>\r\n          }\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (view() === 'agenda') {\r\n      <div class=\"p-scheduler-agenda-view\">\r\n        @for (task of agenda(); track task.id) {\r\n          <button type=\"button\" class=\"p-scheduler-agenda-row\" (click)=\"openTask(task.id)\">\r\n            <span class=\"p-scheduler-agenda-when\">{{ task.dueDate | date: 'mediumDate' }}</span>\r\n            <span class=\"p-scheduler-agenda-what\">\r\n              <span class=\"p-scheduler-event-dot\" [style.background]=\"accentFor(task)\"></span>\r\n              {{ task.title }}\r\n            </span>\r\n          </button>\r\n        } @empty {\r\n          <p class=\"p-scheduler-empty\">{{ label('noTasks') }}</p>\r\n        }\r\n      </div>\r\n    }\r\n  </div>\r\n</div>\r\n\r\n<p-contextMenu #taskCm [model]=\"taskMenuItems\" appendTo=\"body\" />\r\n", styles: ["@charset \"UTF-8\";:host{--tw-surface: var(--p-content-background, var(--p-surface-100, #f1f5f9));--tw-surface-card: var(--p-surface-0, #ffffff);--tw-surface-ground: var(--p-surface-50, #f8fafb);--tw-border: var(--p-content-border-color, var(--p-surface-200, #e2e8f0));--tw-text: var(--p-text-color, #0f172a);--tw-muted: var(--p-text-muted-color, #64748b);--tw-accent: var(--p-primary-color, #0f766e);--tw-accent-contrast: var(--p-primary-contrast-color, #ffffff);--tw-accent-soft: var(--p-primary-100, var(--p-primary-50, #ccfbf1));--tw-danger: var(--p-red-500, #dc2626);--tw-danger-border: var(--p-red-300, #fca5a5);--tw-warning: var(--p-orange-500, #ea580c);--tw-warning-soft: var(--p-orange-100, #ffedd5);--tw-highlight: var(--p-highlight-background, var(--p-primary-50, #f0fdfa));--tw-tag-bg: var(--p-surface-100, #f1f5f9);--tw-tag-fg: var(--p-surface-600, #475569);display:block;height:100%;min-height:0}.p-scheduler{display:flex;flex-direction:column;height:100%;min-height:0;background:var(--tw-surface-card);border:1px solid var(--tw-border);border-radius:12px;overflow:hidden}.p-scheduler-header{flex:0 0 auto;border-bottom:1px solid var(--tw-border);background:var(--tw-surface)}.p-scheduler-toolbar{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:.75rem;padding:.65rem .85rem}.p-scheduler-toolbar-start{justify-self:start}.p-scheduler-toolbar-center{justify-self:center;text-align:center}.p-scheduler-toolbar-end{justify-self:end}.p-scheduler-nav{display:flex;align-items:center;gap:.25rem}.p-scheduler-today-button{margin-left:.35rem}.p-scheduler-title{margin:0;font-size:1.05rem;font-weight:700;color:var(--tw-text);white-space:nowrap}.p-scheduler-body{flex:1 1 auto;min-height:0;overflow-x:hidden;overflow-y:scroll;overscroll-behavior:contain;scrollbar-gutter:stable;scrollbar-width:auto;scrollbar-color:var(--tw-muted) var(--tw-border)}.p-scheduler-body::-webkit-scrollbar{width:10px}.p-scheduler-body::-webkit-scrollbar-thumb{background:var(--tw-muted);border-radius:6px;border:2px solid var(--tw-border)}.p-scheduler-body::-webkit-scrollbar-track{background:var(--tw-border)}.p-scheduler-month-view,.p-scheduler-week-view{display:flex;flex-direction:column;min-height:100%}.p-scheduler-weekdays{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));border-bottom:1px solid var(--tw-border);background:var(--tw-surface-ground);position:sticky;top:0;z-index:2}.p-scheduler-weekday{padding:.55rem .35rem;text-align:center;font-size:.75rem;font-weight:700;color:var(--tw-muted);text-transform:uppercase;letter-spacing:.02em}.p-scheduler-weeks{display:flex;flex-direction:column;flex:1 1 auto;min-height:51rem}.p-scheduler-week{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));flex:1 1 0;min-height:8.5rem;border-bottom:1px solid var(--tw-border)}.p-scheduler-week:last-child{border-bottom:0}.p-scheduler-week-expanded{flex:1 1 auto;min-height:22rem}.p-scheduler-day{position:relative;display:flex;flex-direction:column;min-width:0;min-height:0;padding:.3rem;border-right:1px solid var(--tw-border);background:var(--tw-surface-card)}.p-scheduler-day:last-child{border-right:0}.p-scheduler-day.p-scheduler-day-other-month{background:var(--tw-surface-ground);color:var(--tw-muted)}.p-scheduler-day.p-scheduler-day-other-month .p-scheduler-day-number{color:var(--tw-muted)}.p-scheduler-day.p-scheduler-day-today{background:var(--tw-highlight)}.p-scheduler-day.p-scheduler-day-holiday{background:var(--tw-warning-soft)}.p-scheduler-day.p-scheduler-day-weekend:not(.p-scheduler-day-today):not(.p-scheduler-day-holiday){background:var(--tw-surface-ground)}.p-scheduler-day:hover .p-scheduler-day-add{opacity:1}.p-scheduler-day-header{display:flex;align-items:center;gap:.25rem;margin-bottom:.2rem;min-height:1.5rem}.p-scheduler-day-number{font-size:.8rem;font-weight:700;line-height:1.4;width:1.5rem;height:1.5rem;display:inline-flex;align-items:center;justify-content:center;border-radius:999px}.p-scheduler-day-number.p-scheduler-day-number-today{background:var(--tw-accent);color:var(--tw-accent-contrast)}.p-scheduler-day-holiday-label{flex:1 1 auto;min-width:0;font-size:.62rem;font-weight:600;color:var(--tw-warning);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.p-scheduler-day-add{margin-left:auto;flex:0 0 auto;width:1.35rem;height:1.35rem;border:0;border-radius:6px;background:transparent;color:var(--tw-muted);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;opacity:.45;transition:opacity .12s ease,background .12s ease,color .12s ease}.p-scheduler-day-add:hover{opacity:1;background:var(--tw-accent-soft);color:var(--tw-accent)}.p-scheduler-day-add i{font-size:.7rem}.p-scheduler-day-events{display:flex;flex-direction:column;gap:.15rem;flex:1 1 auto;min-height:0;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:var(--tw-muted) transparent}.p-scheduler-day-events.cdk-drop-list-dragging .p-scheduler-event:not(.cdk-drag-placeholder){transition:transform .15s ease}.p-scheduler-day-events::-webkit-scrollbar{width:6px}.p-scheduler-day-events::-webkit-scrollbar-thumb{background:var(--tw-muted);border-radius:999px}.p-scheduler-day-events::-webkit-scrollbar-track{background:transparent}.p-scheduler-day-events-stack{overflow:auto;gap:.4rem;max-height:100%}.p-scheduler-event{--event-accent: rgb(37, 99, 235);position:relative;display:flex;align-items:center;gap:.3rem;border:0;border-left:3px solid var(--event-accent);border-radius:4px;background:color-mix(in srgb,var(--event-accent) 12%,var(--tw-surface-card));color:var(--tw-text);padding:.15rem .2rem .15rem .35rem;font-size:.72rem;line-height:1.25;cursor:grab;text-align:left;min-width:0}.p-scheduler-event:active{cursor:grabbing}.p-scheduler-event.cdk-drag-animating{transition:transform .15s ease}.p-scheduler-event.p-scheduler-event-large{padding:.75rem .85rem;font-size:.9rem;cursor:pointer}.p-scheduler-event-dot{flex:0 0 auto;width:.4rem;height:.4rem;border-radius:999px;background:var(--event-accent)}.p-scheduler-event-title{flex:1 1 auto;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600}.p-scheduler-event-time{flex:0 0 auto;color:var(--tw-muted);font-size:.75rem;font-weight:500}.p-scheduler-event-menu{flex:0 0 auto;width:1.25rem;height:1.25rem;border:0;border-radius:4px;background:transparent;color:var(--tw-muted);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;opacity:.55;padding:0}.p-scheduler-event-menu i{font-size:.7rem}.p-scheduler-event-menu:hover{background:color-mix(in srgb,var(--tw-text) 6%,transparent);color:var(--tw-text);opacity:1}.p-scheduler-event:hover .p-scheduler-event-menu,.p-scheduler-event-large .p-scheduler-event-menu{opacity:1}.p-scheduler-event-drag-preview{display:flex;align-items:center;padding:.25rem .5rem;border-radius:4px;background:var(--tw-surface-card);border-left:3px solid var(--tw-accent);box-shadow:0 8px 24px #0f1c242e;font-size:.75rem;font-weight:600;max-width:12rem}.p-scheduler-event-placeholder{min-height:1.35rem;border-radius:4px;background:#0d94881f;border:1px dashed var(--tw-accent)}.p-scheduler-more-link{border:0;background:transparent;color:var(--tw-muted);font-size:.7rem;font-weight:600;text-align:left;padding:.1rem .25rem;cursor:pointer}.p-scheduler-more-link:hover{color:var(--tw-accent)}.p-scheduler-day-view,.p-scheduler-agenda-view{padding:1rem}.p-scheduler-day-view-actions{margin-bottom:.75rem}.p-scheduler-holiday-banner{padding:.65rem .85rem;background:var(--tw-warning-soft);color:var(--p-orange-800, #9a3412);border-radius:10px;font-weight:600;margin-bottom:.75rem}.p-scheduler-empty{margin:1rem 0;color:var(--tw-muted);font-size:.9rem}.p-scheduler-agenda-row{display:grid;grid-template-columns:140px 1fr;gap:1rem;width:100%;text-align:left;border:0;border-bottom:1px solid var(--tw-border);background:transparent;padding:.85rem .35rem;cursor:pointer}.p-scheduler-agenda-row:hover{background:var(--tw-surface)}.p-scheduler-agenda-when{font-weight:700;color:var(--tw-muted)}.p-scheduler-agenda-what{display:flex;align-items:center;gap:.6rem;font-weight:600}@media(max-width:900px){.p-scheduler-toolbar{grid-template-columns:1fr;justify-items:stretch}.p-scheduler-toolbar-start,.p-scheduler-toolbar-center,.p-scheduler-toolbar-end{justify-self:stretch}.p-scheduler-toolbar-end{display:flex;justify-content:flex-end}.p-scheduler-agenda-row{grid-template-columns:1fr}.p-scheduler-day-add,.p-scheduler-event-menu{opacity:1}}\n"], dependencies: [{ kind: "pipe", type: DatePipe, name: "date" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ButtonModule }, { kind: "directive", type: i2$1.ButtonDirective, selector: "[pButton]", inputs: ["iconPos", "loadingIcon", "loading", "severity", "raised", "rounded", "text", "outlined", "size", "plain", "fluid", "label", "icon", "buttonProps"] }, { kind: "ngmodule", type: SelectModule }, { kind: "component", type: i3$1.Select, selector: "p-select", inputs: ["id", "scrollHeight", "filter", "name", "style", "panelStyle", "styleClass", "panelStyleClass", "readonly", "required", "editable", "appendTo", "tabindex", "placeholder", "loadingIcon", "filterPlaceholder", "filterLocale", "variant", "inputId", "dataKey", "filterBy", "filterFields", "autofocus", "resetFilterOnHide", "checkmark", "dropdownIcon", "loading", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "autoDisplayFirst", "group", "showClear", "emptyFilterMessage", "emptyMessage", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "size", "overlayOptions", "ariaFilterLabel", "ariaLabel", "ariaLabelledBy", "filterMatchMode", "maxlength", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "focusOnHover", "selectOnFocus", "autoOptionFocus", "autofocusFilter", "fluid", "disabled", "itemSize", "autoZIndex", "baseZIndex", "showTransitionOptions", "hideTransitionOptions", "filterValue", "options"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onShow", "onHide", "onClear", "onLazyLoad"] }, { kind: "ngmodule", type: ContextMenuModule }, { kind: "component", type: i5$1.ContextMenu, selector: "p-contextMenu, p-contextmenu, p-context-menu", inputs: ["model", "triggerEvent", "target", "global", "style", "styleClass", "appendTo", "autoZIndex", "baseZIndex", "id", "breakpoint", "ariaLabel", "ariaLabelledBy", "pressDelay"], outputs: ["onShow", "onHide"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i5.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i5.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i5.CdkDragPreview, selector: "ng-template[cdkDragPreview]", inputs: ["data", "matchSize"] }, { kind: "directive", type: i5.CdkDragPlaceholder, selector: "ng-template[cdkDragPlaceholder]", inputs: ["data"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: TaskSchedulerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'tw-task-scheduler', standalone: true, imports: [DatePipe, FormsModule, ButtonModule, SelectModule, ContextMenuModule, DragDropModule], template: "<div class=\"p-scheduler\">\r\n  <div class=\"p-scheduler-header\">\r\n    <div class=\"p-scheduler-toolbar\">\r\n      <div class=\"p-scheduler-toolbar-start\">\r\n        <div class=\"p-scheduler-nav\">\r\n          <button\r\n            type=\"button\"\r\n            class=\"p-scheduler-nav-button p-button-text p-button-rounded\"\r\n            pButton\r\n            icon=\"pi pi-chevron-left\"\r\n            (click)=\"prev()\"\r\n            [attr.aria-label]=\"'Previous'\"\r\n          ></button>\r\n          <button\r\n            type=\"button\"\r\n            class=\"p-scheduler-nav-button p-button-text p-button-rounded\"\r\n            pButton\r\n            icon=\"pi pi-chevron-right\"\r\n            (click)=\"next()\"\r\n            [attr.aria-label]=\"'Next'\"\r\n          ></button>\r\n          <button\r\n            type=\"button\"\r\n            class=\"p-scheduler-today-button p-button-outlined p-button-sm\"\r\n            pButton\r\n            [label]=\"label('today')\"\r\n            (click)=\"today()\"\r\n          ></button>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"p-scheduler-toolbar-center\">\r\n        <h2 class=\"p-scheduler-title\">{{ title() }}</h2>\r\n      </div>\r\n\r\n      <div class=\"p-scheduler-toolbar-end\">\r\n        <p-select\r\n          class=\"p-scheduler-view-select\"\r\n          [options]=\"viewOptions()\"\r\n          [ngModel]=\"view()\"\r\n          (ngModelChange)=\"setView($event)\"\r\n          optionLabel=\"label\"\r\n          optionValue=\"value\"\r\n          [style]=\"{ minWidth: '8.5rem' }\"\r\n        />\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"p-scheduler-body\">\r\n    @if (view() === 'month') {\r\n      <div class=\"p-scheduler-month-view\">\r\n        <div class=\"p-scheduler-weekdays\">\r\n          @for (dow of weekdays; track dow) {\r\n            <div class=\"p-scheduler-weekday\">{{ dow }}</div>\r\n          }\r\n        </div>\r\n\r\n        <div class=\"p-scheduler-weeks\">\r\n          @for (week of monthWeeks(); track $index) {\r\n            <div class=\"p-scheduler-week\">\r\n              @for (cell of week; track cell.dateKey) {\r\n                <div\r\n                  class=\"p-scheduler-day\"\r\n                  [attr.data-date]=\"cell.dateKey\"\r\n                  [class.p-scheduler-day-other-month]=\"!cell.inMonth\"\r\n                  [class.p-scheduler-day-today]=\"cell.isToday\"\r\n                  [class.p-scheduler-day-weekend]=\"cell.isWeekend\"\r\n                  [class.p-scheduler-day-holiday]=\"!!cell.holidayName\"\r\n                >\r\n                  <div class=\"p-scheduler-day-header\">\r\n                    <span class=\"p-scheduler-day-number\" [class.p-scheduler-day-number-today]=\"cell.isToday\">\r\n                      {{ cell.date | date: 'd' }}\r\n                    </span>\r\n                    @if (cell.holidayName) {\r\n                      <span class=\"p-scheduler-day-holiday-label\" [title]=\"cell.holidayName\">{{ cell.holidayName }}</span>\r\n                    }\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"p-scheduler-day-add\"\r\n                      [attr.aria-label]=\"label('addTask')\"\r\n                      [title]=\"label('addTask')\"\r\n                      (click)=\"addOnDay(cell.date, $event)\"\r\n                    >\r\n                      <i class=\"pi pi-plus\"></i>\r\n                    </button>\r\n                  </div>\r\n\r\n                  <div\r\n                    class=\"p-scheduler-day-events\"\r\n                    cdkDropList\r\n                    [id]=\"dayListId(cell.dateKey)\"\r\n                    [cdkDropListData]=\"cell.tasks\"\r\n                    [cdkDropListConnectedTo]=\"connectedDayLists()\"\r\n                    (cdkDropListDropped)=\"dropTask($event, cell.date)\"\r\n                  >\r\n                    @for (task of visibleTasks(cell); track task.id) {\r\n                      <div\r\n                        class=\"p-scheduler-event\"\r\n                        cdkDrag\r\n                        [cdkDragData]=\"task\"\r\n                        [style.--event-accent]=\"accentFor(task)\"\r\n                        (click)=\"openTask(task.id, $event)\"\r\n                      >\r\n                        <div class=\"p-scheduler-event-drag-preview\" *cdkDragPreview>\r\n                          <span class=\"p-scheduler-event-title\">{{ task.title }}</span>\r\n                        </div>\r\n                        <div class=\"p-scheduler-event-placeholder\" *cdkDragPlaceholder></div>\r\n                        <span class=\"p-scheduler-event-dot\"></span>\r\n                        <span class=\"p-scheduler-event-title\">{{ task.title }}</span>\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"p-scheduler-event-menu\"\r\n                          (click)=\"openTaskMenu($event, task, taskCm)\"\r\n                          [attr.aria-label]=\"label('actions')\"\r\n                        >\r\n                          <i class=\"pi pi-ellipsis-v\"></i>\r\n                        </button>\r\n                      </div>\r\n                    }\r\n                    @if (moreCount(cell) > 0) {\r\n                      <button type=\"button\" class=\"p-scheduler-more-link\" (click)=\"toggleMore(cell, $event)\">\r\n                        +{{ moreCount(cell) }} more\r\n                      </button>\r\n                    }\r\n                  </div>\r\n                </div>\r\n              }\r\n            </div>\r\n          }\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (view() === 'week') {\r\n      <div class=\"p-scheduler-week-view\">\r\n        <div class=\"p-scheduler-weekdays\">\r\n          @for (dow of weekdays; track dow) {\r\n            <div class=\"p-scheduler-weekday\">{{ dow }}</div>\r\n          }\r\n        </div>\r\n        <div class=\"p-scheduler-week p-scheduler-week-expanded\">\r\n          @for (cell of weekDays(); track cell.dateKey) {\r\n            <div\r\n              class=\"p-scheduler-day\"\r\n              [attr.data-date]=\"cell.dateKey\"\r\n              [class.p-scheduler-day-today]=\"cell.isToday\"\r\n              [class.p-scheduler-day-weekend]=\"cell.isWeekend\"\r\n              [class.p-scheduler-day-holiday]=\"!!cell.holidayName\"\r\n            >\r\n              <div class=\"p-scheduler-day-header\">\r\n                <span class=\"p-scheduler-day-number\" [class.p-scheduler-day-number-today]=\"cell.isToday\">\r\n                  {{ cell.date | date: 'd' }}\r\n                </span>\r\n                @if (cell.holidayName) {\r\n                  <span class=\"p-scheduler-day-holiday-label\">{{ cell.holidayName }}</span>\r\n                }\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"p-scheduler-day-add\"\r\n                  [title]=\"label('addTask')\"\r\n                  (click)=\"addOnDay(cell.date, $event)\"\r\n                >\r\n                  <i class=\"pi pi-plus\"></i>\r\n                </button>\r\n              </div>\r\n              <div\r\n                class=\"p-scheduler-day-events\"\r\n                cdkDropList\r\n                [id]=\"dayListId(cell.dateKey)\"\r\n                [cdkDropListData]=\"cell.tasks\"\r\n                [cdkDropListConnectedTo]=\"connectedDayLists()\"\r\n                (cdkDropListDropped)=\"dropTask($event, cell.date)\"\r\n              >\r\n                @for (task of cell.tasks; track task.id) {\r\n                  <div\r\n                    class=\"p-scheduler-event\"\r\n                    cdkDrag\r\n                    [cdkDragData]=\"task\"\r\n                    [style.--event-accent]=\"accentFor(task)\"\r\n                    (click)=\"openTask(task.id, $event)\"\r\n                  >\r\n                    <span class=\"p-scheduler-event-dot\"></span>\r\n                    <span class=\"p-scheduler-event-title\">{{ task.title }}</span>\r\n                    <button type=\"button\" class=\"p-scheduler-event-menu\" (click)=\"openTaskMenu($event, task, taskCm)\">\r\n                      <i class=\"pi pi-ellipsis-v\"></i>\r\n                    </button>\r\n                  </div>\r\n                }\r\n              </div>\r\n            </div>\r\n          }\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (view() === 'day') {\r\n      <div class=\"p-scheduler-day-view\">\r\n        @if (holidayFor(cursor()); as hol) {\r\n          <div class=\"p-scheduler-holiday-banner\">{{ hol.name }}</div>\r\n        }\r\n        <div class=\"p-scheduler-day-view-actions\">\r\n          <button\r\n            type=\"button\"\r\n            class=\"p-button-sm\"\r\n            pButton\r\n            icon=\"pi pi-plus\"\r\n            [label]=\"label('addTask')\"\r\n            (click)=\"addOnDay(cursor())\"\r\n          ></button>\r\n        </div>\r\n        <div class=\"p-scheduler-day-events p-scheduler-day-events-stack\">\r\n          @for (task of dayTasks(); track task.id) {\r\n            <div\r\n              class=\"p-scheduler-event p-scheduler-event-large\"\r\n              [style.--event-accent]=\"accentFor(task)\"\r\n              (click)=\"openTask(task.id, $event)\"\r\n            >\r\n              <span class=\"p-scheduler-event-dot\"></span>\r\n              <span class=\"p-scheduler-event-title\">{{ task.title }}</span>\r\n              <span class=\"p-scheduler-event-time\">{{ task.dueDate | date: 'shortTime' }}</span>\r\n              <button type=\"button\" class=\"p-scheduler-event-menu\" (click)=\"openTaskMenu($event, task, taskCm)\">\r\n                <i class=\"pi pi-ellipsis-v\"></i>\r\n              </button>\r\n            </div>\r\n          } @empty {\r\n            <p class=\"p-scheduler-empty\">{{ label('noTasks') }}</p>\r\n          }\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (view() === 'agenda') {\r\n      <div class=\"p-scheduler-agenda-view\">\r\n        @for (task of agenda(); track task.id) {\r\n          <button type=\"button\" class=\"p-scheduler-agenda-row\" (click)=\"openTask(task.id)\">\r\n            <span class=\"p-scheduler-agenda-when\">{{ task.dueDate | date: 'mediumDate' }}</span>\r\n            <span class=\"p-scheduler-agenda-what\">\r\n              <span class=\"p-scheduler-event-dot\" [style.background]=\"accentFor(task)\"></span>\r\n              {{ task.title }}\r\n            </span>\r\n          </button>\r\n        } @empty {\r\n          <p class=\"p-scheduler-empty\">{{ label('noTasks') }}</p>\r\n        }\r\n      </div>\r\n    }\r\n  </div>\r\n</div>\r\n\r\n<p-contextMenu #taskCm [model]=\"taskMenuItems\" appendTo=\"body\" />\r\n", styles: ["@charset \"UTF-8\";:host{--tw-surface: var(--p-content-background, var(--p-surface-100, #f1f5f9));--tw-surface-card: var(--p-surface-0, #ffffff);--tw-surface-ground: var(--p-surface-50, #f8fafb);--tw-border: var(--p-content-border-color, var(--p-surface-200, #e2e8f0));--tw-text: var(--p-text-color, #0f172a);--tw-muted: var(--p-text-muted-color, #64748b);--tw-accent: var(--p-primary-color, #0f766e);--tw-accent-contrast: var(--p-primary-contrast-color, #ffffff);--tw-accent-soft: var(--p-primary-100, var(--p-primary-50, #ccfbf1));--tw-danger: var(--p-red-500, #dc2626);--tw-danger-border: var(--p-red-300, #fca5a5);--tw-warning: var(--p-orange-500, #ea580c);--tw-warning-soft: var(--p-orange-100, #ffedd5);--tw-highlight: var(--p-highlight-background, var(--p-primary-50, #f0fdfa));--tw-tag-bg: var(--p-surface-100, #f1f5f9);--tw-tag-fg: var(--p-surface-600, #475569);display:block;height:100%;min-height:0}.p-scheduler{display:flex;flex-direction:column;height:100%;min-height:0;background:var(--tw-surface-card);border:1px solid var(--tw-border);border-radius:12px;overflow:hidden}.p-scheduler-header{flex:0 0 auto;border-bottom:1px solid var(--tw-border);background:var(--tw-surface)}.p-scheduler-toolbar{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:.75rem;padding:.65rem .85rem}.p-scheduler-toolbar-start{justify-self:start}.p-scheduler-toolbar-center{justify-self:center;text-align:center}.p-scheduler-toolbar-end{justify-self:end}.p-scheduler-nav{display:flex;align-items:center;gap:.25rem}.p-scheduler-today-button{margin-left:.35rem}.p-scheduler-title{margin:0;font-size:1.05rem;font-weight:700;color:var(--tw-text);white-space:nowrap}.p-scheduler-body{flex:1 1 auto;min-height:0;overflow-x:hidden;overflow-y:scroll;overscroll-behavior:contain;scrollbar-gutter:stable;scrollbar-width:auto;scrollbar-color:var(--tw-muted) var(--tw-border)}.p-scheduler-body::-webkit-scrollbar{width:10px}.p-scheduler-body::-webkit-scrollbar-thumb{background:var(--tw-muted);border-radius:6px;border:2px solid var(--tw-border)}.p-scheduler-body::-webkit-scrollbar-track{background:var(--tw-border)}.p-scheduler-month-view,.p-scheduler-week-view{display:flex;flex-direction:column;min-height:100%}.p-scheduler-weekdays{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));border-bottom:1px solid var(--tw-border);background:var(--tw-surface-ground);position:sticky;top:0;z-index:2}.p-scheduler-weekday{padding:.55rem .35rem;text-align:center;font-size:.75rem;font-weight:700;color:var(--tw-muted);text-transform:uppercase;letter-spacing:.02em}.p-scheduler-weeks{display:flex;flex-direction:column;flex:1 1 auto;min-height:51rem}.p-scheduler-week{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));flex:1 1 0;min-height:8.5rem;border-bottom:1px solid var(--tw-border)}.p-scheduler-week:last-child{border-bottom:0}.p-scheduler-week-expanded{flex:1 1 auto;min-height:22rem}.p-scheduler-day{position:relative;display:flex;flex-direction:column;min-width:0;min-height:0;padding:.3rem;border-right:1px solid var(--tw-border);background:var(--tw-surface-card)}.p-scheduler-day:last-child{border-right:0}.p-scheduler-day.p-scheduler-day-other-month{background:var(--tw-surface-ground);color:var(--tw-muted)}.p-scheduler-day.p-scheduler-day-other-month .p-scheduler-day-number{color:var(--tw-muted)}.p-scheduler-day.p-scheduler-day-today{background:var(--tw-highlight)}.p-scheduler-day.p-scheduler-day-holiday{background:var(--tw-warning-soft)}.p-scheduler-day.p-scheduler-day-weekend:not(.p-scheduler-day-today):not(.p-scheduler-day-holiday){background:var(--tw-surface-ground)}.p-scheduler-day:hover .p-scheduler-day-add{opacity:1}.p-scheduler-day-header{display:flex;align-items:center;gap:.25rem;margin-bottom:.2rem;min-height:1.5rem}.p-scheduler-day-number{font-size:.8rem;font-weight:700;line-height:1.4;width:1.5rem;height:1.5rem;display:inline-flex;align-items:center;justify-content:center;border-radius:999px}.p-scheduler-day-number.p-scheduler-day-number-today{background:var(--tw-accent);color:var(--tw-accent-contrast)}.p-scheduler-day-holiday-label{flex:1 1 auto;min-width:0;font-size:.62rem;font-weight:600;color:var(--tw-warning);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.p-scheduler-day-add{margin-left:auto;flex:0 0 auto;width:1.35rem;height:1.35rem;border:0;border-radius:6px;background:transparent;color:var(--tw-muted);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;opacity:.45;transition:opacity .12s ease,background .12s ease,color .12s ease}.p-scheduler-day-add:hover{opacity:1;background:var(--tw-accent-soft);color:var(--tw-accent)}.p-scheduler-day-add i{font-size:.7rem}.p-scheduler-day-events{display:flex;flex-direction:column;gap:.15rem;flex:1 1 auto;min-height:0;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:var(--tw-muted) transparent}.p-scheduler-day-events.cdk-drop-list-dragging .p-scheduler-event:not(.cdk-drag-placeholder){transition:transform .15s ease}.p-scheduler-day-events::-webkit-scrollbar{width:6px}.p-scheduler-day-events::-webkit-scrollbar-thumb{background:var(--tw-muted);border-radius:999px}.p-scheduler-day-events::-webkit-scrollbar-track{background:transparent}.p-scheduler-day-events-stack{overflow:auto;gap:.4rem;max-height:100%}.p-scheduler-event{--event-accent: rgb(37, 99, 235);position:relative;display:flex;align-items:center;gap:.3rem;border:0;border-left:3px solid var(--event-accent);border-radius:4px;background:color-mix(in srgb,var(--event-accent) 12%,var(--tw-surface-card));color:var(--tw-text);padding:.15rem .2rem .15rem .35rem;font-size:.72rem;line-height:1.25;cursor:grab;text-align:left;min-width:0}.p-scheduler-event:active{cursor:grabbing}.p-scheduler-event.cdk-drag-animating{transition:transform .15s ease}.p-scheduler-event.p-scheduler-event-large{padding:.75rem .85rem;font-size:.9rem;cursor:pointer}.p-scheduler-event-dot{flex:0 0 auto;width:.4rem;height:.4rem;border-radius:999px;background:var(--event-accent)}.p-scheduler-event-title{flex:1 1 auto;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600}.p-scheduler-event-time{flex:0 0 auto;color:var(--tw-muted);font-size:.75rem;font-weight:500}.p-scheduler-event-menu{flex:0 0 auto;width:1.25rem;height:1.25rem;border:0;border-radius:4px;background:transparent;color:var(--tw-muted);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;opacity:.55;padding:0}.p-scheduler-event-menu i{font-size:.7rem}.p-scheduler-event-menu:hover{background:color-mix(in srgb,var(--tw-text) 6%,transparent);color:var(--tw-text);opacity:1}.p-scheduler-event:hover .p-scheduler-event-menu,.p-scheduler-event-large .p-scheduler-event-menu{opacity:1}.p-scheduler-event-drag-preview{display:flex;align-items:center;padding:.25rem .5rem;border-radius:4px;background:var(--tw-surface-card);border-left:3px solid var(--tw-accent);box-shadow:0 8px 24px #0f1c242e;font-size:.75rem;font-weight:600;max-width:12rem}.p-scheduler-event-placeholder{min-height:1.35rem;border-radius:4px;background:#0d94881f;border:1px dashed var(--tw-accent)}.p-scheduler-more-link{border:0;background:transparent;color:var(--tw-muted);font-size:.7rem;font-weight:600;text-align:left;padding:.1rem .25rem;cursor:pointer}.p-scheduler-more-link:hover{color:var(--tw-accent)}.p-scheduler-day-view,.p-scheduler-agenda-view{padding:1rem}.p-scheduler-day-view-actions{margin-bottom:.75rem}.p-scheduler-holiday-banner{padding:.65rem .85rem;background:var(--tw-warning-soft);color:var(--p-orange-800, #9a3412);border-radius:10px;font-weight:600;margin-bottom:.75rem}.p-scheduler-empty{margin:1rem 0;color:var(--tw-muted);font-size:.9rem}.p-scheduler-agenda-row{display:grid;grid-template-columns:140px 1fr;gap:1rem;width:100%;text-align:left;border:0;border-bottom:1px solid var(--tw-border);background:transparent;padding:.85rem .35rem;cursor:pointer}.p-scheduler-agenda-row:hover{background:var(--tw-surface)}.p-scheduler-agenda-when{font-weight:700;color:var(--tw-muted)}.p-scheduler-agenda-what{display:flex;align-items:center;gap:.6rem;font-weight:600}@media(max-width:900px){.p-scheduler-toolbar{grid-template-columns:1fr;justify-items:stretch}.p-scheduler-toolbar-start,.p-scheduler-toolbar-center,.p-scheduler-toolbar-end{justify-self:stretch}.p-scheduler-toolbar-end{display:flex;justify-content:flex-end}.p-scheduler-agenda-row{grid-template-columns:1fr}.p-scheduler-day-add,.p-scheduler-event-menu{opacity:1}}\n"] }]
        }] });

/*
 * Public API Surface of task-workspace
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DEFAULT_TASK_LABELS, TASK_DETAIL_DIALOG, TASK_LABELS, TaskBoardComponent, TaskDialogHostComponent, TaskSchedulerComponent, TaskWorkspaceFacade, dateKey, defaultColumnsForSpace, defaultTodoColumnId, provideTaskDetailDialog, provideTaskWorkspace };
//# sourceMappingURL=task-workspace.mjs.map
