/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="task-workspace" />
export * from './public-api';
