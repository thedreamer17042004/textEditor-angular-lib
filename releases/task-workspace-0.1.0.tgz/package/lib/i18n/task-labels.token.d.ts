import { InjectionToken } from '@angular/core';
export interface TaskLabels {
    favorite: string;
    pin: string;
    open: string;
    duplicate: string;
    delete: string;
    addCard: string;
    addList: string;
    deleteList: string;
    newList: string;
    wip: string;
    today: string;
    month: string;
    week: string;
    day: string;
    agenda: string;
    addTask: string;
    noTasks: string;
    actions: string;
}
export declare const DEFAULT_TASK_LABELS: TaskLabels;
export declare const TASK_LABELS: InjectionToken<TaskLabels>;
