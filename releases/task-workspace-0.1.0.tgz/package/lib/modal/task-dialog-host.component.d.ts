import { Type } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Keeps the host-provided dialog instance alive after first open so overlays
 * can dispose cleanly instead of being torn down mid-close.
 */
export declare class TaskDialogHostComponent {
    private readonly facade;
    private readonly registered;
    readonly dialogType: import("@angular/core").WritableSignal<Type<unknown> | null>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<TaskDialogHostComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TaskDialogHostComponent, "tw-task-dialog-host", never, {}, {}, never, never, true, never>;
}
