import { InjectionToken, Provider, Type } from '@angular/core';
/**
 * Host registers its own task-detail dialog component.
 * Core only mounts it via TaskDialogHostComponent.
 */
export declare const TASK_DETAIL_DIALOG: InjectionToken<Type<unknown>>;
export declare function provideTaskDetailDialog(component: Type<unknown>): Provider;
