import { BoardColumn } from './task.models';
export declare function defaultColumnsForSpace(spaceId: string): BoardColumn[];
export declare function defaultTodoColumnId(spaceId: string, columns: BoardColumn[]): string;
export declare function dateKey(d: Date): string;
