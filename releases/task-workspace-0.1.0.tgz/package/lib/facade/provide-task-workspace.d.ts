import { Provider, Type } from '@angular/core';
import { TaskWorkspaceFacade } from './task-workspace.facade';
export interface ProvideTaskWorkspaceOptions {
    /** Concrete facade class (providedIn / constructors work as usual). */
    useClass?: Type<TaskWorkspaceFacade>;
    /** Existing injectable that implements TaskWorkspaceFacade. */
    useExisting?: Type<TaskWorkspaceFacade>;
    /** Factory returning a facade instance. */
    useFactory?: (...args: unknown[]) => TaskWorkspaceFacade;
    deps?: unknown[];
}
export declare function provideTaskWorkspace(options: ProvideTaskWorkspaceOptions): Provider[];
