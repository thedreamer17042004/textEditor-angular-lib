import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { MenuItem } from 'primeng/api';
import { ContextMenu } from 'primeng/contextmenu';
import { TaskWorkspaceFacade } from '../facade/task-workspace.facade';
import { TaskLabels } from '../i18n/task-labels.token';
import { Task } from '../models/task.models';
import * as i0 from "@angular/core";
type CalView = 'month' | 'week' | 'day' | 'agenda';
interface DayCell {
    date: Date;
    dateKey: string;
    inMonth: boolean;
    isToday: boolean;
    isWeekend: boolean;
    holidayName?: string;
    tasks: Task[];
}
export declare class TaskSchedulerComponent {
    readonly facade: TaskWorkspaceFacade;
    private readonly labels;
    /** Required — create / mutations stay scoped to the host-declared space. */
    readonly spaceId: import("@angular/core").InputSignal<string>;
    readonly tasks: import("@angular/core").InputSignal<Task[]>;
    readonly taskOpen: import("@angular/core").OutputEmitterRef<string>;
    readonly createAt: import("@angular/core").OutputEmitterRef<Date>;
    readonly view: import("@angular/core").WritableSignal<CalView>;
    readonly cursor: import("@angular/core").WritableSignal<Date>;
    readonly expandedDayKey: import("@angular/core").WritableSignal<string | null>;
    taskMenuItems: MenuItem[];
    readonly weekdays: string[];
    readonly viewOptions: import("@angular/core").Signal<{
        label: string;
        value: CalView;
    }[]>;
    readonly monthWeeks: import("@angular/core").Signal<DayCell[][]>;
    readonly weekDays: import("@angular/core").Signal<DayCell[]>;
    readonly dayTasks: import("@angular/core").Signal<Task[]>;
    readonly agenda: import("@angular/core").Signal<Task[]>;
    readonly title: import("@angular/core").Signal<string>;
    readonly connectedDayLists: import("@angular/core").Signal<string[]>;
    dayListId(dateKey: string): string;
    visibleTasks(cell: DayCell): Task[];
    moreCount(cell: DayCell): number;
    toggleMore(cell: DayCell, event: Event): void;
    prev(): void;
    next(): void;
    today(): void;
    setView(value: CalView): void;
    openTask(id: string, event?: Event): void;
    addOnDay(date: Date, event?: Event): void;
    dropTask(event: CdkDragDrop<Task[]>, targetDate: Date): void;
    openTaskMenu(event: MouseEvent, task: Task, menu: ContextMenu): void;
    accentFor(task: Task): string;
    holidayFor(date: Date): import("task-workspace").Holiday | undefined;
    label(key: keyof TaskLabels): string;
    private dateToIsoKeepTime;
    private tasksForDate;
    /** Sunday-first month grid (6 weeks). */
    private buildMonth;
    private buildWeek;
    private toCell;
    static ɵfac: i0.ɵɵFactoryDeclaration<TaskSchedulerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TaskSchedulerComponent, "tw-task-scheduler", never, { "spaceId": { "alias": "spaceId"; "required": true; "isSignal": true; }; "tasks": { "alias": "tasks"; "required": true; "isSignal": true; }; }, { "taskOpen": "taskOpen"; "createAt": "createAt"; }, never, never, true, never>;
}
export {};
