import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { OnDestroy } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { TaskWorkspaceFacade } from '../facade/task-workspace.facade';
import { TaskLabels } from '../i18n/task-labels.token';
import { BoardColumn, Task, TaskPriority } from '../models/task.models';
import * as i0 from "@angular/core";
export declare class TaskBoardComponent implements OnDestroy {
    readonly facade: TaskWorkspaceFacade;
    private readonly labels;
    /** Required — todos/tasks are always scoped to a space declared by the host. */
    readonly spaceId: import("@angular/core").InputSignal<string>;
    readonly tasks: import("@angular/core").InputSignal<Task[]>;
    /** Optional display name for accessibility. */
    readonly spaceName: import("@angular/core").InputSignal<string>;
    readonly taskOpen: import("@angular/core").OutputEmitterRef<string>;
    readonly collapsed: import("@angular/core").WritableSignal<Set<string>>;
    readonly selectedTaskId: import("@angular/core").WritableSignal<string | null>;
    readonly addingList: import("@angular/core").WritableSignal<boolean>;
    readonly newListTitle: import("@angular/core").WritableSignal<string>;
    /** True while a card/column is dragged — locks overflow so no scrollbar flash. */
    readonly dragging: import("@angular/core").WritableSignal<boolean>;
    get hostDragging(): boolean;
    contextItems: MenuItem[];
    columnMenuItems: MenuItem[];
    readonly columns: import("@angular/core").Signal<BoardColumn[]>;
    /** Card drop-lists connect only to each other (not the column list). */
    readonly connectedCardLists: import("@angular/core").Signal<string[]>;
    readonly columnMap: import("@angular/core").Signal<Map<string, Task[]>>;
    tasksInColumn(columnId: string): Task[];
    cardListId(columnId: string): string;
    dropColumn(event: CdkDragDrop<BoardColumn[]>): void;
    drop(event: CdkDragDrop<Task[]>, columnId: string): void;
    toggleCollapse(columnId: string): void;
    isCollapsed(columnId: string): boolean;
    wipExceeded(col: BoardColumn, count: number): boolean;
    open(task: Task): void;
    onDragStarted(): void;
    onDragEnded(): void;
    ngOnDestroy(): void;
    openColumnMenu(event: MouseEvent, col: BoardColumn, menu: {
        show: (e: Event) => void;
    }): void;
    deleteList(columnId: string): void;
    onContext(event: MouseEvent, task: Task, menu: {
        show: (e: Event) => void;
    }): void;
    addCard(columnId: string): void;
    startAddList(): void;
    cancelAddList(): void;
    confirmAddList(): void;
    assignees(task: Task): (import("task-workspace").TaskUser | undefined)[];
    checklistProgress(task: Task): {
        done: number;
        total: number;
    } | null;
    hasDescription(task: Task): boolean;
    isOverdue(task: Task): boolean;
    priorityLabel(priority: TaskPriority): string;
    columnStatusClass(col: BoardColumn): string;
    label(key: keyof TaskLabels): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TaskBoardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TaskBoardComponent, "tw-task-board", never, { "spaceId": { "alias": "spaceId"; "required": true; "isSignal": true; }; "tasks": { "alias": "tasks"; "required": true; "isSignal": true; }; "spaceName": { "alias": "spaceName"; "required": false; "isSignal": true; }; }, { "taskOpen": "taskOpen"; }, never, never, true, never>;
}
