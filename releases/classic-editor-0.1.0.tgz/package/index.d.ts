/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="classic-editor" />
export * from './public-api';
