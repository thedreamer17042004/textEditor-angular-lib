import * as i0 from '@angular/core';
import { input, output, signal, computed, forwardRef, ViewChild, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import Quill from 'quill';

/** Font options applied via Quill StyleAttributor (`font-family`). Edit here to extend. */
const EDITOR_FONTS = [
    { label: 'Default', value: false, css: '' },
    { label: 'Jakarta Sans', value: 'Plus Jakarta Sans', css: '"Plus Jakarta Sans", sans-serif' },
    { label: 'Source Serif', value: 'Source Serif 4', css: '"Source Serif 4", Georgia, serif' },
    { label: 'Merriweather', value: 'Merriweather', css: 'Merriweather, Georgia, serif' },
    { label: 'Lora', value: 'Lora', css: 'Lora, Georgia, serif' },
    { label: 'Georgia', value: 'Georgia', css: 'Georgia, serif' },
    { label: 'Times New Roman', value: 'Times New Roman', css: '"Times New Roman", Times, serif' },
    { label: 'Arial', value: 'Arial', css: 'Arial, Helvetica, sans-serif' },
    { label: 'Verdana', value: 'Verdana', css: 'Verdana, Geneva, sans-serif' },
    { label: 'JetBrains Mono', value: 'JetBrains Mono', css: '"JetBrains Mono", ui-monospace, monospace' },
    { label: 'Courier New', value: 'Courier New', css: '"Courier New", Courier, monospace' },
];
/** Load once in the host app `<head>` so picker fonts render correctly. */
const CLASSIC_EDITOR_FONTS_URL = 'https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Lora:wght@400;600;700&family=Merriweather:wght@400;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&display=swap';
function fontWhitelist() {
    return EDITOR_FONTS.map((f) => f.value).filter((v) => v !== false);
}
function fontLabelOf(value) {
    if (typeof value !== 'string' || !value)
        return 'Default';
    return EDITOR_FONTS.find((f) => f.value === value)?.label ?? value;
}
function fontPreviewCss(value) {
    return EDITOR_FONTS.find((f) => f.value === value)?.css || 'inherit';
}

/** Central toolbar option lists — extend here when adding formats. */
const HEADING_OPTIONS = [
    { label: 'Paragraph', value: false },
    { label: 'Heading 1', value: 1 },
    { label: 'Heading 2', value: 2 },
    { label: 'Heading 3', value: 3 },
    { label: 'Heading 4', value: 4 },
];
const SIZE_OPTIONS = ['12px', '14px', '16px', '18px', '24px', '32px'];
const TEXT_COLORS = [
    '#0f172a',
    '#334155',
    '#64748b',
    '#ef4444',
    '#f59e0b',
    '#10b981',
    '#0ea5e9',
    '#a855f7',
];
const HIGHLIGHT_COLORS = [
    'transparent',
    '#fef08a',
    '#bbf7d0',
    '#bae6fd',
    '#fbcfe8',
    '#fecaca',
    '#e2e8f0',
];
/** Max insert-table picker size (rows × cols). */
const TABLE_GRID_MAX = 8;

/** Register Quill style attributors used by the Classic toolbar. */
function setupQuillFormats() {
    const SizeStyle = Quill.import('attributors/style/size');
    SizeStyle.whitelist = [...SIZE_OPTIONS];
    Quill.register(SizeStyle, true);
    const FontStyle = Quill.import('attributors/style/font');
    FontStyle.whitelist = fontWhitelist();
    Quill.register(FontStyle, true);
}

/** Factory for the editor engine — keep Quill wiring here, not in the component. */
function createQuill(host, options) {
    setupQuillFormats();
    return new Quill(host, {
        theme: 'snow',
        placeholder: options.placeholder,
        readOnly: options.readOnly,
        modules: {
            toolbar: false,
            table: true,
            history: {
                delay: 800,
                maxStack: 120,
                userOnly: true,
            },
            clipboard: {
                matchVisual: false,
            },
        },
    });
}
function getTableModule(quill) {
    if (!quill)
        return null;
    return quill.getModule('table') ?? null;
}

function readQuillHtml(quill) {
    if (!quill)
        return '';
    const anyQuill = quill;
    if (typeof anyQuill.getSemanticHTML === 'function') {
        return anyQuill.getSemanticHTML();
    }
    return quill.root.innerHTML;
}
function writeQuillHtml(quill, html) {
    const normalized = html?.trim() ? html : '';
    quill.setContents([], 'silent');
    if (normalized) {
        quill.clipboard.dangerouslyPasteHTML(0, normalized, 'silent');
    }
}

const PRINT_CSS = `
  @page { margin: 16mm; }
  body {
    font-family: 'Source Serif 4', Georgia, 'Times New Roman', serif;
    padding: 0;
    margin: 0;
    line-height: 1.75;
    color: #1c2434;
    font-size: 16px;
  }
  h1, h2, h3, h4 { letter-spacing: -0.02em; font-weight: 700; }
  blockquote {
    border-left: 3px solid #2563eb;
    padding: 12px 16px;
    background: #eff6ff;
    color: #475569;
    font-style: italic;
  }
  pre {
    background: #1c2434;
    color: #e2e8f0;
    padding: 14px;
    border-radius: 8px;
    font-family: ui-monospace, Menlo, monospace;
    font-size: 13px;
    white-space: pre-wrap;
  }
  code {
    background: #f1f5f9;
    color: #be185d;
    padding: 0.1em 0.35em;
    border-radius: 4px;
  }
  table { border-collapse: collapse; width: 100%; font-family: 'Plus Jakarta Sans', sans-serif; font-size: 14px; }
  th, td { border: 1px solid #cbd5e1; padding: 8px; vertical-align: top; }
  th { background: #f8fafc; text-align: left; }
  img { max-width: 100%; }
  a { color: #2563eb; }
`;
/** Print HTML via a hidden iframe (avoids popup blockers / noopener null window). */
function printHtml(bodyHtml, title = 'Print') {
    const iframe = document.createElement('iframe');
    iframe.setAttribute('title', title);
    iframe.setAttribute('aria-hidden', 'true');
    Object.assign(iframe.style, {
        position: 'fixed',
        right: '0',
        bottom: '0',
        width: '0',
        height: '0',
        border: '0',
        opacity: '0',
        pointerEvents: 'none',
    });
    document.body.appendChild(iframe);
    const frameDoc = iframe.contentDocument ?? iframe.contentWindow?.document;
    if (!frameDoc) {
        iframe.remove();
        return;
    }
    frameDoc.open();
    frameDoc.write(`<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
    <style>${PRINT_CSS}</style></head><body>${bodyHtml}</body></html>`);
    frameDoc.close();
    let printed = false;
    const triggerPrint = () => {
        if (printed)
            return;
        printed = true;
        try {
            iframe.contentWindow?.focus();
            iframe.contentWindow?.print();
        }
        finally {
            window.setTimeout(() => iframe.remove(), 1000);
        }
    };
    window.setTimeout(triggerPrint, 250);
}

function buildTableGrid(max = TABLE_GRID_MAX) {
    return Array.from({ length: max * max }, (_, i) => ({
        row: Math.floor(i / max) + 1,
        col: (i % max) + 1,
    }));
}
function isSelectionInTable(quill) {
    if (!quill)
        return false;
    const table = getTableModule(quill);
    try {
        const selection = quill.getSelection();
        const [tableBlot] = table?.getTable(selection) ?? [null, null, null, -1];
        return tableBlot != null;
    }
    catch {
        return false;
    }
}
function insertTableAtSelection(quill, rows, cols) {
    const table = getTableModule(quill);
    if (!table)
        return;
    quill.focus();
    const selection = quill.getSelection(true);
    if (!selection) {
        quill.setSelection(quill.getLength(), 0, 'silent');
    }
    table.insertTable(Math.max(1, rows), Math.max(1, cols));
}
function runTableAction(quill, action) {
    const table = getTableModule(quill);
    if (!table)
        return;
    quill.focus();
    table[action]();
}
function tableSizeLabel(rows, cols) {
    if (!rows || !cols)
        return 'Insert table';
    return `${rows} × ${cols}`;
}

function readEditorStats(quill) {
    const text = quill.getText().replace(/\n$/, '').trim();
    const history = quill.history;
    return {
        characters: text.length,
        words: text ? text.split(/\s+/).filter(Boolean).length : 0,
        canUndo: (history?.stack?.undo.length ?? 0) > 0,
        canRedo: (history?.stack?.redo.length ?? 0) > 0,
    };
}

/**
 * Classic Quill editor shell.
 * Keep this file thin: UI state + wiring. Engine/options/helpers live under config|core|features.
 */
class ClassicEditorComponent {
    placeholder = input('Start writing…');
    readonly = input(false);
    styleClass = input('');
    contentChange = output();
    editorHost;
    fileInput;
    quill = null;
    onChangeFn = () => undefined;
    onTouchedFn = () => undefined;
    writingValue = false;
    pendingValue = null;
    formats = signal({});
    disabled = signal(false);
    words = signal(0);
    characters = signal(0);
    canUndo = signal(false);
    canRedo = signal(false);
    openMenu = signal(null);
    inTable = signal(false);
    tableHover = signal({ rows: 0, cols: 0 });
    tableGridCells = buildTableGrid();
    headingOptions = HEADING_OPTIONS;
    fontOptions = EDITOR_FONTS;
    sizeOptions = SIZE_OPTIONS;
    textColors = TEXT_COLORS;
    highlightColors = HIGHLIGHT_COLORS;
    headingLabel = computed(() => {
        const header = this.formats()['header'];
        if (!header)
            return 'Paragraph';
        return `Heading ${header}`;
    });
    sizeLabel = computed(() => {
        const size = this.formats()['size'];
        return typeof size === 'string' && size ? size : '16px';
    });
    fontLabel = computed(() => fontLabelOf(this.formats()['font']));
    ngAfterViewInit() {
        this.quill = createQuill(this.editorHost.nativeElement, {
            placeholder: this.placeholder(),
            readOnly: this.readonly() || this.disabled(),
        });
        this.quill.on('text-change', () => {
            this.refreshChrome();
            if (this.writingValue)
                return;
            const html = readQuillHtml(this.quill);
            this.onChangeFn(html);
            this.contentChange.emit(html);
        });
        this.quill.on('selection-change', () => this.refreshChrome());
        this.quill.root.addEventListener('blur', () => this.onTouchedFn());
        if (this.pendingValue !== null) {
            this.setHtml(this.pendingValue);
            this.pendingValue = null;
        }
        this.refreshChrome();
        document.addEventListener('click', this.onDocClick);
    }
    ngOnDestroy() {
        document.removeEventListener('click', this.onDocClick);
        this.quill = null;
    }
    onDocClick = () => this.openMenu.set(null);
    writeValue(value) {
        const html = value ?? '';
        if (!this.quill) {
            this.pendingValue = html;
            return;
        }
        this.setHtml(html);
    }
    registerOnChange(fn) {
        this.onChangeFn = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedFn = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
        this.quill?.enable(!(isDisabled || this.readonly()));
    }
    locked() {
        return this.disabled() || this.readonly();
    }
    isActive(format, value = true) {
        const current = this.formats()[format];
        if (value === true)
            return Boolean(current);
        return current === value;
    }
    toggleMenu(menu, event) {
        event.stopPropagation();
        if (this.locked())
            return;
        this.openMenu.update((cur) => (cur === menu ? null : menu));
        if (menu === 'table')
            this.tableHover.set({ rows: 0, cols: 0 });
    }
    previewTableSize(rows, cols, event) {
        event.stopPropagation();
        this.tableHover.set({ rows, cols });
    }
    tableSizeLabel() {
        const { rows, cols } = this.tableHover();
        return tableSizeLabel(rows, cols);
    }
    format(name, value = true, event) {
        event?.stopPropagation();
        if (!this.quill || this.locked())
            return;
        this.quill.focus();
        const current = this.quill.getFormat();
        if (value === true) {
            this.quill.format(name, !current[name]);
        }
        else if (current[name] === value) {
            this.quill.format(name, false);
        }
        else {
            this.quill.format(name, value);
        }
        this.openMenu.set(null);
        this.refreshChrome();
        this.onTouchedFn();
    }
    setHeading(value, event) {
        event.stopPropagation();
        if (!this.quill || this.locked())
            return;
        this.quill.focus();
        this.quill.format('header', value);
        this.openMenu.set(null);
        this.refreshChrome();
    }
    setSize(size, event) {
        this.format('size', size, event);
    }
    setFont(font, event) {
        this.format('font', font, event);
    }
    fontPreviewCss(font) {
        return fontPreviewCss(font);
    }
    setColor(format, color, event) {
        this.format(format, color === 'transparent' ? false : color, event);
    }
    promptLink(event) {
        event?.stopPropagation();
        if (!this.quill || this.locked())
            return;
        const current = String(this.quill.getFormat()['link'] || 'https://');
        const url = window.prompt('Enter link URL', current)?.trim();
        if (url === undefined)
            return;
        this.quill.focus();
        this.quill.format('link', url || false);
        this.refreshChrome();
    }
    undo(event) {
        event?.stopPropagation();
        this.quill?.history?.undo();
        this.refreshChrome();
    }
    redo(event) {
        event?.stopPropagation();
        this.quill?.history?.redo();
        this.refreshChrome();
    }
    clean(event) {
        event?.stopPropagation();
        if (!this.quill || this.locked())
            return;
        this.quill.focus();
        const range = this.quill.getSelection();
        if (range)
            this.quill.removeFormat(range.index, range.length || 1);
        this.refreshChrome();
    }
    insertHr(event) {
        event?.stopPropagation();
        if (!this.quill || this.locked())
            return;
        const range = this.quill.getSelection(true);
        const index = range?.index ?? this.quill.getLength();
        this.quill.clipboard.dangerouslyPasteHTML(index, '<p><br></p><hr/><p><br></p>');
        this.quill.setSelection(index + 1, 0);
        this.refreshChrome();
    }
    insertTable(rows, cols, event) {
        event?.stopPropagation();
        if (!this.quill || this.locked())
            return;
        insertTableAtSelection(this.quill, rows, cols);
        this.openMenu.set(null);
        this.tableHover.set({ rows: 0, cols: 0 });
        this.refreshChrome();
        this.onTouchedFn();
    }
    tableAction(action, event) {
        event?.stopPropagation();
        if (!this.quill || this.locked() || !this.inTable())
            return;
        runTableAction(this.quill, action);
        this.refreshChrome();
        this.onTouchedFn();
    }
    openImagePicker(event) {
        event.stopPropagation();
        if (this.locked())
            return;
        this.fileInput?.nativeElement.click();
    }
    onImageSelected(event) {
        const inputEl = event.target;
        const file = inputEl.files?.[0];
        if (!file || !this.quill)
            return;
        const reader = new FileReader();
        reader.onload = () => {
            const src = String(reader.result || '');
            if (!src || !this.quill)
                return;
            const range = this.quill.getSelection(true);
            const index = range?.index ?? this.quill.getLength();
            this.quill.insertEmbed(index, 'image', src, 'user');
            this.quill.setSelection(index + 1, 0);
            this.refreshChrome();
        };
        reader.readAsDataURL(file);
        inputEl.value = '';
    }
    insertImageUrl(event) {
        event.stopPropagation();
        if (!this.quill || this.locked())
            return;
        const url = window.prompt('Image URL', 'https://')?.trim();
        if (!url)
            return;
        const range = this.quill.getSelection(true);
        const index = range?.index ?? this.quill.getLength();
        this.quill.insertEmbed(index, 'image', url, 'user');
        this.quill.setSelection(index + 1, 0);
        this.refreshChrome();
    }
    print(event) {
        event?.stopPropagation();
        if (!this.quill)
            return;
        printHtml(this.quill.root.innerHTML);
    }
    setHtml(html) {
        if (!this.quill)
            return;
        this.writingValue = true;
        writeQuillHtml(this.quill, html);
        this.writingValue = false;
        this.refreshChrome();
    }
    refreshChrome() {
        if (!this.quill)
            return;
        try {
            const selection = this.quill.getSelection();
            this.formats.set(selection ? this.quill.getFormat(selection) : {});
        }
        catch {
            this.formats.set({});
        }
        this.inTable.set(isSelectionInTable(this.quill));
        const stats = readEditorStats(this.quill);
        this.characters.set(stats.characters);
        this.words.set(stats.words);
        this.canUndo.set(stats.canUndo);
        this.canRedo.set(stats.canRedo);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ClassicEditorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ClassicEditorComponent, isStandalone: true, selector: "ce-editor", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { contentChange: "contentChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ClassicEditorComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "editorHost", first: true, predicate: ["editorHost"], descendants: true, static: true }, { propertyName: "fileInput", first: true, predicate: ["fileInput"], descendants: true }], ngImport: i0, template: "<div class=\"te\" [class]=\"styleClass()\" [class.te-disabled]=\"locked()\" (click)=\"$event.stopPropagation()\">\r\n  <div class=\"te-toolbar\" role=\"toolbar\" aria-label=\"Formatting toolbar\">\r\n    <!-- History -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Undo (Ctrl+Z)\" [disabled]=\"!canUndo() || locked()\" (click)=\"undo($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M12 5V2L7 6.5 12 11V8a5 5 0 1 1-5 5H5a7 7 0 1 0 7-8z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Redo (Ctrl+Y)\" [disabled]=\"!canRedo() || locked()\" (click)=\"redo($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M12 5V2l5 4.5L12 11V8a5 5 0 1 0 5 5h2a7 7 0 1 1-7-8z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Structure -->\r\n    <div class=\"te-group te-dropdown-wrap\">\r\n      <button type=\"button\" class=\"te-btn te-btn-wide\" title=\"Text style\" [disabled]=\"locked()\" (click)=\"toggleMenu('heading', $event)\">\r\n        <span>{{ headingLabel() }}</span>\r\n        <svg class=\"chev\" viewBox=\"0 0 24 24\"><path d=\"M7 10l5 5 5-5H7z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      @if (openMenu() === 'heading') {\r\n        <div class=\"te-menu\">\r\n          @for (opt of headingOptions; track opt.label) {\r\n            <button\r\n              type=\"button\"\r\n              class=\"te-menu-item\"\r\n              [attr.data-level]=\"opt.value === false ? null : opt.value\"\r\n              [class.active]=\"(opt.value === false && !formats()['header']) || formats()['header'] === opt.value\"\r\n              (click)=\"setHeading(opt.value, $event)\"\r\n            >\r\n              {{ opt.label }}\r\n            </button>\r\n          }\r\n        </div>\r\n      }\r\n    </div>\r\n\r\n    <div class=\"te-group te-dropdown-wrap\">\r\n      <button type=\"button\" class=\"te-btn te-btn-wide te-btn-font\" title=\"Font family\" [disabled]=\"locked()\" (click)=\"toggleMenu('font', $event)\">\r\n        <span>{{ fontLabel() }}</span>\r\n        <svg class=\"chev\" viewBox=\"0 0 24 24\"><path d=\"M7 10l5 5 5-5H7z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      @if (openMenu() === 'font') {\r\n        <div class=\"te-menu te-menu-font\">\r\n          @for (opt of fontOptions; track opt.label) {\r\n            <button\r\n              type=\"button\"\r\n              class=\"te-menu-item\"\r\n              [class.active]=\"(opt.value === false && !formats()['font']) || formats()['font'] === opt.value\"\r\n              [style.font-family]=\"fontPreviewCss(opt.value)\"\r\n              (click)=\"setFont(opt.value, $event)\"\r\n            >\r\n              {{ opt.label }}\r\n            </button>\r\n          }\r\n        </div>\r\n      }\r\n    </div>\r\n\r\n    <div class=\"te-group te-dropdown-wrap\">\r\n      <button type=\"button\" class=\"te-btn te-btn-wide te-btn-size\" title=\"Font size\" [disabled]=\"locked()\" (click)=\"toggleMenu('size', $event)\">\r\n        <span>{{ sizeLabel() }}</span>\r\n        <svg class=\"chev\" viewBox=\"0 0 24 24\"><path d=\"M7 10l5 5 5-5H7z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      @if (openMenu() === 'size') {\r\n        <div class=\"te-menu\">\r\n          @for (size of sizeOptions; track size) {\r\n            <button type=\"button\" class=\"te-menu-item\" [class.active]=\"formats()['size'] === size\" (click)=\"setSize(size, $event)\">{{ size }}</button>\r\n          }\r\n        </div>\r\n      }\r\n    </div>\r\n\r\n    <!-- Inline -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Bold (Ctrl+B)\" [class.active]=\"isActive('bold')\" [disabled]=\"locked()\" (click)=\"format('bold', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\">\r\n          <path\r\n            fill=\"currentColor\"\r\n            d=\"M8 4h5.2c2.55 0 4.3 1.45 4.3 3.55 0 1.35-.7 2.45-1.85 3.05C17.5 11.3 18.6 12.6 18.6 14.4c0 2.4-1.95 4.1-4.7 4.1H8V4zm3.05 2.35v3.7h1.85c1.15 0 1.85-.55 1.85-1.85s-.7-1.85-1.85-1.85h-1.85zm0 6.05v4.25h2.15c1.3 0 2.1-.65 2.1-2.1s-.8-2.15-2.1-2.15h-2.15z\"\r\n          />\r\n        </svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Italic (Ctrl+I)\" [class.active]=\"isActive('italic')\" [disabled]=\"locked()\" (click)=\"format('italic', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M10 5h9v2h-3.2l-3.6 10H16v2H7v-2h3.2l3.6-10H10V5z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Underline (Ctrl+U)\" [class.active]=\"isActive('underline')\" [disabled]=\"locked()\" (click)=\"format('underline', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M7 4v7a5 5 0 0 0 10 0V4h-2v7a3 3 0 1 1-6 0V4H7zm-1 15h12v2H6v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Strikethrough\" [class.active]=\"isActive('strike')\" [disabled]=\"locked()\" (click)=\"format('strike', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 11h16v2H4v-2zm8-7c-2.8 0-5 1.6-5 4h2.2c0-1.1 1.2-2 2.8-2s2.8.9 2.8 2c0 .7-.4 1.3-1.2 1.8H7.5C6 12.4 5 13.6 5 15.5 5 18 7.2 20 12 20c4.2 0 6.5-2 6.5-4.5h-2.3c0 1.2-1.1 2.5-4.2 2.5-2.4 0-3.7-1-3.7-2.3 0-1 .7-1.7 2.3-2.2H19V4h-7z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Clear formatting\" [disabled]=\"locked()\" (click)=\"clean($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M6 5h9.5l-1.2 3H16l1.8-4.5A1 1 0 0 0 16.9 2H5a1 1 0 0 0-.9 1.5L6.5 8H8L6 5zm2.3 7 1.5 4H8.2L6.5 12H5l3.2 8.5c.2.6.8 1 1.4 1h.2c.7 0 1.2-.4 1.5-1L14 12h-1.7l-1.4 4-1.4-4H8.3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Code / script -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Inline code\" [class.active]=\"isActive('code')\" [disabled]=\"locked()\" (click)=\"format('code', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M8.5 7 3 12l5.5 5 1.4-1.4L5.8 12l4.1-3.6L8.5 7zm7 0-1.4 1.4L18.2 12l-4.1 3.6 1.4 1.4L21 12l-5.5-5z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Code block\" [class.active]=\"isActive('code-block')\" [disabled]=\"locked()\" (click)=\"format('code-block', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zm2 5 3 3-3 3 1.4 1.4L12 12.8 7.4 7.6 6 9zm7 8h5v-2h-5v2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Subscript\" [class.active]=\"isActive('script', 'sub')\" [disabled]=\"locked()\" (click)=\"format('script', 'sub', $event)\">\r\n        <span class=\"te-text\">X<sub>2</sub></span>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Superscript\" [class.active]=\"isActive('script', 'super')\" [disabled]=\"locked()\" (click)=\"format('script', 'super', $event)\">\r\n        <span class=\"te-text\">X<sup>2</sup></span>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Colors + link -->\r\n    <div class=\"te-group te-dropdown-wrap\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Text color\" [disabled]=\"locked()\" (click)=\"toggleMenu('color', $event)\">\r\n        <span class=\"te-color-icon\" [style.border-bottom-color]=\"(formats()['color'] || '#334155')\">A</span>\r\n      </button>\r\n      @if (openMenu() === 'color') {\r\n        <div class=\"te-menu te-swatches\">\r\n          @for (c of textColors; track c) {\r\n            <button type=\"button\" class=\"te-swatch\" [style.background]=\"c\" [class.active]=\"formats()['color'] === c\" (click)=\"setColor('color', c, $event)\"></button>\r\n          }\r\n        </div>\r\n      }\r\n\r\n      <button type=\"button\" class=\"te-btn\" title=\"Highlight\" [disabled]=\"locked()\" (click)=\"toggleMenu('highlight', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 19h16v2H4v-2zm9.7-14.3 4.6 4.6-8.5 8.5H5.2v-4.6l8.5-8.5zm1.4-1.4L16.5 2a1.5 1.5 0 0 1 2.1 0l1.4 1.4a1.5 1.5 0 0 1 0 2.1l-1.4 1.4-3.5-3.6z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      @if (openMenu() === 'highlight') {\r\n        <div class=\"te-menu te-swatches\">\r\n          @for (c of highlightColors; track c) {\r\n            <button type=\"button\" class=\"te-swatch\" [style.background]=\"c === 'transparent' ? '#fff' : c\" [class.clear]=\"c === 'transparent'\" (click)=\"setColor('background', c, $event)\"></button>\r\n          }\r\n        </div>\r\n      }\r\n\r\n      <button type=\"button\" class=\"te-btn\" title=\"Link (Ctrl+K)\" [class.active]=\"isActive('link')\" [disabled]=\"locked()\" (click)=\"promptLink($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M10.5 13.5a4 4 0 0 0 5.7 0l2.8-2.8a4 4 0 1 0-5.7-5.7l-1 1 1.4 1.4 1-1a2 2 0 1 1 2.8 2.8l-2.8 2.8a2 2 0 0 1-2.8 0l-1.4 1.5zm3 0a4 4 0 0 0-5.7 0L5 16.3a4 4 0 1 0 5.7 5.7l1-1-1.4-1.4-1 1a2 2 0 1 1-2.8-2.8l2.8-2.8a2 2 0 0 1 2.8 0l1.4-1.5z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Align -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Align left\" [class.active]=\"!formats()['align']\" [disabled]=\"locked()\" (click)=\"format('align', false, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm0 5h10v2H4v-2zm0 5h14v2H4v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Align center\" [class.active]=\"isActive('align', 'center')\" [disabled]=\"locked()\" (click)=\"format('align', 'center', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm3 5h10v2H7v-2zm-1 5h12v2H6v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Align right\" [class.active]=\"isActive('align', 'right')\" [disabled]=\"locked()\" (click)=\"format('align', 'right', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm6 5h10v2H10v-2zm2 5h8v2h-8v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Justify\" [class.active]=\"isActive('align', 'justify')\" [disabled]=\"locked()\" (click)=\"format('align', 'justify', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm0 5h16v2H4v-2zm0 5h16v2H4v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Lists -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Bullet list\" [class.active]=\"isActive('list', 'bullet')\" [disabled]=\"locked()\" (click)=\"format('list', 'bullet', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M8 6h12v2H8V6zm0 5h12v2H8v-2zm0 5h12v2H8v-2zM4 7.5A1.5 1.5 0 1 1 4 4.5 1.5 1.5 0 0 1 4 7.5zm0 5A1.5 1.5 0 1 1 4 9.5 1.5 1.5 0 0 1 4 12.5zm0 5A1.5 1.5 0 1 1 4 14.5 1.5 1.5 0 0 1 4 17.5z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Numbered list\" [class.active]=\"isActive('list', 'ordered')\" [disabled]=\"locked()\" (click)=\"format('list', 'ordered', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M8 6h12v2H8V6zm0 5h12v2H8v-2zm0 5h12v2H8v-2zM3 5h2.2v5H3.8V6.5H3V5zm.2 8H5v1H3.8v.8H5V16H3.2v-3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Checklist\" [class.active]=\"isActive('list', 'checked') || isActive('list', 'unchecked')\" [disabled]=\"locked()\" (click)=\"format('list', 'unchecked', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Decrease indent\" [disabled]=\"locked()\" (click)=\"format('indent', '-1', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm6 5h10v2H10v-2zm0 5h10v2H10v-2zM8 12l-4 3v-6l4 3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Increase indent\" [disabled]=\"locked()\" (click)=\"format('indent', '+1', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm6 5h10v2H10v-2zm0 5h10v2H10v-2zM4 9v6l4-3-4-3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Blocks / media -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Quote\" [class.active]=\"isActive('blockquote')\" [disabled]=\"locked()\" (click)=\"format('blockquote', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M7 7h5v5H9.5A2.5 2.5 0 0 0 7 14.5V17H5v-2.5A4.5 4.5 0 0 1 9.5 10H12V7H7zm10 0h5v5h-2.5A2.5 2.5 0 0 0 17 14.5V17h-2v-2.5A4.5 4.5 0 0 1 19.5 10H22V7h-5z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Divider\" [disabled]=\"locked()\" (click)=\"insertHr($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 11h16v2H4v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Upload image\" [disabled]=\"locked()\" (click)=\"openImagePicker($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M5 5h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2zm0 2v6.5l3.5-3.5 2.5 2.5 4-4L19 13V7H5zm8.5 2a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Image from URL\" [disabled]=\"locked()\" (click)=\"insertImageUrl($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M5 5h14v2H5V5zm0 12h14v2H5v-2zm2-6h4v2H7v-2zm6 0h4v2h-4v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <div class=\"te-dropdown-wrap\">\r\n        <button\r\n          type=\"button\"\r\n          class=\"te-btn\"\r\n          title=\"Insert table\"\r\n          [class.active]=\"openMenu() === 'table'\"\r\n          [disabled]=\"locked()\"\r\n          (click)=\"toggleMenu('table', $event)\"\r\n        >\r\n          <svg viewBox=\"0 0 24 24\"><path d=\"M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zm0 2v3h7V6H4zm9 0v3h7V6h-7zM4 11v3h7v-3H4zm9 0v3h7v-3h-7zM4 16v2h7v-2H4zm9 0v2h7v-2h-7z\" fill=\"currentColor\"/></svg>\r\n        </button>\r\n        @if (openMenu() === 'table') {\r\n          <div class=\"te-menu te-table-picker\" (click)=\"$event.stopPropagation()\">\r\n            <div class=\"te-table-picker-label\">{{ tableSizeLabel() }}</div>\r\n            <div class=\"te-table-grid\" role=\"grid\" aria-label=\"Table size\">\r\n              @for (cell of tableGridCells; track cell.row + '-' + cell.col) {\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"te-table-cell\"\r\n                  role=\"gridcell\"\r\n                  [class.on]=\"cell.row <= tableHover().rows && cell.col <= tableHover().cols\"\r\n                  (mouseenter)=\"previewTableSize(cell.row, cell.col, $event)\"\r\n                  (focus)=\"previewTableSize(cell.row, cell.col, $event)\"\r\n                  (click)=\"insertTable(cell.row, cell.col, $event)\"\r\n                ></button>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n      </div>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Print\" [disabled]=\"locked()\" (click)=\"print($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M7 3h10v5H7V3zm-2 7h14a2 2 0 0 1 2 2v5h-4v4H7v-4H3v-5a2 2 0 0 1 2-2zm2 9h6v-3H7v3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n  </div>\r\n\r\n  @if (inTable() && !locked()) {\r\n    <div class=\"te-table-bar\" role=\"toolbar\" aria-label=\"Table tools\">\r\n      <span class=\"te-table-bar-label\">Table</span>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Insert row above\" (click)=\"tableAction('insertRowAbove', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 14h16v2H4v-2zm0 4h16v2H4v-2zM11 4v6H8l4 4 4-4h-3V4h-2z\" fill=\"currentColor\"/></svg>\r\n        <span class=\"te-btn-label\">Row \u2191</span>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Insert row below\" (click)=\"tableAction('insertRowBelow', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 4h16v2H4V4zm0 4h16v2H4V8zm7 10v-6h3l-4-4-4 4h3v6h2z\" fill=\"currentColor\"/></svg>\r\n        <span class=\"te-btn-label\">Row \u2193</span>\r\n      </button>\r\n      <span class=\"te-table-sep\" aria-hidden=\"true\"></span>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Insert column left\" (click)=\"tableAction('insertColumnLeft', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M14 4h2v16h-2V4zm4 0h2v16h-2V4zM10 11H4v2h6v3l4-4-4-4v3z\" fill=\"currentColor\"/></svg>\r\n        <span class=\"te-btn-label\">Col \u2190</span>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Insert column right\" (click)=\"tableAction('insertColumnRight', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M8 4h2v16H8V4zM4 4h2v16H4V4zm10 7v-3l4 4-4 4v-3h-6v-2h6z\" fill=\"currentColor\"/></svg>\r\n        <span class=\"te-btn-label\">Col \u2192</span>\r\n      </button>\r\n      <span class=\"te-table-sep\" aria-hidden=\"true\"></span>\r\n      <button type=\"button\" class=\"te-btn te-btn-danger\" title=\"Delete row\" (click)=\"tableAction('deleteRow', $event)\">\r\n        <span class=\"te-btn-label\">Del row</span>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn te-btn-danger\" title=\"Delete column\" (click)=\"tableAction('deleteColumn', $event)\">\r\n        <span class=\"te-btn-label\">Del col</span>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn te-btn-danger\" title=\"Delete table\" (click)=\"tableAction('deleteTable', $event)\">\r\n        <span class=\"te-btn-label\">Del table</span>\r\n      </button>\r\n    </div>\r\n  }\r\n\r\n  <div class=\"te-canvas\">\r\n    <div class=\"te-paper\">\r\n      <div #editorHost class=\"te-host\"></div>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"te-footer\" aria-live=\"polite\">\r\n    <span class=\"stat\">\r\n      <span class=\"stat-label\">Words</span>\r\n      {{ words() }}\r\n    </span>\r\n    <span class=\"sep\" aria-hidden=\"true\"></span>\r\n    <span class=\"stat\">\r\n      <span class=\"stat-label\">Chars</span>\r\n      {{ characters() }}\r\n    </span>\r\n    <span class=\"hint\">\r\n      @if (inTable()) {\r\n        Click inside a cell \u00B7 use Table bar to add rows/columns\r\n      } @else {\r\n        Select text, then format \u00B7 Ctrl+B / Ctrl+I / Ctrl+K\r\n      }\r\n    </span>\r\n    <span class=\"badge\"><span class=\"badge-dot\" aria-hidden=\"true\"></span>Quill</span>\r\n  </div>\r\n\r\n  <input #fileInput type=\"file\" accept=\"image/*\" hidden (change)=\"onImageSelected($event)\" />\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block;--te-accent: #2563eb;--te-accent-soft: #eff6ff;--te-accent-mid: #dbeafe;--te-ink: #1c2434;--te-muted: #64748b;--te-line: #e4e9f0;--te-line-strong: #d0d7e2;--te-surface: #ffffff;--te-toolbar: #f7f9fc;--te-canvas: #edf1f7;--te-radius: 12px;--te-font-ui: \"Plus Jakarta Sans\", \"Segoe UI\", sans-serif;--te-font-doc: \"Source Serif 4\", Georgia, \"Times New Roman\", serif;--te-shadow: 0 1px 0 rgba(28, 36, 52, .04), 0 8px 24px rgba(28, 36, 52, .06)}.te{display:flex;flex-direction:column;border:1px solid var(--te-line);border-radius:var(--te-radius);background:var(--te-surface);box-shadow:var(--te-shadow);overflow:hidden;color:var(--te-ink);font-family:var(--te-font-ui)}.te-disabled{opacity:.62;pointer-events:none}.te-toolbar{display:flex;flex-wrap:wrap;gap:6px 2px;align-items:center;padding:8px 10px;background:linear-gradient(180deg,#ffffff 0%,var(--te-toolbar) 100%);border-bottom:1px solid var(--te-line);position:sticky;top:0;z-index:8}.te-group{display:inline-flex;align-items:center;gap:1px;padding:0 8px 0 2px;margin-right:2px;position:relative}.te-group:after{content:\"\";position:absolute;right:0;top:6px;bottom:6px;width:1px;background:var(--te-line-strong);opacity:.7}.te-group:last-child{padding-right:2px;margin-right:0}.te-group:last-child:after{display:none}.te-dropdown-wrap{position:relative}.te-btn{min-width:32px;height:32px;padding:0 7px;border:0;border-radius:7px;background:transparent;color:#475569;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:4px;transition:background .12s ease,color .12s ease,box-shadow .12s ease}.te-btn svg{width:15px;height:15px;display:block}.te-btn .chev{width:12px;height:12px;opacity:.55;flex-shrink:0}.te-btn:hover:not(:disabled){background:#e8eef6;color:var(--te-ink)}.te-btn:focus-visible{outline:2px solid var(--te-accent);outline-offset:1px}.te-btn.active{background:var(--te-accent-soft);color:var(--te-accent);box-shadow:inset 0 0 0 1px #2563eb38}.te-btn:disabled{opacity:.35;cursor:default}.te-btn-wide{min-width:124px;height:32px;padding:0 10px;font-size:12.5px;font-weight:600;letter-spacing:-.01em;justify-content:space-between;background:#fff;box-shadow:inset 0 0 0 1px var(--te-line)}.te-btn-font{min-width:132px;max-width:160px}.te-btn-font span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.te-btn-size{min-width:78px}.te-menu-font{min-width:200px;max-height:280px;overflow-y:auto;scrollbar-width:thin;scrollbar-color:#c1c7d0 transparent}.te-text{font-size:12px;font-weight:700;font-family:var(--te-font-ui)}.te-color-icon{font-size:13px;font-weight:800;border-bottom:3px solid currentColor;line-height:1;padding-bottom:1px;font-family:var(--te-font-doc)}.te-menu{position:absolute;top:calc(100% + 6px);left:0;min-width:180px;padding:6px;border-radius:10px;border:1px solid var(--te-line);background:#fff;box-shadow:0 12px 32px #1c24341f;z-index:40;animation:te-pop .14s ease-out}@keyframes te-pop{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}.te-menu-item{width:100%;border:0;background:transparent;text-align:left;padding:8px 10px;border-radius:7px;color:#334155;font-size:13px;font-family:var(--te-font-ui);cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:12px}.te-menu-item:hover{background:#f1f5f9;color:var(--te-ink)}.te-menu-item.active{background:var(--te-accent-soft);color:var(--te-accent);font-weight:600}.te-menu-item[data-level=\"1\"]{font-size:18px;font-weight:700;font-family:var(--te-font-doc)}.te-menu-item[data-level=\"2\"]{font-size:16px;font-weight:700;font-family:var(--te-font-doc)}.te-menu-item[data-level=\"3\"]{font-size:14px;font-weight:700;font-family:var(--te-font-doc)}.te-menu-item[data-level=\"4\"]{font-size:13px;font-weight:700;font-family:var(--te-font-doc)}.te-swatches{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;min-width:156px;padding:10px}.te-table-picker{min-width:188px;padding:10px}.te-table-picker-label{font-size:12px;font-weight:600;color:var(--te-muted);margin-bottom:8px;text-align:center}.te-table-grid{display:grid;grid-template-columns:repeat(8,1fr);gap:3px}.te-table-cell{width:18px;height:18px;padding:0;border:1px solid #cbd5e1;border-radius:3px;background:#fff;cursor:pointer}.te-table-cell.on{background:var(--te-accent-soft);border-color:var(--te-accent)}.te-table-bar{display:flex;flex-wrap:wrap;align-items:center;gap:2px 4px;padding:6px 10px;border-bottom:1px solid var(--te-line);background:linear-gradient(180deg,var(--te-accent-soft) 0%,#f8fbff 100%)}.te-table-bar-label{font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--te-accent);margin-right:6px}.te-table-sep{width:1px;height:18px;background:var(--te-line-strong);margin:0 4px}.te-btn-label{font-size:11px;font-weight:600;white-space:nowrap}.te-table-bar .te-btn{min-width:auto;height:28px;gap:4px;padding:0 8px}.te-btn-danger{color:#b91c1c}.te-btn-danger:hover:not(:disabled){background:#fef2f2;color:#991b1b}.te-swatch{width:28px;height:28px;border-radius:8px;border:1px solid rgba(15,23,42,.12);cursor:pointer;padding:0;transition:transform .12s ease,box-shadow .12s ease}.te-swatch:hover{transform:scale(1.08)}.te-swatch.active{box-shadow:0 0 0 2px #fff,0 0 0 4px var(--te-accent)}.te-swatch.clear{background-image:linear-gradient(45deg,#e2e8f0 25%,transparent 25%,transparent 75%,#e2e8f0 75%);background-size:10px 10px}.te-canvas{background:radial-gradient(ellipse 80% 50% at 50% 0%,rgba(37,99,235,.04),transparent 70%),linear-gradient(180deg,#e8edf5 0%,var(--te-canvas) 100%);padding:28px 18px 36px;flex:1}.te-paper{max-width:780px;margin:0 auto;background:#fff;border:1px solid #dde3ec;border-radius:4px;box-shadow:0 1px 2px #1c24340a,0 12px 28px #1c243412;overflow:hidden;transition:box-shadow .2s ease}.te-paper:focus-within{box-shadow:0 1px 2px #1c24340a,0 14px 36px #2563eb1a,0 0 0 1px #2563eb2e}.te-host{min-height:480px}:host ::ng-deep .ql-toolbar{display:none!important}:host ::ng-deep .ql-container.ql-snow{border:0;font-family:var(--te-font-doc);font-size:17px}:host ::ng-deep .ql-editor{min-height:480px;max-height:680px;overflow-y:auto;overflow-x:hidden;padding:44px 52px 56px;line-height:1.75;color:var(--te-ink);font-optical-sizing:auto;scrollbar-width:thin;scrollbar-color:#c1c7d0 transparent}:host ::ng-deep .ql-editor::-webkit-scrollbar{width:10px}:host ::ng-deep .ql-editor::-webkit-scrollbar-track{background:transparent;margin:8px 0}:host ::ng-deep .ql-editor::-webkit-scrollbar-thumb{background:#c1c7d0;border-radius:999px;border:2px solid transparent;background-clip:padding-box}:host ::ng-deep .ql-editor::-webkit-scrollbar-thumb:hover{background:#9aa3b2;border:2px solid transparent;background-clip:padding-box}:host ::ng-deep .ql-editor.ql-blank:before{color:#94a3b8;font-style:normal;font-family:var(--te-font-ui);font-size:15px;left:52px;right:52px}:host ::ng-deep .ql-editor h1{font-size:2.15rem;font-weight:700;letter-spacing:-.025em;line-height:1.25;margin:0 0 .5em;color:#0f172a}:host ::ng-deep .ql-editor h2{font-size:1.5rem;font-weight:700;letter-spacing:-.02em;margin:1.35em 0 .45em;color:#0f172a}:host ::ng-deep .ql-editor h3{font-size:1.25rem;font-weight:700;margin:1.2em 0 .4em}:host ::ng-deep .ql-editor h4{font-size:1.05rem;font-weight:700;margin:1.05em 0 .35em}:host ::ng-deep .ql-editor p,:host ::ng-deep .ql-editor ul,:host ::ng-deep .ql-editor ol,:host ::ng-deep .ql-editor pre,:host ::ng-deep .ql-editor blockquote{margin-bottom:.9em}:host ::ng-deep .ql-editor ul,:host ::ng-deep .ql-editor ol{padding-left:1.4em}:host ::ng-deep .ql-editor blockquote{border-left:3px solid var(--te-accent);background:linear-gradient(90deg,var(--te-accent-soft),transparent 90%);color:#475569;padding:12px 16px;border-radius:0 8px 8px 0;margin:.2em 0 1em;font-style:italic}:host ::ng-deep .ql-editor pre.ql-syntax{background:#1c2434;color:#e2e8f0;border-radius:8px;padding:16px 18px;overflow:auto;font-family:ui-monospace,Cascadia Code,SF Mono,Menlo,monospace;font-size:13.5px;line-height:1.55}:host ::ng-deep .ql-editor code{font-family:ui-monospace,Cascadia Code,Menlo,monospace;font-size:.88em;background:#f1f5f9;color:#be185d;padding:.12em .38em;border-radius:4px}:host ::ng-deep .ql-editor a{color:var(--te-accent);text-decoration-thickness:1px;text-underline-offset:2px}:host ::ng-deep .ql-editor img{max-width:100%;border-radius:6px;margin:.4em 0}:host ::ng-deep .ql-editor table{width:100%;border-collapse:collapse;margin:.4em 0 1.1em;font-family:var(--te-font-ui);font-size:14px;table-layout:fixed}:host ::ng-deep .ql-editor th,:host ::ng-deep .ql-editor td{border:1px solid #cbd5e1;padding:10px 12px;min-width:48px;vertical-align:top;background:#fff}:host ::ng-deep .ql-editor th{background:#f8fafc;font-weight:600;text-align:left}:host ::ng-deep .ql-editor td.ql-table-selected,:host ::ng-deep .ql-editor td:focus{outline:2px solid rgba(37,99,235,.35);outline-offset:-2px}:host ::ng-deep .ql-editor hr{border:0;border-top:1px solid #d8dee8;margin:1.6em 0}.te-footer{display:flex;flex-wrap:wrap;gap:6px 12px;align-items:center;padding:9px 16px;border-top:1px solid var(--te-line);background:linear-gradient(180deg,#fafbfc,#f4f6f9);color:var(--te-muted);font-size:12px;font-weight:500}.te-footer .stat{display:inline-flex;align-items:center;gap:6px;font-variant-numeric:tabular-nums}.te-footer .stat-label{color:#94a3b8;font-weight:500;text-transform:uppercase;letter-spacing:.04em;font-size:10.5px}.te-footer .sep{width:1px;height:12px;background:var(--te-line-strong)}.te-footer .hint{margin-left:auto;color:#94a3b8;font-weight:500}.te-footer .badge{display:inline-flex;align-items:center;gap:5px;padding:3px 8px;border-radius:6px;background:var(--te-accent-soft);color:var(--te-accent);font-size:11px;font-weight:600}.te-footer .badge-dot{width:6px;height:6px;border-radius:50%;background:var(--te-accent)}@media(max-width:720px){.te-canvas{padding:14px 10px 20px}:host ::ng-deep .ql-editor{padding:24px 20px 32px;min-height:360px;font-size:16px}:host ::ng-deep .ql-editor.ql-blank:before{left:20px;right:20px}.te-btn-wide{min-width:108px}.te-footer .hint{margin-left:0;width:100%}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ClassicEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ce-editor', standalone: true, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ClassicEditorComponent),
                            multi: true,
                        },
                    ], template: "<div class=\"te\" [class]=\"styleClass()\" [class.te-disabled]=\"locked()\" (click)=\"$event.stopPropagation()\">\r\n  <div class=\"te-toolbar\" role=\"toolbar\" aria-label=\"Formatting toolbar\">\r\n    <!-- History -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Undo (Ctrl+Z)\" [disabled]=\"!canUndo() || locked()\" (click)=\"undo($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M12 5V2L7 6.5 12 11V8a5 5 0 1 1-5 5H5a7 7 0 1 0 7-8z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Redo (Ctrl+Y)\" [disabled]=\"!canRedo() || locked()\" (click)=\"redo($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M12 5V2l5 4.5L12 11V8a5 5 0 1 0 5 5h2a7 7 0 1 1-7-8z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Structure -->\r\n    <div class=\"te-group te-dropdown-wrap\">\r\n      <button type=\"button\" class=\"te-btn te-btn-wide\" title=\"Text style\" [disabled]=\"locked()\" (click)=\"toggleMenu('heading', $event)\">\r\n        <span>{{ headingLabel() }}</span>\r\n        <svg class=\"chev\" viewBox=\"0 0 24 24\"><path d=\"M7 10l5 5 5-5H7z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      @if (openMenu() === 'heading') {\r\n        <div class=\"te-menu\">\r\n          @for (opt of headingOptions; track opt.label) {\r\n            <button\r\n              type=\"button\"\r\n              class=\"te-menu-item\"\r\n              [attr.data-level]=\"opt.value === false ? null : opt.value\"\r\n              [class.active]=\"(opt.value === false && !formats()['header']) || formats()['header'] === opt.value\"\r\n              (click)=\"setHeading(opt.value, $event)\"\r\n            >\r\n              {{ opt.label }}\r\n            </button>\r\n          }\r\n        </div>\r\n      }\r\n    </div>\r\n\r\n    <div class=\"te-group te-dropdown-wrap\">\r\n      <button type=\"button\" class=\"te-btn te-btn-wide te-btn-font\" title=\"Font family\" [disabled]=\"locked()\" (click)=\"toggleMenu('font', $event)\">\r\n        <span>{{ fontLabel() }}</span>\r\n        <svg class=\"chev\" viewBox=\"0 0 24 24\"><path d=\"M7 10l5 5 5-5H7z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      @if (openMenu() === 'font') {\r\n        <div class=\"te-menu te-menu-font\">\r\n          @for (opt of fontOptions; track opt.label) {\r\n            <button\r\n              type=\"button\"\r\n              class=\"te-menu-item\"\r\n              [class.active]=\"(opt.value === false && !formats()['font']) || formats()['font'] === opt.value\"\r\n              [style.font-family]=\"fontPreviewCss(opt.value)\"\r\n              (click)=\"setFont(opt.value, $event)\"\r\n            >\r\n              {{ opt.label }}\r\n            </button>\r\n          }\r\n        </div>\r\n      }\r\n    </div>\r\n\r\n    <div class=\"te-group te-dropdown-wrap\">\r\n      <button type=\"button\" class=\"te-btn te-btn-wide te-btn-size\" title=\"Font size\" [disabled]=\"locked()\" (click)=\"toggleMenu('size', $event)\">\r\n        <span>{{ sizeLabel() }}</span>\r\n        <svg class=\"chev\" viewBox=\"0 0 24 24\"><path d=\"M7 10l5 5 5-5H7z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      @if (openMenu() === 'size') {\r\n        <div class=\"te-menu\">\r\n          @for (size of sizeOptions; track size) {\r\n            <button type=\"button\" class=\"te-menu-item\" [class.active]=\"formats()['size'] === size\" (click)=\"setSize(size, $event)\">{{ size }}</button>\r\n          }\r\n        </div>\r\n      }\r\n    </div>\r\n\r\n    <!-- Inline -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Bold (Ctrl+B)\" [class.active]=\"isActive('bold')\" [disabled]=\"locked()\" (click)=\"format('bold', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\">\r\n          <path\r\n            fill=\"currentColor\"\r\n            d=\"M8 4h5.2c2.55 0 4.3 1.45 4.3 3.55 0 1.35-.7 2.45-1.85 3.05C17.5 11.3 18.6 12.6 18.6 14.4c0 2.4-1.95 4.1-4.7 4.1H8V4zm3.05 2.35v3.7h1.85c1.15 0 1.85-.55 1.85-1.85s-.7-1.85-1.85-1.85h-1.85zm0 6.05v4.25h2.15c1.3 0 2.1-.65 2.1-2.1s-.8-2.15-2.1-2.15h-2.15z\"\r\n          />\r\n        </svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Italic (Ctrl+I)\" [class.active]=\"isActive('italic')\" [disabled]=\"locked()\" (click)=\"format('italic', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M10 5h9v2h-3.2l-3.6 10H16v2H7v-2h3.2l3.6-10H10V5z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Underline (Ctrl+U)\" [class.active]=\"isActive('underline')\" [disabled]=\"locked()\" (click)=\"format('underline', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M7 4v7a5 5 0 0 0 10 0V4h-2v7a3 3 0 1 1-6 0V4H7zm-1 15h12v2H6v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Strikethrough\" [class.active]=\"isActive('strike')\" [disabled]=\"locked()\" (click)=\"format('strike', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 11h16v2H4v-2zm8-7c-2.8 0-5 1.6-5 4h2.2c0-1.1 1.2-2 2.8-2s2.8.9 2.8 2c0 .7-.4 1.3-1.2 1.8H7.5C6 12.4 5 13.6 5 15.5 5 18 7.2 20 12 20c4.2 0 6.5-2 6.5-4.5h-2.3c0 1.2-1.1 2.5-4.2 2.5-2.4 0-3.7-1-3.7-2.3 0-1 .7-1.7 2.3-2.2H19V4h-7z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Clear formatting\" [disabled]=\"locked()\" (click)=\"clean($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M6 5h9.5l-1.2 3H16l1.8-4.5A1 1 0 0 0 16.9 2H5a1 1 0 0 0-.9 1.5L6.5 8H8L6 5zm2.3 7 1.5 4H8.2L6.5 12H5l3.2 8.5c.2.6.8 1 1.4 1h.2c.7 0 1.2-.4 1.5-1L14 12h-1.7l-1.4 4-1.4-4H8.3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Code / script -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Inline code\" [class.active]=\"isActive('code')\" [disabled]=\"locked()\" (click)=\"format('code', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M8.5 7 3 12l5.5 5 1.4-1.4L5.8 12l4.1-3.6L8.5 7zm7 0-1.4 1.4L18.2 12l-4.1 3.6 1.4 1.4L21 12l-5.5-5z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Code block\" [class.active]=\"isActive('code-block')\" [disabled]=\"locked()\" (click)=\"format('code-block', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zm2 5 3 3-3 3 1.4 1.4L12 12.8 7.4 7.6 6 9zm7 8h5v-2h-5v2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Subscript\" [class.active]=\"isActive('script', 'sub')\" [disabled]=\"locked()\" (click)=\"format('script', 'sub', $event)\">\r\n        <span class=\"te-text\">X<sub>2</sub></span>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Superscript\" [class.active]=\"isActive('script', 'super')\" [disabled]=\"locked()\" (click)=\"format('script', 'super', $event)\">\r\n        <span class=\"te-text\">X<sup>2</sup></span>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Colors + link -->\r\n    <div class=\"te-group te-dropdown-wrap\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Text color\" [disabled]=\"locked()\" (click)=\"toggleMenu('color', $event)\">\r\n        <span class=\"te-color-icon\" [style.border-bottom-color]=\"(formats()['color'] || '#334155')\">A</span>\r\n      </button>\r\n      @if (openMenu() === 'color') {\r\n        <div class=\"te-menu te-swatches\">\r\n          @for (c of textColors; track c) {\r\n            <button type=\"button\" class=\"te-swatch\" [style.background]=\"c\" [class.active]=\"formats()['color'] === c\" (click)=\"setColor('color', c, $event)\"></button>\r\n          }\r\n        </div>\r\n      }\r\n\r\n      <button type=\"button\" class=\"te-btn\" title=\"Highlight\" [disabled]=\"locked()\" (click)=\"toggleMenu('highlight', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 19h16v2H4v-2zm9.7-14.3 4.6 4.6-8.5 8.5H5.2v-4.6l8.5-8.5zm1.4-1.4L16.5 2a1.5 1.5 0 0 1 2.1 0l1.4 1.4a1.5 1.5 0 0 1 0 2.1l-1.4 1.4-3.5-3.6z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      @if (openMenu() === 'highlight') {\r\n        <div class=\"te-menu te-swatches\">\r\n          @for (c of highlightColors; track c) {\r\n            <button type=\"button\" class=\"te-swatch\" [style.background]=\"c === 'transparent' ? '#fff' : c\" [class.clear]=\"c === 'transparent'\" (click)=\"setColor('background', c, $event)\"></button>\r\n          }\r\n        </div>\r\n      }\r\n\r\n      <button type=\"button\" class=\"te-btn\" title=\"Link (Ctrl+K)\" [class.active]=\"isActive('link')\" [disabled]=\"locked()\" (click)=\"promptLink($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M10.5 13.5a4 4 0 0 0 5.7 0l2.8-2.8a4 4 0 1 0-5.7-5.7l-1 1 1.4 1.4 1-1a2 2 0 1 1 2.8 2.8l-2.8 2.8a2 2 0 0 1-2.8 0l-1.4 1.5zm3 0a4 4 0 0 0-5.7 0L5 16.3a4 4 0 1 0 5.7 5.7l1-1-1.4-1.4-1 1a2 2 0 1 1-2.8-2.8l2.8-2.8a2 2 0 0 1 2.8 0l1.4-1.5z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Align -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Align left\" [class.active]=\"!formats()['align']\" [disabled]=\"locked()\" (click)=\"format('align', false, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm0 5h10v2H4v-2zm0 5h14v2H4v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Align center\" [class.active]=\"isActive('align', 'center')\" [disabled]=\"locked()\" (click)=\"format('align', 'center', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm3 5h10v2H7v-2zm-1 5h12v2H6v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Align right\" [class.active]=\"isActive('align', 'right')\" [disabled]=\"locked()\" (click)=\"format('align', 'right', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm6 5h10v2H10v-2zm2 5h8v2h-8v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Justify\" [class.active]=\"isActive('align', 'justify')\" [disabled]=\"locked()\" (click)=\"format('align', 'justify', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm0 5h16v2H4v-2zm0 5h16v2H4v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Lists -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Bullet list\" [class.active]=\"isActive('list', 'bullet')\" [disabled]=\"locked()\" (click)=\"format('list', 'bullet', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M8 6h12v2H8V6zm0 5h12v2H8v-2zm0 5h12v2H8v-2zM4 7.5A1.5 1.5 0 1 1 4 4.5 1.5 1.5 0 0 1 4 7.5zm0 5A1.5 1.5 0 1 1 4 9.5 1.5 1.5 0 0 1 4 12.5zm0 5A1.5 1.5 0 1 1 4 14.5 1.5 1.5 0 0 1 4 17.5z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Numbered list\" [class.active]=\"isActive('list', 'ordered')\" [disabled]=\"locked()\" (click)=\"format('list', 'ordered', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M8 6h12v2H8V6zm0 5h12v2H8v-2zm0 5h12v2H8v-2zM3 5h2.2v5H3.8V6.5H3V5zm.2 8H5v1H3.8v.8H5V16H3.2v-3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Checklist\" [class.active]=\"isActive('list', 'checked') || isActive('list', 'unchecked')\" [disabled]=\"locked()\" (click)=\"format('list', 'unchecked', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Decrease indent\" [disabled]=\"locked()\" (click)=\"format('indent', '-1', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm6 5h10v2H10v-2zm0 5h10v2H10v-2zM8 12l-4 3v-6l4 3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Increase indent\" [disabled]=\"locked()\" (click)=\"format('indent', '+1', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 6h16v2H4V6zm6 5h10v2H10v-2zm0 5h10v2H10v-2zM4 9v6l4-3-4-3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n\r\n    <!-- Blocks / media -->\r\n    <div class=\"te-group\">\r\n      <button type=\"button\" class=\"te-btn\" title=\"Quote\" [class.active]=\"isActive('blockquote')\" [disabled]=\"locked()\" (click)=\"format('blockquote', true, $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M7 7h5v5H9.5A2.5 2.5 0 0 0 7 14.5V17H5v-2.5A4.5 4.5 0 0 1 9.5 10H12V7H7zm10 0h5v5h-2.5A2.5 2.5 0 0 0 17 14.5V17h-2v-2.5A4.5 4.5 0 0 1 19.5 10H22V7h-5z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Divider\" [disabled]=\"locked()\" (click)=\"insertHr($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 11h16v2H4v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Upload image\" [disabled]=\"locked()\" (click)=\"openImagePicker($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M5 5h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2zm0 2v6.5l3.5-3.5 2.5 2.5 4-4L19 13V7H5zm8.5 2a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Image from URL\" [disabled]=\"locked()\" (click)=\"insertImageUrl($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M5 5h14v2H5V5zm0 12h14v2H5v-2zm2-6h4v2H7v-2zm6 0h4v2h-4v-2z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n      <div class=\"te-dropdown-wrap\">\r\n        <button\r\n          type=\"button\"\r\n          class=\"te-btn\"\r\n          title=\"Insert table\"\r\n          [class.active]=\"openMenu() === 'table'\"\r\n          [disabled]=\"locked()\"\r\n          (click)=\"toggleMenu('table', $event)\"\r\n        >\r\n          <svg viewBox=\"0 0 24 24\"><path d=\"M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zm0 2v3h7V6H4zm9 0v3h7V6h-7zM4 11v3h7v-3H4zm9 0v3h7v-3h-7zM4 16v2h7v-2H4zm9 0v2h7v-2h-7z\" fill=\"currentColor\"/></svg>\r\n        </button>\r\n        @if (openMenu() === 'table') {\r\n          <div class=\"te-menu te-table-picker\" (click)=\"$event.stopPropagation()\">\r\n            <div class=\"te-table-picker-label\">{{ tableSizeLabel() }}</div>\r\n            <div class=\"te-table-grid\" role=\"grid\" aria-label=\"Table size\">\r\n              @for (cell of tableGridCells; track cell.row + '-' + cell.col) {\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"te-table-cell\"\r\n                  role=\"gridcell\"\r\n                  [class.on]=\"cell.row <= tableHover().rows && cell.col <= tableHover().cols\"\r\n                  (mouseenter)=\"previewTableSize(cell.row, cell.col, $event)\"\r\n                  (focus)=\"previewTableSize(cell.row, cell.col, $event)\"\r\n                  (click)=\"insertTable(cell.row, cell.col, $event)\"\r\n                ></button>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n      </div>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Print\" [disabled]=\"locked()\" (click)=\"print($event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M7 3h10v5H7V3zm-2 7h14a2 2 0 0 1 2 2v5h-4v4H7v-4H3v-5a2 2 0 0 1 2-2zm2 9h6v-3H7v3z\" fill=\"currentColor\"/></svg>\r\n      </button>\r\n    </div>\r\n  </div>\r\n\r\n  @if (inTable() && !locked()) {\r\n    <div class=\"te-table-bar\" role=\"toolbar\" aria-label=\"Table tools\">\r\n      <span class=\"te-table-bar-label\">Table</span>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Insert row above\" (click)=\"tableAction('insertRowAbove', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 14h16v2H4v-2zm0 4h16v2H4v-2zM11 4v6H8l4 4 4-4h-3V4h-2z\" fill=\"currentColor\"/></svg>\r\n        <span class=\"te-btn-label\">Row \u2191</span>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Insert row below\" (click)=\"tableAction('insertRowBelow', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M4 4h16v2H4V4zm0 4h16v2H4V8zm7 10v-6h3l-4-4-4 4h3v6h2z\" fill=\"currentColor\"/></svg>\r\n        <span class=\"te-btn-label\">Row \u2193</span>\r\n      </button>\r\n      <span class=\"te-table-sep\" aria-hidden=\"true\"></span>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Insert column left\" (click)=\"tableAction('insertColumnLeft', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M14 4h2v16h-2V4zm4 0h2v16h-2V4zM10 11H4v2h6v3l4-4-4-4v3z\" fill=\"currentColor\"/></svg>\r\n        <span class=\"te-btn-label\">Col \u2190</span>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn\" title=\"Insert column right\" (click)=\"tableAction('insertColumnRight', $event)\">\r\n        <svg viewBox=\"0 0 24 24\"><path d=\"M8 4h2v16H8V4zM4 4h2v16H4V4zm10 7v-3l4 4-4 4v-3h-6v-2h6z\" fill=\"currentColor\"/></svg>\r\n        <span class=\"te-btn-label\">Col \u2192</span>\r\n      </button>\r\n      <span class=\"te-table-sep\" aria-hidden=\"true\"></span>\r\n      <button type=\"button\" class=\"te-btn te-btn-danger\" title=\"Delete row\" (click)=\"tableAction('deleteRow', $event)\">\r\n        <span class=\"te-btn-label\">Del row</span>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn te-btn-danger\" title=\"Delete column\" (click)=\"tableAction('deleteColumn', $event)\">\r\n        <span class=\"te-btn-label\">Del col</span>\r\n      </button>\r\n      <button type=\"button\" class=\"te-btn te-btn-danger\" title=\"Delete table\" (click)=\"tableAction('deleteTable', $event)\">\r\n        <span class=\"te-btn-label\">Del table</span>\r\n      </button>\r\n    </div>\r\n  }\r\n\r\n  <div class=\"te-canvas\">\r\n    <div class=\"te-paper\">\r\n      <div #editorHost class=\"te-host\"></div>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"te-footer\" aria-live=\"polite\">\r\n    <span class=\"stat\">\r\n      <span class=\"stat-label\">Words</span>\r\n      {{ words() }}\r\n    </span>\r\n    <span class=\"sep\" aria-hidden=\"true\"></span>\r\n    <span class=\"stat\">\r\n      <span class=\"stat-label\">Chars</span>\r\n      {{ characters() }}\r\n    </span>\r\n    <span class=\"hint\">\r\n      @if (inTable()) {\r\n        Click inside a cell \u00B7 use Table bar to add rows/columns\r\n      } @else {\r\n        Select text, then format \u00B7 Ctrl+B / Ctrl+I / Ctrl+K\r\n      }\r\n    </span>\r\n    <span class=\"badge\"><span class=\"badge-dot\" aria-hidden=\"true\"></span>Quill</span>\r\n  </div>\r\n\r\n  <input #fileInput type=\"file\" accept=\"image/*\" hidden (change)=\"onImageSelected($event)\" />\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block;--te-accent: #2563eb;--te-accent-soft: #eff6ff;--te-accent-mid: #dbeafe;--te-ink: #1c2434;--te-muted: #64748b;--te-line: #e4e9f0;--te-line-strong: #d0d7e2;--te-surface: #ffffff;--te-toolbar: #f7f9fc;--te-canvas: #edf1f7;--te-radius: 12px;--te-font-ui: \"Plus Jakarta Sans\", \"Segoe UI\", sans-serif;--te-font-doc: \"Source Serif 4\", Georgia, \"Times New Roman\", serif;--te-shadow: 0 1px 0 rgba(28, 36, 52, .04), 0 8px 24px rgba(28, 36, 52, .06)}.te{display:flex;flex-direction:column;border:1px solid var(--te-line);border-radius:var(--te-radius);background:var(--te-surface);box-shadow:var(--te-shadow);overflow:hidden;color:var(--te-ink);font-family:var(--te-font-ui)}.te-disabled{opacity:.62;pointer-events:none}.te-toolbar{display:flex;flex-wrap:wrap;gap:6px 2px;align-items:center;padding:8px 10px;background:linear-gradient(180deg,#ffffff 0%,var(--te-toolbar) 100%);border-bottom:1px solid var(--te-line);position:sticky;top:0;z-index:8}.te-group{display:inline-flex;align-items:center;gap:1px;padding:0 8px 0 2px;margin-right:2px;position:relative}.te-group:after{content:\"\";position:absolute;right:0;top:6px;bottom:6px;width:1px;background:var(--te-line-strong);opacity:.7}.te-group:last-child{padding-right:2px;margin-right:0}.te-group:last-child:after{display:none}.te-dropdown-wrap{position:relative}.te-btn{min-width:32px;height:32px;padding:0 7px;border:0;border-radius:7px;background:transparent;color:#475569;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:4px;transition:background .12s ease,color .12s ease,box-shadow .12s ease}.te-btn svg{width:15px;height:15px;display:block}.te-btn .chev{width:12px;height:12px;opacity:.55;flex-shrink:0}.te-btn:hover:not(:disabled){background:#e8eef6;color:var(--te-ink)}.te-btn:focus-visible{outline:2px solid var(--te-accent);outline-offset:1px}.te-btn.active{background:var(--te-accent-soft);color:var(--te-accent);box-shadow:inset 0 0 0 1px #2563eb38}.te-btn:disabled{opacity:.35;cursor:default}.te-btn-wide{min-width:124px;height:32px;padding:0 10px;font-size:12.5px;font-weight:600;letter-spacing:-.01em;justify-content:space-between;background:#fff;box-shadow:inset 0 0 0 1px var(--te-line)}.te-btn-font{min-width:132px;max-width:160px}.te-btn-font span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.te-btn-size{min-width:78px}.te-menu-font{min-width:200px;max-height:280px;overflow-y:auto;scrollbar-width:thin;scrollbar-color:#c1c7d0 transparent}.te-text{font-size:12px;font-weight:700;font-family:var(--te-font-ui)}.te-color-icon{font-size:13px;font-weight:800;border-bottom:3px solid currentColor;line-height:1;padding-bottom:1px;font-family:var(--te-font-doc)}.te-menu{position:absolute;top:calc(100% + 6px);left:0;min-width:180px;padding:6px;border-radius:10px;border:1px solid var(--te-line);background:#fff;box-shadow:0 12px 32px #1c24341f;z-index:40;animation:te-pop .14s ease-out}@keyframes te-pop{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}.te-menu-item{width:100%;border:0;background:transparent;text-align:left;padding:8px 10px;border-radius:7px;color:#334155;font-size:13px;font-family:var(--te-font-ui);cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:12px}.te-menu-item:hover{background:#f1f5f9;color:var(--te-ink)}.te-menu-item.active{background:var(--te-accent-soft);color:var(--te-accent);font-weight:600}.te-menu-item[data-level=\"1\"]{font-size:18px;font-weight:700;font-family:var(--te-font-doc)}.te-menu-item[data-level=\"2\"]{font-size:16px;font-weight:700;font-family:var(--te-font-doc)}.te-menu-item[data-level=\"3\"]{font-size:14px;font-weight:700;font-family:var(--te-font-doc)}.te-menu-item[data-level=\"4\"]{font-size:13px;font-weight:700;font-family:var(--te-font-doc)}.te-swatches{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;min-width:156px;padding:10px}.te-table-picker{min-width:188px;padding:10px}.te-table-picker-label{font-size:12px;font-weight:600;color:var(--te-muted);margin-bottom:8px;text-align:center}.te-table-grid{display:grid;grid-template-columns:repeat(8,1fr);gap:3px}.te-table-cell{width:18px;height:18px;padding:0;border:1px solid #cbd5e1;border-radius:3px;background:#fff;cursor:pointer}.te-table-cell.on{background:var(--te-accent-soft);border-color:var(--te-accent)}.te-table-bar{display:flex;flex-wrap:wrap;align-items:center;gap:2px 4px;padding:6px 10px;border-bottom:1px solid var(--te-line);background:linear-gradient(180deg,var(--te-accent-soft) 0%,#f8fbff 100%)}.te-table-bar-label{font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--te-accent);margin-right:6px}.te-table-sep{width:1px;height:18px;background:var(--te-line-strong);margin:0 4px}.te-btn-label{font-size:11px;font-weight:600;white-space:nowrap}.te-table-bar .te-btn{min-width:auto;height:28px;gap:4px;padding:0 8px}.te-btn-danger{color:#b91c1c}.te-btn-danger:hover:not(:disabled){background:#fef2f2;color:#991b1b}.te-swatch{width:28px;height:28px;border-radius:8px;border:1px solid rgba(15,23,42,.12);cursor:pointer;padding:0;transition:transform .12s ease,box-shadow .12s ease}.te-swatch:hover{transform:scale(1.08)}.te-swatch.active{box-shadow:0 0 0 2px #fff,0 0 0 4px var(--te-accent)}.te-swatch.clear{background-image:linear-gradient(45deg,#e2e8f0 25%,transparent 25%,transparent 75%,#e2e8f0 75%);background-size:10px 10px}.te-canvas{background:radial-gradient(ellipse 80% 50% at 50% 0%,rgba(37,99,235,.04),transparent 70%),linear-gradient(180deg,#e8edf5 0%,var(--te-canvas) 100%);padding:28px 18px 36px;flex:1}.te-paper{max-width:780px;margin:0 auto;background:#fff;border:1px solid #dde3ec;border-radius:4px;box-shadow:0 1px 2px #1c24340a,0 12px 28px #1c243412;overflow:hidden;transition:box-shadow .2s ease}.te-paper:focus-within{box-shadow:0 1px 2px #1c24340a,0 14px 36px #2563eb1a,0 0 0 1px #2563eb2e}.te-host{min-height:480px}:host ::ng-deep .ql-toolbar{display:none!important}:host ::ng-deep .ql-container.ql-snow{border:0;font-family:var(--te-font-doc);font-size:17px}:host ::ng-deep .ql-editor{min-height:480px;max-height:680px;overflow-y:auto;overflow-x:hidden;padding:44px 52px 56px;line-height:1.75;color:var(--te-ink);font-optical-sizing:auto;scrollbar-width:thin;scrollbar-color:#c1c7d0 transparent}:host ::ng-deep .ql-editor::-webkit-scrollbar{width:10px}:host ::ng-deep .ql-editor::-webkit-scrollbar-track{background:transparent;margin:8px 0}:host ::ng-deep .ql-editor::-webkit-scrollbar-thumb{background:#c1c7d0;border-radius:999px;border:2px solid transparent;background-clip:padding-box}:host ::ng-deep .ql-editor::-webkit-scrollbar-thumb:hover{background:#9aa3b2;border:2px solid transparent;background-clip:padding-box}:host ::ng-deep .ql-editor.ql-blank:before{color:#94a3b8;font-style:normal;font-family:var(--te-font-ui);font-size:15px;left:52px;right:52px}:host ::ng-deep .ql-editor h1{font-size:2.15rem;font-weight:700;letter-spacing:-.025em;line-height:1.25;margin:0 0 .5em;color:#0f172a}:host ::ng-deep .ql-editor h2{font-size:1.5rem;font-weight:700;letter-spacing:-.02em;margin:1.35em 0 .45em;color:#0f172a}:host ::ng-deep .ql-editor h3{font-size:1.25rem;font-weight:700;margin:1.2em 0 .4em}:host ::ng-deep .ql-editor h4{font-size:1.05rem;font-weight:700;margin:1.05em 0 .35em}:host ::ng-deep .ql-editor p,:host ::ng-deep .ql-editor ul,:host ::ng-deep .ql-editor ol,:host ::ng-deep .ql-editor pre,:host ::ng-deep .ql-editor blockquote{margin-bottom:.9em}:host ::ng-deep .ql-editor ul,:host ::ng-deep .ql-editor ol{padding-left:1.4em}:host ::ng-deep .ql-editor blockquote{border-left:3px solid var(--te-accent);background:linear-gradient(90deg,var(--te-accent-soft),transparent 90%);color:#475569;padding:12px 16px;border-radius:0 8px 8px 0;margin:.2em 0 1em;font-style:italic}:host ::ng-deep .ql-editor pre.ql-syntax{background:#1c2434;color:#e2e8f0;border-radius:8px;padding:16px 18px;overflow:auto;font-family:ui-monospace,Cascadia Code,SF Mono,Menlo,monospace;font-size:13.5px;line-height:1.55}:host ::ng-deep .ql-editor code{font-family:ui-monospace,Cascadia Code,Menlo,monospace;font-size:.88em;background:#f1f5f9;color:#be185d;padding:.12em .38em;border-radius:4px}:host ::ng-deep .ql-editor a{color:var(--te-accent);text-decoration-thickness:1px;text-underline-offset:2px}:host ::ng-deep .ql-editor img{max-width:100%;border-radius:6px;margin:.4em 0}:host ::ng-deep .ql-editor table{width:100%;border-collapse:collapse;margin:.4em 0 1.1em;font-family:var(--te-font-ui);font-size:14px;table-layout:fixed}:host ::ng-deep .ql-editor th,:host ::ng-deep .ql-editor td{border:1px solid #cbd5e1;padding:10px 12px;min-width:48px;vertical-align:top;background:#fff}:host ::ng-deep .ql-editor th{background:#f8fafc;font-weight:600;text-align:left}:host ::ng-deep .ql-editor td.ql-table-selected,:host ::ng-deep .ql-editor td:focus{outline:2px solid rgba(37,99,235,.35);outline-offset:-2px}:host ::ng-deep .ql-editor hr{border:0;border-top:1px solid #d8dee8;margin:1.6em 0}.te-footer{display:flex;flex-wrap:wrap;gap:6px 12px;align-items:center;padding:9px 16px;border-top:1px solid var(--te-line);background:linear-gradient(180deg,#fafbfc,#f4f6f9);color:var(--te-muted);font-size:12px;font-weight:500}.te-footer .stat{display:inline-flex;align-items:center;gap:6px;font-variant-numeric:tabular-nums}.te-footer .stat-label{color:#94a3b8;font-weight:500;text-transform:uppercase;letter-spacing:.04em;font-size:10.5px}.te-footer .sep{width:1px;height:12px;background:var(--te-line-strong)}.te-footer .hint{margin-left:auto;color:#94a3b8;font-weight:500}.te-footer .badge{display:inline-flex;align-items:center;gap:5px;padding:3px 8px;border-radius:6px;background:var(--te-accent-soft);color:var(--te-accent);font-size:11px;font-weight:600}.te-footer .badge-dot{width:6px;height:6px;border-radius:50%;background:var(--te-accent)}@media(max-width:720px){.te-canvas{padding:14px 10px 20px}:host ::ng-deep .ql-editor{padding:24px 20px 32px;min-height:360px;font-size:16px}:host ::ng-deep .ql-editor.ql-blank:before{left:20px;right:20px}.te-btn-wide{min-width:108px}.te-footer .hint{margin-left:0;width:100%}}\n"] }]
        }], propDecorators: { editorHost: [{
                type: ViewChild,
                args: ['editorHost', { static: true }]
            }], fileInput: [{
                type: ViewChild,
                args: ['fileInput']
            }] } });

/*
 * Public API of classic-editor
 * Prefer importing from 'classic-editor' — only export stable surface here.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CLASSIC_EDITOR_FONTS_URL, ClassicEditorComponent, EDITOR_FONTS, HEADING_OPTIONS, HIGHLIGHT_COLORS, SIZE_OPTIONS, TABLE_GRID_MAX, TEXT_COLORS, buildTableGrid, createQuill, getTableModule, printHtml, readQuillHtml, setupQuillFormats, writeQuillHtml };
//# sourceMappingURL=classic-editor.mjs.map
