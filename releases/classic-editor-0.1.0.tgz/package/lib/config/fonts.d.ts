/** Font options applied via Quill StyleAttributor (`font-family`). Edit here to extend. */
export declare const EDITOR_FONTS: readonly [{
    readonly label: "Default";
    readonly value: false;
    readonly css: "";
}, {
    readonly label: "Jakarta Sans";
    readonly value: "Plus Jakarta Sans";
    readonly css: "\"Plus Jakarta Sans\", sans-serif";
}, {
    readonly label: "Source Serif";
    readonly value: "Source Serif 4";
    readonly css: "\"Source Serif 4\", Georgia, serif";
}, {
    readonly label: "Merriweather";
    readonly value: "Merriweather";
    readonly css: "Merriweather, Georgia, serif";
}, {
    readonly label: "Lora";
    readonly value: "Lora";
    readonly css: "Lora, Georgia, serif";
}, {
    readonly label: "Georgia";
    readonly value: "Georgia";
    readonly css: "Georgia, serif";
}, {
    readonly label: "Times New Roman";
    readonly value: "Times New Roman";
    readonly css: "\"Times New Roman\", Times, serif";
}, {
    readonly label: "Arial";
    readonly value: "Arial";
    readonly css: "Arial, Helvetica, sans-serif";
}, {
    readonly label: "Verdana";
    readonly value: "Verdana";
    readonly css: "Verdana, Geneva, sans-serif";
}, {
    readonly label: "JetBrains Mono";
    readonly value: "JetBrains Mono";
    readonly css: "\"JetBrains Mono\", ui-monospace, monospace";
}, {
    readonly label: "Courier New";
    readonly value: "Courier New";
    readonly css: "\"Courier New\", Courier, monospace";
}];
export type EditorFontValue = (typeof EDITOR_FONTS)[number]['value'];
/** Load once in the host app `<head>` so picker fonts render correctly. */
export declare const CLASSIC_EDITOR_FONTS_URL = "https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Lora:wght@400;600;700&family=Merriweather:wght@400;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&display=swap";
export declare function fontWhitelist(): string[];
export declare function fontLabelOf(value: unknown): string;
export declare function fontPreviewCss(value: EditorFontValue): string;
