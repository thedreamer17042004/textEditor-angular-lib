/** Font options applied via Quill StyleAttributor (`font-family`). Edit here to extend. */
export declare const EDITOR_FONTS: readonly [{
    readonly label: "Default";
    readonly value: false;
    readonly css: "";
}, {
    readonly label: "Inter";
    readonly value: "Inter";
    readonly css: "Inter, system-ui, sans-serif";
}, {
    readonly label: "Georgia";
    readonly value: "Georgia";
    readonly css: "Georgia, serif";
}, {
    readonly label: "Times New Roman";
    readonly value: "Times New Roman";
    readonly css: "\"Times New Roman\", Times, serif";
}, {
    readonly label: "Arial";
    readonly value: "Arial";
    readonly css: "Arial, Helvetica, sans-serif";
}, {
    readonly label: "Verdana";
    readonly value: "Verdana";
    readonly css: "Verdana, Geneva, sans-serif";
}, {
    readonly label: "Courier New";
    readonly value: "Courier New";
    readonly css: "\"Courier New\", Courier, monospace";
}, {
    readonly label: "JetBrains Mono";
    readonly value: "JetBrains Mono";
    readonly css: "\"JetBrains Mono\", ui-monospace, monospace";
}];
export type EditorFontValue = (typeof EDITOR_FONTS)[number]['value'];
/** Load once in the host app `<head>` so picker fonts render correctly. */
export declare const CLASSIC_EDITOR_FONTS_URL = "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap";
export declare function fontWhitelist(): string[];
export declare function fontLabelOf(value: unknown): string;
export declare function fontPreviewCss(value: EditorFontValue): string;
