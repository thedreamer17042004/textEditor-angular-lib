/** Central toolbar option lists — extend here when adding formats. */
export declare const HEADING_OPTIONS: readonly [{
    readonly label: "Paragraph";
    readonly value: false;
}, {
    readonly label: "Heading 1";
    readonly value: 1;
}, {
    readonly label: "Heading 2";
    readonly value: 2;
}, {
    readonly label: "Heading 3";
    readonly value: 3;
}, {
    readonly label: "Heading 4";
    readonly value: 4;
}];
export type HeadingValue = (typeof HEADING_OPTIONS)[number]['value'];
export declare const SIZE_OPTIONS: readonly ["12px", "14px", "16px", "18px", "24px", "32px"];
export type SizeValue = (typeof SIZE_OPTIONS)[number];
export declare const TEXT_COLORS: readonly ["#0f172a", "#334155", "#64748b", "#ef4444", "#f59e0b", "#10b981", "#0ea5e9", "#a855f7"];
export declare const HIGHLIGHT_COLORS: readonly ["transparent", "#fef08a", "#bbf7d0", "#bae6fd", "#fbcfe8", "#fecaca", "#e2e8f0"];
/** Max insert-table picker size (rows × cols). */
export declare const TABLE_GRID_MAX = 8;
