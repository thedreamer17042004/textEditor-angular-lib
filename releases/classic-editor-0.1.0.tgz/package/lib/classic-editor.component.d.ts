import { AfterViewInit, OnDestroy } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { EditorFontValue, HeadingValue } from './config';
import { QuillFormatMap, TableAction, ToolbarMenu } from './core';
import * as i0 from "@angular/core";
/**
 * Classic Quill editor shell.
 * Keep this file thin: UI state + wiring. Engine/options/helpers live under config|core|features.
 */
export declare class ClassicEditorComponent implements AfterViewInit, OnDestroy, ControlValueAccessor {
    readonly placeholder: import("@angular/core").InputSignal<string>;
    readonly readonly: import("@angular/core").InputSignal<boolean>;
    readonly styleClass: import("@angular/core").InputSignal<string>;
    readonly contentChange: import("@angular/core").OutputEmitterRef<string>;
    private editorHost;
    private fileInput?;
    private quill;
    private onChangeFn;
    private onTouchedFn;
    private writingValue;
    private pendingValue;
    readonly formats: import("@angular/core").WritableSignal<QuillFormatMap>;
    readonly disabled: import("@angular/core").WritableSignal<boolean>;
    readonly words: import("@angular/core").WritableSignal<number>;
    readonly characters: import("@angular/core").WritableSignal<number>;
    readonly canUndo: import("@angular/core").WritableSignal<boolean>;
    readonly canRedo: import("@angular/core").WritableSignal<boolean>;
    readonly openMenu: import("@angular/core").WritableSignal<ToolbarMenu | null>;
    readonly inTable: import("@angular/core").WritableSignal<boolean>;
    readonly tableHover: import("@angular/core").WritableSignal<{
        rows: number;
        cols: number;
    }>;
    readonly tableGridCells: import("./features").TableGridCell[];
    readonly headingOptions: readonly [{
        readonly label: "Paragraph";
        readonly value: false;
    }, {
        readonly label: "Heading 1";
        readonly value: 1;
    }, {
        readonly label: "Heading 2";
        readonly value: 2;
    }, {
        readonly label: "Heading 3";
        readonly value: 3;
    }, {
        readonly label: "Heading 4";
        readonly value: 4;
    }];
    readonly fontOptions: readonly [{
        readonly label: "Default";
        readonly value: false;
        readonly css: "";
    }, {
        readonly label: "Jakarta Sans";
        readonly value: "Plus Jakarta Sans";
        readonly css: "\"Plus Jakarta Sans\", sans-serif";
    }, {
        readonly label: "Source Serif";
        readonly value: "Source Serif 4";
        readonly css: "\"Source Serif 4\", Georgia, serif";
    }, {
        readonly label: "Merriweather";
        readonly value: "Merriweather";
        readonly css: "Merriweather, Georgia, serif";
    }, {
        readonly label: "Lora";
        readonly value: "Lora";
        readonly css: "Lora, Georgia, serif";
    }, {
        readonly label: "Georgia";
        readonly value: "Georgia";
        readonly css: "Georgia, serif";
    }, {
        readonly label: "Times New Roman";
        readonly value: "Times New Roman";
        readonly css: "\"Times New Roman\", Times, serif";
    }, {
        readonly label: "Arial";
        readonly value: "Arial";
        readonly css: "Arial, Helvetica, sans-serif";
    }, {
        readonly label: "Verdana";
        readonly value: "Verdana";
        readonly css: "Verdana, Geneva, sans-serif";
    }, {
        readonly label: "JetBrains Mono";
        readonly value: "JetBrains Mono";
        readonly css: "\"JetBrains Mono\", ui-monospace, monospace";
    }, {
        readonly label: "Courier New";
        readonly value: "Courier New";
        readonly css: "\"Courier New\", Courier, monospace";
    }];
    readonly sizeOptions: readonly ["12px", "14px", "16px", "18px", "24px", "32px"];
    readonly textColors: readonly ["#0f172a", "#334155", "#64748b", "#ef4444", "#f59e0b", "#10b981", "#0ea5e9", "#a855f7"];
    readonly highlightColors: readonly ["transparent", "#fef08a", "#bbf7d0", "#bae6fd", "#fbcfe8", "#fecaca", "#e2e8f0"];
    readonly headingLabel: import("@angular/core").Signal<string>;
    readonly sizeLabel: import("@angular/core").Signal<string>;
    readonly fontLabel: import("@angular/core").Signal<string>;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private onDocClick;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    locked(): boolean;
    isActive(format: string, value?: unknown): boolean;
    toggleMenu(menu: ToolbarMenu, event: Event): void;
    previewTableSize(rows: number, cols: number, event: Event): void;
    tableSizeLabel(): string;
    format(name: string, value?: unknown, event?: Event): void;
    setHeading(value: HeadingValue, event: Event): void;
    setSize(size: string, event: Event): void;
    setFont(font: EditorFontValue, event: Event): void;
    fontPreviewCss(font: EditorFontValue): string;
    setColor(format: 'color' | 'background', color: string, event: Event): void;
    promptLink(event?: Event): void;
    undo(event?: Event): void;
    redo(event?: Event): void;
    clean(event?: Event): void;
    insertHr(event?: Event): void;
    insertTable(rows: number, cols: number, event?: Event): void;
    tableAction(action: TableAction, event?: Event): void;
    openImagePicker(event: Event): void;
    onImageSelected(event: Event): void;
    insertImageUrl(event: Event): void;
    print(event?: Event): void;
    private setHtml;
    private refreshChrome;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClassicEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClassicEditorComponent, "ce-editor", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, { "contentChange": "contentChange"; }, never, never, true, never>;
}
