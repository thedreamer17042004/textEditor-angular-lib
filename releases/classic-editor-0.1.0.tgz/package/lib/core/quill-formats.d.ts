/** Register Quill style attributors used by the Classic toolbar. */
export declare function setupQuillFormats(): void;
