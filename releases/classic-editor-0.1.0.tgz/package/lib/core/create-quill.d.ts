import Quill from 'quill';
import { QuillTableModule } from './types';
export interface CreateQuillOptions {
    placeholder: string;
    readOnly: boolean;
}
/** Factory for the editor engine — keep Quill wiring here, not in the component. */
export declare function createQuill(host: HTMLElement, options: CreateQuillOptions): Quill;
export declare function getTableModule(quill: Quill | null): QuillTableModule | null;
