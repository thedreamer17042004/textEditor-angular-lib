/** Print HTML via a hidden iframe (avoids popup blockers / noopener null window). */
export declare function printHtml(bodyHtml: string, title?: string): void;
