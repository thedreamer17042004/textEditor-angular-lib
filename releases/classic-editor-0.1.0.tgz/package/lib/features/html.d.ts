import Quill from 'quill';
export declare function readQuillHtml(quill: Quill | null): string;
export declare function writeQuillHtml(quill: Quill, html: string): void;
