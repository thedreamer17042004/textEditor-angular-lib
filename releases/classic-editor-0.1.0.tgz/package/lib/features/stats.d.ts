import Quill from 'quill';
export interface EditorStats {
    words: number;
    characters: number;
    canUndo: boolean;
    canRedo: boolean;
}
export declare function readEditorStats(quill: Quill): EditorStats;
