import Quill from 'quill';
import { TableAction } from '../core/types';
export interface TableGridCell {
    row: number;
    col: number;
}
export declare function buildTableGrid(max?: number): TableGridCell[];
export declare function isSelectionInTable(quill: Quill | null): boolean;
export declare function insertTableAtSelection(quill: Quill, rows: number, cols: number): void;
export declare function runTableAction(quill: Quill, action: TableAction): void;
export declare function tableSizeLabel(rows: number, cols: number): string;
